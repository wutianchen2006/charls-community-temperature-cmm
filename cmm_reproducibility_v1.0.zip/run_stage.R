args <- commandArgs(trailingOnly=TRUE)
stages <- read.csv("STAGES.csv", stringsAsFactors=FALSE, fileEncoding="UTF-8-BOM")
if (!length(args) || args[1]=="--list") {print(stages, row.names=FALSE); quit(status=0)}
stopifnot(args[1] %in% as.character(stages$stage))
root <- Sys.getenv("P19_PROJECT_ROOT", unset="")
if (!nzchar(root) || !dir.exists(root)) stop("Set P19_PROJECT_ROOT to the authorized local analysis project; do not upload participant data.")
script <- stages$script[as.character(stages$stage)==args[1]]
source(script, encoding="UTF-8")
