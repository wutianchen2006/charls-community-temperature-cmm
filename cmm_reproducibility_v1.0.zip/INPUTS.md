# Required authorized inputs

Keep these files outside the public repository and do not commit them.

1. Frozen analytic risk set: 15,061 participants, 1,117 first CMM events, 446 communities. Event time: time_from_2011_years. Event indicator: cmm_event. Covariates: Age, Gender, Residence, Education_Status, Marital_status, Smoking_Status, Drinking_Status, household_income, BMI2011, Regional_Category_2011; participant identifiers, community_id and individual_weight are needed for alignment and clustered weighted Cox analysis. Exposure column names are mapped in EXPOSURES.csv. Preserve the original types/factor levels and row alignment.
2. MICE prepared input and saved mids object: 20 imputations, 25 iterations, seed 20261025. The original Part A/B scripts specify the exact factor preparation and predictor matrix; baseline disease count is retained for imputation, excluded from the final M3 adjustment set.
3. For mortality CIFs and migration sensitivity, the selected scripts require the corresponding mortality and address inputs under their documented project locations. These are not included publicly.

Set P19_PROJECT_ROOT to an analysis project laid out as in `analysis/`. The expected risk-set path is `02_人群纳排与风险集/数据/人群筛选_20261022/2011_2020_CMM主风险集_年龄45岁及以上.rds`; the saved imputation path is `06_ABC多重插补/数据/PartB_MICE_m20_maxit25_seed20261025.rds`. Never supply fabricated participant data to satisfy these inputs.
