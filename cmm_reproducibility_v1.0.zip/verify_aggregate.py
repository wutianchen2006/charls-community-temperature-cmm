from pathlib import Path
import csv, math
p=Path(__file__).resolve().parent
def rows(n):
    with (p/'aggregate'/n).open(encoding='utf-8-sig', newline='') as f:return list(csv.DictReader(f))
counts=rows('quartile_counts_events_person_years.csv')
for e in ['TV','Tmean','DTR','Anum','Bnum','CEnum']:
    rr=[r for r in counts if r['exposure']==e]
    assert sum(int(r['n']) for r in rr)==15061
    assert sum(int(r['events']) for r in rr)==1117
    assert math.isclose(sum(float(r['person_years']) for r in rr),113600.0833333333,abs_tol=1e-6)
for r in rows('quartile_boundaries.csv'):
    assert math.isclose(float(r['p75'])-float(r['p25']),float(r['IQR']),abs_tol=1e-10)
kn=rows('spline_knots.csv')
assert [float(r['knot_value']) for r in kn if r['exposure']=='Bnum']==[0,2,4]
assert all(sum(r['exposure']==e for r in kn)==4 for e in ['TV','Tmean','DTR','Anum','CEnum'])
mi=rows('imputation_run_summary.csv')[0]
assert [int(mi[k]) for k in ['risk_set_n','events','m','maxit','seed']]==[15061,1117,20,25,20261025]
print('PASS: aggregate counts, person-years, cutoffs, knots and MICE settings; no participant-level model reanalysis performed.')
