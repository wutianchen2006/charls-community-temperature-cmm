# Community environment, long-term temperature and incident CMM

Reproducibility materials for: Community built environment and long-term temperature exposure in relation to incident cardiometabolic multimorbidity: A cohort study in China.

This release contains study analysis scripts and aggregate verification data. It does not contain participant-level CHARLS records, identifiers, imputation objects, credentials or local account configuration.

## Data access

Obtain participant data through CHARLS (https://charls.pku.edu.cn/) under its applicable access terms. The analysis used surveys in 2011, 2013, 2015, 2018 and 2020, Harmonized CHARLS D, community survey information, and charlsMAX derived CMM states. The public data do not reconstruct participants. Authorized users need to prepare the input files described in INPUTS.md.

Temperature source: Zhang, L., Hu, Y., Zhao, Y., Che, T. (2025), ChinaMet, National Cryosphere Desert Data Center, https://doi.org/10.12072/ncdc.nieer.db6722.2025 (CC BY 4.0). This study used supplied provincial Tmax/Tmin summaries. Which source grid and spatial weights produced those summaries is not documented in the available archive; neither individual 1 km exposure nor a specific grid aggregation algorithm is claimed.

## Contents and checks

- `analysis/`: selected executed analysis scripts, with machine-specific project roots made configurable. Original study code is not altered.
- `aggregate/`: provincial exposures, model summaries, quartile boundaries, spline knots and imputation settings. No person-level rows.
- `verify_aggregate.py`: standard-library-only checks of cohort counts, exposure cutoffs and spline parameters against saved outputs.
- `run_stage.R`: explicitly run one selected stage against authorized local inputs. It does not download data or install packages.
- `INPUTS.md`, `RUN_ORDER.md`, `SOFTWARE.md`: required inputs, execution order and dependency information.

Run `python verify_aggregate.py` from this directory for the aggregate audit. R scripts require R 4.4.3 and the packages listed in SOFTWARE.md. Run `Rscript run_stage.R --list` to see stages. Full participant-level reanalysis requires authorized input data and has not been rerun solely to prepare this repository. Do not confuse aggregate checks or R syntax checks with rerunning all Cox models.

The repository is an analysis-from-prepared-inputs release. Upstream acquisition and preparation depend on the source access routes and input definitions; it is not a claim that a fresh raw-data-to-publication reproduction is possible with this archive alone. Known provenance gaps are documented in PROVENANCE.md.
