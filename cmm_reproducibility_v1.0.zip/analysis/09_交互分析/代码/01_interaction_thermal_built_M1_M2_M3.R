# ============================================================================
# 步骤09：气温暴露与建成环境的交互分析
#
# 预先规定的九个交互组合：
#   TV、Tmean、DTR 分别与 Anum、Bnum、CEnum 交互；
#   每个组合分别拟合 M1、M2 和修订 M3，共27个模型，每个模型20份插补。
#
# Anum、Bnum、CEnum不能同时放在同一个公式中，因为CEnum是Anum+Bnum的综合
# 指标。本脚本将每个组合单独建模，报告交互项P值、Rubin合并结果和条件HR图。
# 不根据P值删除组合，不修改风险集、暴露定义或协变量。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
suppressPackageStartupMessages({
  library(survival)
  library(mice)
  library(ggplot2)
  library(digest)
})

# 1. 路径 --------------------------------------------------------------------
project_root <- Sys.getenv("P19_PROJECT_ROOT", unset = "analysis")
riskset_default <- file.path(project_root, "02_人群纳排与风险集", "数据",
                             "人群筛选_20261022", "2011_2020_CMM主风险集_年龄45岁及以上.rds")
mids_default <- file.path(project_root, "06_ABC多重插补", "数据",
                          "PartB_MICE_m20_maxit25_seed20261025.rds")
riskset_path <- Sys.getenv("P19_INT_RISKSET_ASCII", unset = riskset_default)
mids_path <- Sys.getenv("P19_INT_MIDS_ASCII", unset = mids_default)
result_dir <- Sys.getenv("P19_INT_RESULT_ASCII", unset = file.path(project_root, "09_交互分析", "结果"))
data_dir <- Sys.getenv("P19_INT_DATA_ASCII", unset = file.path(project_root, "09_交互分析", "数据"))
trace_dir <- Sys.getenv("P19_INT_TRACE_ASCII", unset = file.path(project_root, "09_交互分析", "追溯文件"))
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(trace_dir, recursive = TRUE, showWarnings = FALSE)
if (!all(file.exists(c(riskset_path, mids_path)))) stop("交互分析输入文件不存在。")

# 2. 输入门禁 ----------------------------------------------------------------
riskset <- readRDS(riskset_path)
mids_obj <- readRDS(mids_path)
as_event <- function(x) suppressWarnings(as.integer(as.character(x)))
if (!inherits(mids_obj, "mids") || mids_obj$m != 20L || mids_obj$iteration != 25L) {
  stop("MICE对象不是冻结的m=20、maxit=25版本。")
}
if (nrow(riskset) != 15061L || sum(as_event(riskset$cmm_event)) != 1117L) {
  stop("风险集不是冻结的15,061人、1,117例事件版本。")
}

thermal_vars <- c(
  TV = "temperature_TV_daily_annual_mean_pre2011",
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010"
)
built_vars <- c(Anum = "built_Anum", Bnum = "built_Bnum", CEnum = "built_CEnum")
model_covariates <- list(
  M1 = c("Age", "Gender", "Residence", "Education_Status"),
  M2 = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
         "Smoking_Status", "Drinking_Status", "household_income"),
  M3_revised = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
                 "Smoking_Status", "Drinking_Status", "household_income", "BMI2011",
                 "Regional_Category_2011")
)
required_vars <- unique(c(unname(thermal_vars), unname(built_vars), unlist(model_covariates),
                          "cmm_event", "time_from_2011_years"))
if (!all(required_vars %in% names(mids_obj$data))) stop("MICE对象缺少交互分析变量。")

completed_data <- lapply(seq_len(mids_obj$m), function(i) {
  d <- mice::complete(mids_obj, action = i)
  if (nrow(d) != nrow(riskset) ||
      !identical(as_event(d$cmm_event), as_event(riskset$cmm_event)) ||
      !isTRUE(all.equal(as.numeric(d$time_from_2011_years),
                        as.numeric(riskset$time_from_2011_years), check.attributes = FALSE))) {
    stop("第", i, "份插补数据的结局或随访时间与风险集不一致。")
  }
  for (v in c(unname(thermal_vars), unname(built_vars))) {
    if (!isTRUE(all.equal(as.numeric(d[[v]]), as.numeric(riskset[[v]]),
                          check.attributes = FALSE))) stop("固定暴露发生变化：", v)
  }
  d$community_id_fixed <- as.character(riskset$community_id)
  d$individual_weight_fixed <- as.numeric(riskset$individual_weight)
  d
})

# 3. Rubin合并和条件HR函数 ---------------------------------------------------
fit_interaction <- function(d, thermal_name, built_name, covariates) {
  d$cmm_event_num <- as_event(d$cmm_event)
  d$analysis_weight <- d$individual_weight_fixed / mean(d$individual_weight_fixed)
  formula <- stats::as.formula(paste(
    "survival::Surv(time_from_2011_years, cmm_event_num) ~ thermal_c * built_c +",
    paste(covariates, collapse = " + "), "+ cluster(community_id_fixed)"
  ))
  survival::coxph(formula, data = d, weights = analysis_weight, ties = "efron",
                  robust = TRUE, na.action = stats::na.fail, x = TRUE)
}

pool_term <- function(fits, term, thermal_name, built_name, model_name) {
  q <- vapply(fits, function(f) unname(stats::coef(f)[term]), numeric(1))
  u <- vapply(fits, function(f) unname(stats::vcov(f)[term, term]), numeric(1))
  m <- length(q); qbar <- mean(q); within <- mean(u)
  between <- if (m > 1) stats::var(q) else 0
  total <- within + (1 + 1 / m) * between
  se <- sqrt(total)
  df <- if (between <= .Machine$double.eps) Inf else
    (m - 1) * (1 + within / ((1 + 1 / m) * between))^2
  crit <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
  p <- if (is.finite(df)) 2 * stats::pt(abs(qbar / se), df, lower.tail = FALSE) else
    2 * stats::pnorm(abs(qbar / se), lower.tail = FALSE)
  data.frame(thermal = thermal_name, built = built_name, model = model_name,
             term = term, imputations = m, beta = qbar, robust_SE = se,
             HR = exp(qbar), CI_95_low = exp(qbar - crit * se),
             CI_95_high = exp(qbar + crit * se), p_value = p, df = df,
             within_variance = within, between_variance = between,
             n = 15061L, events = 1117L, communities = 446L,
             stringsAsFactors = FALSE)
}

pool_contrast <- function(fits, built_c_value) {
  estimates <- vapply(fits, function(f) {
    b <- stats::coef(f)
    unname(b["thermal_c"] + built_c_value * b["thermal_c:built_c"])
  }, numeric(1))
  variances <- vapply(fits, function(f) {
    V <- stats::vcov(f)
    L <- setNames(rep(0, nrow(V)), rownames(V))
    L["thermal_c"] <- 1
    L["thermal_c:built_c"] <- built_c_value
    as.numeric(t(L) %*% V %*% L)
  }, numeric(1))
  m <- length(estimates); qbar <- mean(estimates); within <- mean(variances)
  between <- stats::var(estimates); total <- within + (1 + 1 / m) * between
  se <- sqrt(total)
  df <- if (between <= .Machine$double.eps) Inf else
    (m - 1) * (1 + within / ((1 + 1 / m) * between))^2
  crit <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
  data.frame(beta = qbar, HR = exp(qbar), CI_95_low = exp(qbar - crit * se),
             CI_95_high = exp(qbar + crit * se), p_value = if (is.finite(df))
               2 * stats::pt(abs(qbar / se), df, lower.tail = FALSE) else
               2 * stats::pnorm(abs(qbar / se), lower.tail = FALSE), df = df,
             stringsAsFactors = FALSE)
}

# 4. 运行27个模型 ------------------------------------------------------------
term_results <- list(); conditional_results <- list(); boundaries <- list(); audits <- list()
pair_labels <- c(
  TV = "Temperature variability (TV)", Tmean = "Mean temperature (Tmean)",
  DTR = "Diurnal temperature range (DTR)", Anum = "Infrastructure score (Anum)",
  Bnum = "Community support score (Bnum)", CEnum = "Composite built environment score (CEnum)"
)

for (thermal_name in names(thermal_vars)) {
  for (built_name in names(built_vars)) {
    thermal_col <- thermal_vars[[thermal_name]]; built_col <- built_vars[[built_name]]
    thermal_x <- as.numeric(riskset[[thermal_col]]); built_x <- as.numeric(riskset[[built_col]])
    thermal_med <- stats::median(thermal_x, na.rm = TRUE); built_med <- stats::median(built_x, na.rm = TRUE)
    thermal_iqr <- stats::IQR(thermal_x, na.rm = TRUE); built_iqr <- stats::IQR(built_x, na.rm = TRUE)
    if (!is.finite(thermal_iqr) || thermal_iqr <= 0 || !is.finite(built_iqr) || built_iqr <= 0) {
      stop("交互变量IQR无效：", thermal_name, " / ", built_name)
    }
    boundaries[[paste(thermal_name, built_name, sep = "_")]] <- data.frame(
      thermal = thermal_name, built = built_name,
      thermal_median = thermal_med, thermal_IQR = thermal_iqr,
      built_p25 = as.numeric(stats::quantile(built_x, .25)),
      built_median = built_med, built_p75 = as.numeric(stats::quantile(built_x, .75)),
      built_IQR = built_iqr, stringsAsFactors = FALSE
    )
    for (i in seq_along(completed_data)) {
      completed_data[[i]]$thermal_c <- (as.numeric(completed_data[[i]][[thermal_col]]) - thermal_med) / thermal_iqr
      completed_data[[i]]$built_c <- (as.numeric(completed_data[[i]][[built_col]]) - built_med) / built_iqr
    }
    for (model_name in names(model_covariates)) {
      fits <- lapply(completed_data, fit_interaction, thermal_name = thermal_name,
                     built_name = built_name, covariates = model_covariates[[model_name]])
      term_results[[paste(thermal_name, built_name, model_name, sep = "_")]] <- do.call(rbind, lapply(
        c("thermal_c", "built_c", "thermal_c:built_c"), pool_term, fits = fits,
        thermal_name = thermal_name, built_name = built_name, model_name = model_name
      ))
      audits[[paste(thermal_name, built_name, model_name, sep = "_")]] <- data.frame(
        thermal = thermal_name, built = built_name, model = model_name,
        imputations = length(fits), n = 15061L, events = 1117L, communities = 446L,
        thermal_median = thermal_med, thermal_IQR = thermal_iqr,
        built_median = built_med, built_IQR = built_iqr, stringsAsFactors = FALSE
      )

      # 交互图和条件效应均只输出修订M3，M1/M2保留完整统计表。
      if (model_name == "M3_revised") {
        grid <- sort(unique(built_x))
        if (length(grid) > 80L) grid <- seq(min(built_x), max(built_x), length.out = 100L)
        curve <- do.call(rbind, lapply(grid, function(v) {
          built_c_value <- (v - built_med) / built_iqr
          cbind(thermal = thermal_name, built = built_name, model = model_name,
                built_value = v, built_c = built_c_value, pool_contrast(fits, built_c_value))
        }))
        conditional_results[[paste(thermal_name, built_name, sep = "_")]] <- curve
        p <- ggplot(curve, aes(built_value, HR)) +
          geom_ribbon(aes(ymin = CI_95_low, ymax = CI_95_high), fill = "#0072B2", alpha = 0.18) +
          geom_line(color = "#0072B2", linewidth = 0.8) +
          geom_hline(yintercept = 1, linetype = 2, color = "grey45") +
          geom_vline(xintercept = as.numeric(stats::quantile(built_x, c(.25, .50, .75))),
                     linetype = 3, color = "grey60") +
          labs(title = paste(pair_labels[[thermal_name]], "x", pair_labels[[built_name]]),
               subtitle = "M3 revised; HR for one thermal-exposure IQR",
               x = built_name, y = paste0(thermal_name, " HR (95% CI)")) +
          theme_classic(base_size = 10) + theme(plot.title = element_text(face = "bold"))
        ggplot2::ggsave(file.path(result_dir, paste0("Interaction_", thermal_name, "_", built_name, "_M3.png")),
                        p, width = 7.2, height = 4.6, units = "in", dpi = 600, bg = "white")
        grDevices::cairo_pdf(file.path(result_dir, paste0("Interaction_", thermal_name, "_", built_name, "_M3.pdf")),
                             width = 7.2, height = 4.6); print(p); grDevices::dev.off()
      }
    }
    message("交互完成：", thermal_name, " x ", built_name)
  }
}

term_table <- do.call(rbind, term_results)
term_table$q_BH_M3_interaction <- NA_real_
primary_interactions <- term_table$model == "M3_revised" & term_table$term == "thermal_c:built_c"
term_table$q_BH_M3_interaction[primary_interactions] <- stats::p.adjust(
  term_table$p_value[primary_interactions], method = "BH"
)
write.csv(term_table, file.path(result_dir, "interaction_terms_M1_M2_M3_Rubin.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, conditional_results), file.path(data_dir, "interaction_M3_conditional_HR_source.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, boundaries), file.path(data_dir, "interaction_boundaries_medians_IQR.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, audits), file.path(trace_dir, "interaction_model_audit.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(data.frame(
  file = c(riskset_path, mids_path),
  sha256 = c(digest::digest(riskset_path, file = TRUE, algo = "sha256"),
             digest::digest(mids_path, file = TRUE, algo = "sha256")),
  stringsAsFactors = FALSE
), file.path(trace_dir, "interaction_input_sha256.csv"), row.names = FALSE, fileEncoding = "UTF-8")

writeLines(c(
  paste0("Run time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
  paste0("Risk set: ", nrow(riskset), " persons; ", sum(as_event(riskset$cmm_event)), " events; 446 communities."),
  "Pairs: TV/Tmean/DTR x Anum/Bnum/CEnum; models: M1, M2, M3_revised; 27 models x 20 imputations.",
  "Anum, Bnum and CEnum were fitted in separate models because CEnum is their composite.",
  "Thermal and built exposures were centered at medians and scaled by observed IQR.",
  "Rubin pooling used community-clustered robust covariance; no pair was removed by P value."
), file.path(trace_dir, "interaction_run_trace.txt"), useBytes = TRUE)
message("INTERACTION_ANALYSIS_COMPLETE")
