# =============================================================================
# Part B 插补诊断复核
#
# 本脚本只检查已经完成的 MICE 插补，不会重新运行插补，也不会修改风险集。
# 初学者请先阅读“00_本步骤运行说明.md”，再从第一行运行到最后一行。
#
# 自动核对样本人数、事件数、插补份数、迭代次数、插补后缺失和原始观测值。
# 脚本还会输出连续变量及分类变量的分布表和诊断图。自动检查不能替代人工阅图。
# =============================================================================

options(stringsAsFactors = FALSE, encoding = "UTF-8")

# 一、设置本步骤文件位置 -----------------------------------------------------
# 通常直接使用项目路径；遇到Windows命令行中文路径兼容问题时，可设置P19_MI_DIR。
步骤目录 <- Sys.getenv(
  "P19_MI_DIR",
  unset = enc2native(file.path(Sys.getenv("P19_PROJECT_ROOT", unset = "analysis"), "06_ABC多重插补"))
)
插补对象路径 <- Sys.getenv(
  "P19_MI_OBJECT",
  unset = file.path(步骤目录, "数据", "PartB_MICE_m20_maxit25_seed20261025.rds")
)
插补输入路径 <- Sys.getenv(
  "P19_MI_INPUT",
  unset = file.path(步骤目录, "数据", "PartB_MICE_input_prepared_20261025.rds")
)
结果目录 <- Sys.getenv(
  "P19_MI_RESULT_DIR",
  unset = file.path(步骤目录, "结果", "Part_B_MICE_20261025")
)
追溯目录 <- Sys.getenv(
  "P19_MI_AUDIT_DIR",
  unset = file.path(步骤目录, "追溯文件", "Part_B_MICE_20261025")
)
dir.create(结果目录, recursive = TRUE, showWarnings = FALSE)
dir.create(追溯目录, recursive = TRUE, showWarnings = FALSE)

# 二、确认依赖和输入文件 -----------------------------------------------------
if (!requireNamespace("mice", quietly = TRUE)) {
  stop("没有安装 mice 包。请在 RStudio Console 运行 install.packages('mice')。")
}
if (!file.exists(插补对象路径)) stop("找不到已保存的 MICE 对象：", 插补对象路径)
if (!file.exists(插补输入路径)) stop("找不到 Part B 插补输入：", 插补输入路径)

# 三、读取并核对对象 ---------------------------------------------------------
插补对象 <- readRDS(插补对象路径)
原始输入 <- readRDS(插补输入路径)
if (!inherits(插补对象, "mids")) {
  stop("读取到的文件不是 mice::mids 对象，请停止并检查文件来源。")
}

插补变量 <- c("BMI2011", "household_income", "Smoking_Status", "Drinking_Status")
风险集人数 <- 15061L
事件数预期 <- 1117L
if (!all(插补变量 %in% names(插补对象$data))) {
  stop("MICE对象缺少插补变量：",
       paste(setdiff(插补变量, names(插补对象$data)), collapse = ", "))
}
if (!all(names(插补对象$data) %in% names(原始输入))) {
  stop("MICE对象中有变量不在已保存的Part B输入内。")
}

# 比较 MICE 对象中的输入和准备好的输入，防止误读其他版本。
输入数据一致 <- all(vapply(names(插补对象$data), function(变量名) {
  isTRUE(all.equal(插补对象$data[[变量名]], 原始输入[[变量名]], check.attributes = TRUE))
}, logical(1)))
事件值 <- suppressWarnings(as.integer(as.character(插补对象$data$cmm_event)))
实际事件数 <- sum(事件值 == 1L, na.rm = TRUE)

# 四、逐份检查 20 个完整数据集 -----------------------------------------------
全部完整数据 <- mice::complete(插补对象, action = "all")
逐份核对 <- lapply(seq_along(全部完整数据), function(数据编号) {
  当前数据 <- 全部完整数据[[数据编号]]
  当前事件 <- suppressWarnings(as.integer(as.character(当前数据$cmm_event)))
  data.frame(
    imputation = 数据编号,
    n = nrow(当前数据),
    events = sum(当前事件 == 1L, na.rm = TRUE),
    missing_in_imputed_variables = sum(vapply(
      当前数据[插补变量], function(x) sum(is.na(x)), integer(1)
    )),
    stringsAsFactors = FALSE
  )
})
逐份核对表 <- do.call(rbind, 逐份核对)
write.csv(逐份核对表,
          file.path(结果目录, "B8_imputation_set_checks.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

# 五、检查原始观测值是否在插补中保持不变 -----------------------------------
观测值保持不变 <- do.call(rbind, lapply(插补变量, function(变量名) {
  原始值 <- 插补对象$data[[变量名]]
  观测位置 <- !is.na(原始值)
  每份均保持 <- vapply(全部完整数据, function(当前数据) {
    isTRUE(all.equal(
      as.character(当前数据[[变量名]][观测位置]),
      as.character(原始值[观测位置]), check.attributes = FALSE
    ))
  }, logical(1))
  data.frame(
    variable = 变量名,
    observed_n = sum(观测位置),
    missing_before_imputation = sum(!观测位置),
    all_observed_values_preserved = all(每份均保持),
    stringsAsFactors = FALSE
  )
}))
write.csv(观测值保持不变,
          file.path(结果目录, "B9_observed_value_preservation.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

# 六、汇总连续变量的观测值和插补值分布 -------------------------------------
连续变量 <- c("BMI2011", "household_income")
连续分布 <- do.call(rbind, lapply(连续变量, function(变量名) {
  原始观测 <- 插补对象$data[[变量名]][!is.na(插补对象$data[[变量名]])]
  汇总 <- function(值, 数据标签) {
    data.frame(
      variable = 变量名, dataset = 数据标签, n = length(值),
      mean = mean(值), sd = stats::sd(值), median = stats::median(值),
      q1 = unname(stats::quantile(值, 0.25)),
      q3 = unname(stats::quantile(值, 0.75)), stringsAsFactors = FALSE
    )
  }
  rbind(
    汇总(原始观测, "Observed values"),
    do.call(rbind, lapply(seq_along(全部完整数据), function(i) {
      插补值 <- 全部完整数据[[i]][[变量名]][is.na(插补对象$data[[变量名]])]
      汇总(插补值, paste0("Imputation ", i))
    }))
  )
}))
write.csv(连续分布,
          file.path(结果目录, "B10_continuous_observed_imputed_distributions.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

# 七、汇总分类变量的观测类别和插补类别分布 -------------------------------
分类分布 <- do.call(rbind, lapply(c("Smoking_Status", "Drinking_Status"), function(变量名) {
  原始值 <- 插补对象$data[[变量名]]
  类别 <- sort(unique(as.character(原始值[!is.na(原始值)])))
  数据标签 <- c("Observed values", paste0("Imputation ", seq_along(全部完整数据)))
  do.call(rbind, lapply(数据标签, function(标签) {
    if (标签 == "Observed values") {
      值 <- as.character(原始值[!is.na(原始值)])
    } else {
      编号 <- as.integer(sub("Imputation ", "", 标签))
      值 <- as.character(全部完整数据[[编号]][[变量名]][is.na(原始值)])
    }
    计数 <- table(factor(值, levels = 类别))
    data.frame(
      variable = 变量名, dataset = 标签, category = names(计数),
      n = as.integer(计数), percent = as.numeric(计数) / length(值) * 100,
      stringsAsFactors = FALSE
    )
  }))
}))
write.csv(分类分布,
          file.path(结果目录, "B11_categorical_observed_imputed_distributions.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

# 八、为四个插补变量分别输出链图 -------------------------------------------
# 每个变量单独作图，避免把多个变量放入同一个公式时只显示最后一项。
for (变量名 in 插补变量) {
  png(file.path(结果目录, paste0("B12_trace_", 变量名, ".png")),
      width = 1800, height = 1100, res = 160)
  print(plot(插补对象, y = 变量名, layout = c(2, 1)))
  dev.off()
}

# 密度图比较连续变量的观测值与插补值分布，每个变量单独一页。
pdf(file.path(结果目录, "B13_continuous_imputation_density_plots.pdf"), width = 10, height = 6)
print(mice::densityplot(插补对象, ~BMI2011))
print(mice::densityplot(插补对象, ~household_income))
dev.off()

# 分类变量分别作图，观察各插补链生成的类别分布。
pdf(file.path(结果目录, "B14_categorical_imputation_chain_plots.pdf"), width = 10, height = 6)
print(mice::stripplot(插补对象, Smoking_Status ~ .imp, pch = 20, cex = 0.55, jitter = TRUE))
print(mice::stripplot(插补对象, Drinking_Status ~ .imp, pch = 20, cex = 0.55, jitter = TRUE))
dev.off()

# 九、保存自动核验清单和复核结论 -------------------------------------------
记录事件 <- 插补对象$loggedEvents
记录事件行数 <- if (is.null(记录事件)) 0L else nrow(记录事件)
核验项目 <- data.frame(
  check = c(
    "MICE对象类型正确", "Part B输入与对象数据一致", "插补份数为20",
    "迭代次数为25", "风险集人数为15061", "事件数为1117",
    "全部插补数据人数和事件数一致", "插补变量在全部数据中无缺失",
    "loggedEvents为0", "原始观测值在全部插补数据中保持不变"
  ),
  passed = c(
    inherits(插补对象, "mids"), 输入数据一致, 插补对象$m == 20L,
    插补对象$iteration == 25L, nrow(插补对象$data) == 风险集人数,
    实际事件数 == 事件数预期,
    all(逐份核对表$n == 风险集人数 & 逐份核对表$events == 事件数预期),
    all(逐份核对表$missing_in_imputed_variables == 0L),
    记录事件行数 == 0L,
    all(观测值保持不变$all_observed_values_preserved)
  ),
  stringsAsFactors = FALSE
)
write.csv(核验项目,
          file.path(结果目录, "B15_PartB_automatic_checks.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

自动核验通过 <- all(核验项目$passed)
核验结论 <- c(
  "Part B 插补诊断复核",
  paste0("复核时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
  paste0("风险集人数：", nrow(插补对象$data)),
  paste0("事件数：", 实际事件数),
  paste0("插补份数：", 插补对象$m),
  paste0("迭代次数：", 插补对象$iteration),
  paste0("loggedEvents行数：", 记录事件行数),
  paste0("自动核验：", if (自动核验通过) "全部通过" else "存在未通过项目，请停止"),
  "人工阅图状态：待查看B12、B13、B14图形并记录结论。",
  "自动检查通过不代表链图和分布图已经通过人工判断。",
  paste0("结果目录：", 结果目录)
)
writeLines(核验结论,
           file.path(追溯目录, "B16_visual_review_and_audit_status.txt"), useBytes = TRUE)
cat(paste(核验结论, collapse = "\n"), "\n")
if (!自动核验通过) {
  stop("自动核验未全部通过。请查看B15清单并停止，不要进入Part C。")
}
