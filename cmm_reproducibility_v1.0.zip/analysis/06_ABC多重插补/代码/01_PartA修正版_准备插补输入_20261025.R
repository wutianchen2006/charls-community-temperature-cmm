# ==============================================================================
# ABC Part A：修正缺失诊断并准备MICE输入
#
# 研究目的：
#   1. 保持15,061人的冻结风险集不变；
#   2. 将家庭收入从字符型转换为数值型，保留负值；
#   3. 将分类协变量转换为因子，避免非响应分析把分类变量当作连续变量；
#   4. 重新输出缺失率、缺失模式和完整/不完整人群比较；
#   5. 生成Part B使用的插补输入副本。
#
# 本脚本不会修改原始母表、三源合并表或冻结风险集。
# 运行后必须看到：15,061人、1,117事件、完整7,167人、缺失7,894人。
# ==============================================================================

suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.utf8"))
options(stringsAsFactors = FALSE, encoding = "UTF-8")

if (!requireNamespace("digest", quietly = TRUE)) {
  stop("缺少digest包，请先在RStudio安装：install.packages('digest')")
}

项目根目录 <- Sys.getenv("P19_PROJECT_ROOT", unset = "analysis")
风险集路径 <- file.path(
  项目根目录, "02_人群纳排与风险集", "数据", "人群筛选_20261022",
  "2011_2020_CMM主风险集_年龄45岁及以上.rds"
)
本步骤目录 <- file.path(项目根目录, "06_ABC多重插补")
结果目录 <- file.path(本步骤目录, "结果", "Part_A_修正版缺失诊断")
数据目录 <- file.path(本步骤目录, "数据")
追溯目录 <- file.path(本步骤目录, "追溯文件", "Part_A_修正版_20261025")
for (路径 in c(结果目录, 数据目录, 追溯目录)) {
  dir.create(路径, recursive = TRUE, showWarnings = FALSE)
}

冻结哈希 <- "f199d6bb86ce49f43a652f57908020932382cb5cf989073ee171b4b92cca3131"
if (!file.exists(风险集路径)) stop("找不到冻结风险集：", 风险集路径)
实际哈希 <- digest::digest(风险集路径, file = TRUE, algo = "sha256")
if (!identical(实际哈希, 冻结哈希)) {
  stop("冻结风险集哈希不一致，脚本停止。记录值：", 冻结哈希, "；当前值：", 实际哈希)
}

风险集 <- readRDS(风险集路径)
stopifnot(nrow(风险集) == 15061L, sum(风险集$cmm_event) == 1117L,
          !anyDuplicated(as.character(风险集$ID)))

# 1. 把家庭收入转成数值 -----------------------------------------------
# 原始负值表示家庭负债，保留其数值含义；只有真正无法转换的非数值文本才停止。
收入原始 <- as.character(风险集$household_income)
收入数值 <- suppressWarnings(as.numeric(trimws(收入原始)))
非数值记录 <- !is.na(收入原始) & is.na(收入数值)
if (any(非数值记录)) {
  stop("家庭收入存在无法转换的非数值记录：",
       paste(unique(收入原始[非数值记录]), collapse = " | "))
}
风险集$household_income <- 收入数值

# 2. 固定分类变量类型和水平 -------------------------------------------
# 水平按项目数据字典固定；缺失值保持NA，不把缺失编码成一个正常类别。
转因子 <- function(x, levels) factor(as.character(x), levels = levels)
风险集$Gender <- 转因子(风险集$Gender, c("1", "2"))
风险集$Residence <- 转因子(风险集$Residence, c("1", "2"))
风险集$Education_Status <- 转因子(风险集$Education_Status, c("1", "2", "3"))
风险集$Marital_status <- 转因子(风险集$Marital_status, c("1", "2", "3"))
风险集$Smoking_Status <- 转因子(风险集$Smoking_Status, c("0", "1"))
风险集$Drinking_Status <- 转因子(风险集$Drinking_Status, c("0", "1", "2"))
风险集$Regional_Category_2011 <- factor(
  as.character(风险集$Regional_Category_2011),
  levels = c("East", "Midland", "West")
)
风险集$baseline_CMM_component_count <- 转因子(
  风险集$baseline_CMM_component_count, c("0", "1")
)

# 3. 固定Part B输入变量 -----------------------------------------------
# cmm_event和随访时间是结局信息，只作为插补预测变量，不会被插补。
# ID、社区键、省份键、个体权重和原始波次状态不进入MICE，避免插补身份或权重。
插补变量 <- c("BMI2011", "household_income", "Smoking_Status", "Drinking_Status")
完整预测变量 <- c(
  "Age", "Gender", "Residence", "Education_Status", "Marital_status",
  "Smoking_Status", "Drinking_Status", "Regional_Category_2011",
  "baseline_CMM_component_count", "BMI2011", "household_income",
  "built_Anum", "built_Bnum", "built_CEnum",
  "temperature_TV_daily_annual_mean_pre2011",
  "temperature_tmean_pre2011_mean_2008_2010",
  "temperature_dtr_pre2011_mean_2008_2010",
  "cmm_event", "time_from_2011_years", "analysis_end_wave"
)
if (!all(c(插补变量, 完整预测变量) %in% names(风险集))) {
  stop("风险集缺少Part B所需变量：",
       paste(setdiff(c(插补变量, 完整预测变量), names(风险集)), collapse = ", "))
}

插补输入 <- 风险集[, 完整预测变量, drop = FALSE]
插补输入$cmm_event <- factor(插补输入$cmm_event, levels = c(0, 1))
插补输入$analysis_end_wave <- factor(插补输入$analysis_end_wave, levels = 2:5)

# 4. Part A缺失率和缺失模式 -------------------------------------------
缺失率 <- data.frame(
  variable = names(插补输入),
  n = nrow(插补输入),
  missing = vapply(插补输入, function(x) sum(is.na(x)), integer(1)),
  observed = vapply(插补输入, function(x) sum(!is.na(x)), integer(1)),
  class = vapply(插补输入, function(x) paste(class(x), collapse = "/"), character(1)),
  stringsAsFactors = FALSE
)
缺失率$missing_percent <- 100 * 缺失率$missing / nrow(插补输入)
缺失率 <- 缺失率[order(-缺失率$missing_percent, 缺失率$variable), ]
write.csv(缺失率, file.path(结果目录, "A1_variable_missingness_corrected.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

缺失矩阵 <- as.data.frame(lapply(插补输入, is.na))
缺失模式 <- as.data.frame(table(
  apply(缺失矩阵, 1, function(x) paste(ifelse(x, "M", "O"), collapse = ""))
), stringsAsFactors = FALSE)
names(缺失模式) <- c("pattern", "n")
缺失模式$percent <- 100 * 缺失模式$n / nrow(插补输入)
缺失模式 <- 缺失模式[order(-缺失模式$n), ]
write.csv(缺失模式, file.path(结果目录, "A2_joint_missing_patterns_corrected.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

用于完整性判断 <- c(
  "Age", "Gender", "Residence", "Education_Status", "Marital_status",
  "Smoking_Status", "Drinking_Status", "Regional_Category_2011",
  "baseline_CMM_component_count", "BMI2011", "household_income",
  "built_Anum", "built_Bnum", "built_CEnum",
  "temperature_TV_daily_annual_mean_pre2011",
  "temperature_tmean_pre2011_mean_2008_2010",
  "temperature_dtr_pre2011_mean_2008_2010"
)
完整病例 <- complete.cases(插补输入[, 用于完整性判断, drop = FALSE])
完整性汇总 <- data.frame(
  status = c("Complete for selected analysis variables", "At least one selected variable missing"),
  n = c(sum(完整病例), sum(!完整病例)),
  percent = 100 * c(sum(完整病例), sum(!完整病例)) / nrow(插补输入)
)
write.csv(完整性汇总, file.path(结果目录, "A3_complete_incomplete_counts_corrected.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

# 5. 完整/不完整人群比较 ----------------------------------------------
完整状态 <- factor(完整病例, levels = c(FALSE, TRUE),
                  labels = c("Incomplete", "Complete"))
连续变量 <- names(插补输入)[vapply(插补输入, is.numeric, logical(1))]
分类变量 <- setdiff(names(插补输入), 连续变量)
连续变量 <- setdiff(连续变量, c("cmm_event", "analysis_end_wave"))

比较结果 <- list()
for (变量 in 连续变量) {
  x <- 插补输入[[变量]]
  p值 <- tryCatch(wilcox.test(x ~ 完整状态)$p.value, error = function(e) NA_real_)
  比较结果[[length(比较结果) + 1L]] <- data.frame(
    variable = 变量, type = "continuous", p_value = p值,
    stringsAsFactors = FALSE
  )
}
for (变量 in 分类变量) {
  x <- 插补输入[[变量]]
  tab <- table(x, 完整状态, useNA = "no")
  p值 <- tryCatch({
    if (any(tab < 5)) fisher.test(tab)$p.value else chisq.test(tab, correct = FALSE)$p.value
  }, error = function(e) NA_real_)
  比较结果[[length(比较结果) + 1L]] <- data.frame(
    variable = 变量, type = "categorical", p_value = p值,
    stringsAsFactors = FALSE
  )
}
write.csv(do.call(rbind, 比较结果),
          file.path(结果目录, "A4_complete_vs_incomplete_tests_corrected.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

# 6. 保存Part B输入和审计记录 -----------------------------------------
输入路径 <- file.path(数据目录, "PartB_MICE_input_prepared_20261025.rds")
saveRDS(插补输入, 输入路径)
write.csv(data.frame(
  variable = 完整预测变量,
  role = ifelse(完整预测变量 %in% 插补变量, "impute", "predictor_or_outcome"),
  stringsAsFactors = FALSE
), file.path(追溯目录, "PartB_variable_dictionary.csv"),
row.names = FALSE, fileEncoding = "UTF-8")

运行摘要 <- data.frame(
  input_sha256 = 实际哈希,
  risk_set_n = nrow(风险集),
  events = sum(风险集$cmm_event),
  imputation_variables = length(插补变量),
  analysis_variables = length(完整预测变量),
  complete_n = sum(完整病例),
  incomplete_n = sum(!完整病例),
  income_negative_n = sum(插补输入$household_income < 0, na.rm = TRUE),
  stringsAsFactors = FALSE
)
write.csv(运行摘要, file.path(结果目录, "A5_run_summary_corrected.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c(
  paste0("输入哈希：", 实际哈希),
  paste0("风险集：", nrow(风险集), "人；事件：", sum(风险集$cmm_event), "例"),
  paste0("完整：", sum(完整病例), "人；至少一项缺失：", sum(!完整病例), "人"),
  paste0("收入负值保留：", sum(插补输入$household_income < 0, na.rm = TRUE), "人"),
  "Part A修正版完成；冻结风险集未修改；尚未执行MICE。"
), file.path(追溯目录, "运行摘要.txt"), useBytes = TRUE)

cat("PART_A_CORRECTED_COMPLETE N=", nrow(风险集),
    " EVENTS=", sum(风险集$cmm_event),
    " COMPLETE=", sum(完整病例),
    " INCOMPLETE=", sum(!完整病例), "\n", sep = "")
