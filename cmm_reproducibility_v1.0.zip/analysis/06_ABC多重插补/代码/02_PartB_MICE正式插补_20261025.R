# ==============================================================================
# ABC Part B：MICE正式多重插补
#
# 输入：01_PartA修正版生成的PartB_MICE_input_prepared_20261025.rds。
# 设置：m=20，maxit=25，seed=20261025。
# 方法：BMI和家庭收入使用pmm；二分类吸烟使用logreg；三分类饮酒使用polyreg。
# 结局cmm_event和随访时间进入预测矩阵，但不被插补。
# 输出：mids对象、第一份完整数据、方法/诊断/哈希和图形。
#
# 本脚本不拟合Cox模型。模型分析必须在所有20份插补数据上分别拟合后再按
# Rubin规则合并，不能只使用第一份完整数据作为主结果。
# ==============================================================================

suppressWarnings(Sys.setlocale("LC_CTYPE", "Chinese_China.utf8"))
options(stringsAsFactors = FALSE, encoding = "UTF-8")

if (!requireNamespace("mice", quietly = TRUE)) {
  stop("缺少mice包，请先在RStudio安装：install.packages('mice')")
}
if (!requireNamespace("digest", quietly = TRUE)) {
  stop("缺少digest包，请先在RStudio安装：install.packages('digest')")
}

项目根目录 <- Sys.getenv("P19_PROJECT_ROOT", unset = "analysis")
输入路径 <- file.path(项目根目录, "06_ABC多重插补", "数据",
                    "PartB_MICE_input_prepared_20261025.rds")
结果目录 <- file.path(项目根目录, "06_ABC多重插补", "结果", "Part_B_MICE_20261025")
数据目录 <- file.path(项目根目录, "06_ABC多重插补", "数据")
追溯目录 <- file.path(项目根目录, "06_ABC多重插补", "追溯文件", "Part_B_MICE_20261025")
for (路径 in c(结果目录, 追溯目录)) {
  dir.create(路径, recursive = TRUE, showWarnings = FALSE)
}
if (!file.exists(输入路径)) {
  stop("找不到Part B输入，请先运行01_PartA修正版_准备插补输入_20261025.R：", 输入路径)
}

输入哈希 <- digest::digest(输入路径, file = TRUE, algo = "sha256")
输入数据 <- readRDS(输入路径)
stopifnot(nrow(输入数据) == 15061L,
          sum(as.integer(as.character(输入数据$cmm_event))) == 1117L)

插补变量 <- c("BMI2011", "household_income", "Smoking_Status", "Drinking_Status")
必要变量 <- c(
  "Age", "Gender", "Residence", "Education_Status", "Marital_status",
  "Smoking_Status", "Drinking_Status", "Regional_Category_2011",
  "baseline_CMM_component_count", "BMI2011", "household_income",
  "built_Anum", "built_Bnum", "built_CEnum",
  "temperature_TV_daily_annual_mean_pre2011",
  "temperature_tmean_pre2011_mean_2008_2010",
  "temperature_dtr_pre2011_mean_2008_2010",
  "cmm_event", "time_from_2011_years", "analysis_end_wave"
)
if (!all(必要变量 %in% names(输入数据))) {
  stop("Part B输入缺少变量：", paste(setdiff(必要变量, names(输入数据)), collapse = ", "))
}

# 1. 建立MICE数据集和方法 ---------------------------------------------
# MICE只处理这里的分析变量，不把ID、社区键、权重或原始波次变量带入。
mice_data <- 输入数据[, 必要变量, drop = FALSE]
mice_method <- mice::make.method(mice_data)
mice_method[] <- ""
mice_method["BMI2011"] <- "pmm"
mice_method["household_income"] <- "pmm"
mice_method["Smoking_Status"] <- "logreg"
mice_method["Drinking_Status"] <- "polyreg"

# 2. 设置预测矩阵 ------------------------------------------------------
# 每个需要插补的变量使用其余结局、暴露和协变量作为预测变量；对角线关闭。
预测矩阵 <- mice::make.predictorMatrix(mice_data)
预测矩阵[,] <- 0
for (变量 in 插补变量) {
  预测矩阵[变量, setdiff(必要变量, 变量)] <- 1
}
diag(预测矩阵) <- 0
# CEnum = Anum + Bnum，是精确线性组合。保留Bnum和CEnum，排除Anum作为
# 插补预测变量，避免MICE每轮因完全共线而记录loggedEvents。Anum仍保留在
# 插补数据中，后续以Anum为主要暴露时可单独拟合模型。
预测矩阵[插补变量, "built_Anum"] <- 0

write.csv(data.frame(variable = names(mice_method), method = unname(mice_method)),
          file.path(结果目录, "B1_imputation_methods.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(as.data.frame(预测矩阵), file.path(结果目录, "B2_predictor_matrix.csv"),
          row.names = TRUE, fileEncoding = "UTF-8")

# 3. 执行MICE ----------------------------------------------------------
# 固定随机种子，保证相同R版本和包版本下能够复现同一批插补链。
m值 <- 20L
迭代次数 <- 25L
随机种子 <- 20261025L
插补对象 <- mice::mice(
  data = mice_data,
  m = m值,
  maxit = 迭代次数,
  method = mice_method,
  predictorMatrix = 预测矩阵,
  seed = 随机种子,
  printFlag = TRUE
)

# 4. 检查MICE警告、收敛和插补后缺失 -------------------------------
记录事件 <- 插补对象$loggedEvents
if (is.null(记录事件)) {
  记录事件 <- data.frame(message = "No logged events")
}
write.csv(记录事件, file.path(结果目录, "B3_logged_events.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

完整数据1 <- mice::complete(插补对象, action = 1)
插补后缺失 <- data.frame(
  variable = names(完整数据1),
  missing = vapply(完整数据1, function(x) sum(is.na(x)), integer(1)),
  stringsAsFactors = FALSE
)
write.csv(插补后缺失, file.path(结果目录, "B4_completed_dataset1_missingness.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
if (any(插补后缺失$missing[插补后缺失$variable %in% 插补变量] > 0L)) {
  stop("正式插补后仍有插补变量缺失，停止交付。")
}

# 5. 保存插补对象和第一份完整数据 -------------------------------
# mids对象是后续Cox模型的主输入；第一份完整数据仅用于检查和敏感性分析。
saveRDS(插补对象, file.path(数据目录, "PartB_MICE_m20_maxit25_seed20261025.rds"),
        compress = TRUE)
saveRDS(完整数据1, file.path(数据目录, "PartB_complete_dataset_01_for_check_only.rds"),
        compress = TRUE)

# 6. 保存诊断图 --------------------------------------------------------
png(file.path(结果目录, "B5_trace_plots.png"), width = 1800, height = 1200, res = 160)
plot(插补对象)
dev.off()
png(file.path(结果目录, "B6_density_plots.png"), width = 1800, height = 1200, res = 160)
print(mice::densityplot(插补对象, ~BMI2011))
dev.off()

运行摘要 <- data.frame(
  input_sha256 = 输入哈希,
  risk_set_n = nrow(mice_data),
  events = sum(as.integer(as.character(mice_data$cmm_event))),
  m = m值,
  maxit = 迭代次数,
  seed = 随机种子,
  imputation_variables = length(插补变量),
  logged_event_rows = if (is.null(插补对象$loggedEvents)) 0L else nrow(插补对象$loggedEvents),
  stringsAsFactors = FALSE
)
write.csv(运行摘要, file.path(结果目录, "B7_run_summary.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c(
  paste0("输入哈希：", 输入哈希),
  paste0("风险集：", nrow(mice_data), "人；事件：", 运行摘要$events, "例"),
  paste0("m=", m值, "；maxit=", 迭代次数, "；seed=", 随机种子),
  paste0("loggedEvents行数：", 运行摘要$logged_event_rows),
  "mids对象已保存；后续模型必须在全部插补数据上拟合并按Rubin规则合并。"
), file.path(追溯目录, "运行摘要.txt"), useBytes = TRUE)

cat("PART_B_MICE_COMPLETE N=", nrow(mice_data),
    " EVENTS=", 运行摘要$events,
    " M=", m值,
    " LOGGED_EVENTS=", 运行摘要$logged_event_rows, "\n", sep = "")
