# ============================================================================
# 第十九篇预分析 | Part C：六个暴露的完整 M1、M2、M3
#
# 补齐气温 Tmean、DTR，并生成六个暴露的完整三模型结果：
#   气温：TV、Tmean、DTR；建成环境：Anum、Bnum、CEnum。
#
# 气温窗口固定为 2008--2010：这是 2011 基线访谈前的连续三年，保证暴露
# 先于基线和 2011--2020 随访结局；温度交付表也按该窗口提供汇总指标。
#
# M3 为修订口径：M2 + BMI2011 + Regional_Category_2011，删除
# baseline_CMM_component_count。旧完整 M3 不覆盖，保留在原结果目录追溯。
#
# 在 RStudio 打开本文件，点击 Source。脚本不修改原始表、风险集或插补对象。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
suppressPackageStartupMessages({
  library(survival)
  library(mice)
  library(digest)
})

项目根目录 <- Sys.getenv(
  "P19_PROJECT_ROOT",
  unset = Sys.getenv("P19_PROJECT_ROOT", unset = "analysis")
)
路径或默认值 <- function(环境变量名, 默认路径) {
  值 <- Sys.getenv(环境变量名, unset = "")
  if (nzchar(值)) 值 else 默认路径
}
风险集路径 <- 路径或默认值(
  "P19_CURRENT_RISKSET",
  file.path(项目根目录, "02_人群纳排与风险集/数据/人群筛选_20261022/2011_2020_CMM主风险集_年龄45岁及以上.rds")
)
插补对象路径 <- 路径或默认值(
  "P19_CURRENT_MIDS",
  file.path(项目根目录, "06_ABC多重插补/数据/PartB_MICE_m20_maxit25_seed20261025.rds")
)
结果目录 <- 路径或默认值(
  "P19_SIX_EXPOSURE_RESULTS",
  file.path(项目根目录, "07_模型分析/结果/Part_C_主模型_20261025_六暴露_M3修订")
)
追溯目录 <- 路径或默认值(
  "P19_SIX_EXPOSURE_TRACE",
  file.path(项目根目录, "07_模型分析/追溯文件/Part_C_主模型_20261025_六暴露_M3修订")
)
dir.create(结果目录, recursive = TRUE, showWarnings = FALSE)
dir.create(追溯目录, recursive = TRUE, showWarnings = FALSE)

if (any(!file.exists(c(风险集路径, 插补对象路径)))) {
  stop("缺少输入文件：", paste(c(风险集路径, 插补对象路径)[!file.exists(c(风险集路径, 插补对象路径))], collapse = "；"))
}

# 1. 输入门禁：冻结风险集和 Part B 设置必须保持不变 --------------------------
风险集 <- readRDS(风险集路径)
插补对象 <- readRDS(插补对象路径)
事件数值 <- function(x) suppressWarnings(as.integer(as.character(x)))
if (!inherits(插补对象, "mids")) stop("Part B 输入不是 mice 的 mids 对象。")
if (插补对象$m != 20L || 插补对象$iteration != 25L) stop("MICE 设置不是 m=20、maxit=25。")
if (nrow(风险集) != 15061L || sum(事件数值(风险集$cmm_event)) != 1117L) {
  stop("风险集不是 15,061 人、1,117 事件的冻结版本。")
}

# 2. 六个暴露和三个模型的协变量 -----------------------------------------------
暴露变量 <- c(
  TV = "temperature_TV_daily_annual_mean_pre2011",
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010",
  Anum = "built_Anum",
  Bnum = "built_Bnum",
  CEnum = "built_CEnum"
)
模型协变量 <- list(
  M1 = c("Age", "Gender", "Residence", "Education_Status"),
  M2 = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
         "Smoking_Status", "Drinking_Status", "household_income"),
  M3_revised = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
                 "Smoking_Status", "Drinking_Status", "household_income", "BMI2011",
                 "Regional_Category_2011")
)
必要变量 <- unique(c(unname(暴露变量), unlist(模型协变量),
                      "cmm_event", "time_from_2011_years"))
if (!all(必要变量 %in% names(插补对象$data))) {
  stop("Part B 对象缺少：", paste(setdiff(必要变量, names(插补对象$data)), collapse = "、"))
}

# 每个暴露的 IQR 只从冻结风险集计算一次，20份插补数据共享同一尺度。
IQR尺度 <- vapply(暴露变量, function(v) {
  x <- as.numeric(风险集[[v]])
  as.numeric(stats::quantile(x, .75, na.rm = TRUE, names = FALSE) -
               stats::quantile(x, .25, na.rm = TRUE, names = FALSE))
}, numeric(1))
if (any(!is.finite(IQR尺度) | IQR尺度 <= 0)) stop("至少一个暴露的 IQR 无效。")

# 3. 读取20份插补数据，验证固定列，并接回不插补的ID、社区和权重 ----------
插补完成数据 <- lapply(seq_len(插补对象$m), function(i) {
  d <- mice::complete(插补对象, action = i)
  if (nrow(d) != nrow(风险集)) stop("第", i, "份插补数据行数不符。")
  if (!identical(事件数值(d$cmm_event), 事件数值(风险集$cmm_event)) ||
      !isTRUE(all.equal(as.numeric(d$time_from_2011_years),
                        as.numeric(风险集$time_from_2011_years), check.attributes = FALSE))) {
    stop("第", i, "份插补数据的事件或随访时间与风险集不一致。")
  }
  for (v in unname(暴露变量)) {
    if (!isTRUE(all.equal(as.numeric(d[[v]]), as.numeric(风险集[[v]]), check.attributes = FALSE))) {
      stop("第", i, "份插补数据的固定暴露列被改变：", v)
    }
  }
  d$ID_fixed <- as.character(风险集$ID)
  d$community_id_fixed <- as.character(风险集$community_id)
  d$individual_weight_fixed <- as.numeric(风险集$individual_weight)
  d
})

# 4. 拟合加权、社区聚类 Cox 模型 ---------------------------------------------
拟合单个模型 <- function(d, 暴露名, 协变量名) {
  d$analysis_weight <- d$individual_weight_fixed / mean(d$individual_weight_fixed)
  d$exposure_IQR <- as.numeric(d[[暴露变量[[暴露名]]]]) / IQR尺度[[暴露名]]
  d$cmm_event_num <- 事件数值(d$cmm_event)
  公式 <- stats::as.formula(paste(
    "survival::Surv(time_from_2011_years, cmm_event_num) ~ exposure_IQR +",
    paste(协变量名, collapse = " + "), "+ cluster(community_id_fixed)"
  ))
  survival::coxph(formula = 公式, data = d, weights = analysis_weight,
                  ties = "efron", robust = TRUE,
                  na.action = stats::na.fail, x = TRUE)
}

# Rubin规则合并20份模型的系数、稳健方差、95% CI和P值。
Rubin合并 <- function(模型列表, 模型名, 暴露名) {
  系数名 <- names(stats::coef(模型列表[[1]]))
  if (any(!vapply(模型列表, function(f) identical(names(stats::coef(f)), 系数名), logical(1)))) {
    stop(模型名, " / ", 暴露名, " 的20份模型系数不一致。")
  }
  do.call(rbind, lapply(系数名, function(term) {
    q <- vapply(模型列表, function(f) unname(stats::coef(f)[term]), numeric(1))
    u <- vapply(模型列表, function(f) unname(stats::vcov(f)[term, term]), numeric(1))
    m <- length(q); qbar <- mean(q); within <- mean(u); between <- stats::var(q)
    total <- within + (1 + 1 / m) * between
    se <- sqrt(total)
    df <- if (between <= .Machine$double.eps) Inf else
      (m - 1) * (1 + within / ((1 + 1 / m) * between))^2
    statistic <- qbar / se
    p <- if (is.finite(df)) 2 * stats::pt(abs(statistic), df, lower.tail = FALSE) else
      2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
    crit <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
    data.frame(model = 模型名, exposure = 暴露名, term = term,
      imputations = m, beta = qbar, robust_SE = se, HR = exp(qbar),
      CI_95_low = exp(qbar - crit * se), CI_95_high = exp(qbar + crit * se),
      p_value = p, df = df, within_variance = within, between_variance = between,
      n = nrow(风险集), events = sum(事件数值(风险集$cmm_event)),
      communities = length(unique(风险集$community_id)),
      stringsAsFactors = FALSE)
  }))
}

# 5. 六个暴露 × 三个模型 = 18个模型 ------------------------------------------
结果列表 <- list()
审计列表 <- list()
for (暴露名 in names(暴露变量)) {
  for (模型名 in names(模型协变量)) {
    message("运行：", 模型名, " | ", 暴露名, " | 20份插补数据")
    模型列表 <- lapply(插补完成数据, 拟合单个模型,
                       暴露名 = 暴露名, 协变量名 = 模型协变量[[模型名]])
    结果列表[[paste(模型名, 暴露名, sep = "_")]] <- Rubin合并(模型列表, 模型名, 暴露名)
    审计列表[[paste(模型名, 暴露名, sep = "_")]] <- data.frame(
      model = 模型名, exposure = 暴露名, imputation = seq_along(模型列表),
      n = nrow(风险集), events = sum(事件数值(风险集$cmm_event)),
      communities = length(unique(风险集$community_id)),
      stringsAsFactors = FALSE
    )
  }
}
全部结果 <- do.call(rbind, 结果列表); rownames(全部结果) <- NULL
模型审计 <- do.call(rbind, 审计列表); rownames(模型审计) <- NULL
write.csv(全部结果, file.path(结果目录, "C01_六暴露_M1_M2_M3_Rubin合并全部系数.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
主效应 <- 全部结果[全部结果$term == "exposure_IQR", , drop = FALSE]
主效应$exposure_variable <- unname(暴露变量[主效应$exposure])
主效应$exposure_IQR <- unname(IQR尺度[主效应$exposure])
write.csv(主效应, file.path(结果目录, "C02_六暴露_M1_M2_M3_主要效应_HR每IQR.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(模型审计, file.path(追溯目录, "C01_18个模型_20份插补样本核验.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

if (nrow(模型审计) != 360L || any(模型审计$n != 15061L) ||
    any(模型审计$events != 1117L) || any(模型审计$communities != 446L)) {
  stop("18个模型的样本、事件或社区数未保持冻结值。")
}

# 6. 保存气温窗口、模型公式、输入哈希和运行日志 -------------------------------
writeLines(c(
  "气温暴露窗口：2008--2010，基线访谈年份为2011。",
  "选择理由：窗口先于基线和2011--2020随访，保持时间顺序并降低反向因果解释；温度源表按该三年提供Tmean、DTR和TV汇总指标。",
  "正式气温指标：TV（年内日均温标准差平均）、Tmean（年均温平均）、DTR（平均日较差）。",
  "TA为候选指标，使用2008--2020参照期，当前记录未核准为正式主暴露，本次未纳入。",
  "M1：年龄、性别、城乡、教育；M2：M1加婚姻、吸烟、饮酒、家庭收入。",
  "M3修订：M2加BMI2011和东中西区域；删除baseline_CMM_component_count。",
  "所有6个暴露均分别拟合M1、M2、M3，不把Anum、Bnum、CEnum同时放入同一模型。"
), file.path(追溯目录, "C02_气温窗口与模型公式说明.md"), useBytes = TRUE)

哈希记录 <- data.frame(
  file = c(风险集路径, 插补对象路径),
  sha256 = c(digest::digest(风险集路径, file = TRUE, algo = "sha256"),
             digest::digest(插补对象路径, file = TRUE, algo = "sha256")),
  stringsAsFactors = FALSE
)
write.csv(哈希记录, file.path(追溯目录, "C03_输入文件SHA256.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c(
  paste0("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
  paste0("风险集：", nrow(风险集), "人；事件：", sum(事件数值(风险集$cmm_event)),
         "例；社区：", length(unique(风险集$community_id))),
  paste0("MICE：m=", 插补对象$m, "；maxit=", 插补对象$iteration),
  "模型：6个暴露 × M1/M2/M3_revised，共18个模型；每个模型20份插补数据按Rubin规则合并。",
  "M3_revised不含baseline_CMM_component_count。",
  "运行完成标志：C01审计应有360行（18个模型×20份插补）。"
), file.path(追溯目录, "C04_运行闭环.txt"), useBytes = TRUE)
message("六暴露三模型完成：", 结果目录)
