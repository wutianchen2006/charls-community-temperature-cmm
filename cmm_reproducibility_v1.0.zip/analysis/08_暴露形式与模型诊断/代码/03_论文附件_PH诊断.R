# ============================================================================
# Step 08: publication supplement PH diagnostics
#
# 目的：将20份插补的完整PH诊断整理为论文附件可用的表格和汇总图。
# 原始PH检验图和残差数据不删除，继续保存在追溯文件夹。
# 运行方式：在RStudio中打开本脚本，设置下方环境变量后点击Source。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(svglite)
})

# 为避免Windows中文路径编码问题，正式运行时使用ASCII路径环境变量。
source_csv <- Sys.getenv("P19_PH_SOURCE_ASCII", unset = "")
result_dir <- Sys.getenv("P19_PH_ATTACHMENT_ASCII", unset = "")
trace_dir <- Sys.getenv("P19_PH_ATTACHMENT_TRACE_ASCII", unset = "")
ph_table_csv <- Sys.getenv("P19_PH_TABLE_ASCII", unset = "")

if (!nzchar(source_csv) || !nzchar(result_dir) || !nzchar(trace_dir) || !nzchar(ph_table_csv)) {
  stop("Please set P19_PH_SOURCE_ASCII, P19_PH_ATTACHMENT_ASCII, P19_PH_ATTACHMENT_TRACE_ASCII and P19_PH_TABLE_ASCII.")
}
if (!file.exists(source_csv) || !file.exists(ph_table_csv)) {
  stop("PH source file or PH result table does not exist.")
}
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(trace_dir, recursive = TRUE, showWarnings = FALSE)

# 读取逐份插补的PH检验表，并保留所有模型项及GLOBAL行。
ph <- fread(ph_table_csv, encoding = "UTF-8")
required_ph <- c("model", "exposure", "imputation", "term", "chisq", "p_value")
if (!all(required_ph %in% names(ph))) stop("PH result table is missing required columns.")
ph[, imputation := as.integer(imputation)]
ph[, term_type := ifelse(term == "exposure_IQR", "Main exposure", ifelse(term == "GLOBAL", "Global test", "Covariate"))]
ph[, term_label := fifelse(term == "exposure_IQR", "Exposure (per IQR)",
                           fifelse(term == "GLOBAL", "GLOBAL", term))]

# 统计所有模型项在20次插补中的P值范围和小于0.05的次数。
summary_table <- ph[, .(
  imputations = uniqueN(imputation),
  p_lt_0_05_n = sum(p_value < 0.05, na.rm = TRUE),
  p_lt_0_05_percent = 100 * mean(p_value < 0.05, na.rm = TRUE),
  p_min = min(p_value, na.rm = TRUE),
  p_median = median(p_value, na.rm = TRUE),
  p_max = max(p_value, na.rm = TRUE),
  chisq_median = median(chisq, na.rm = TRUE),
  n = 15061L,
  events = 1117L,
  diagnostic_cox = "unweighted_unclustered"
), by = .(exposure, model, term_type, term, term_label)]
setorder(summary_table, exposure, model, term_type, term)

# 写入CSV，作为论文附件表格的机器可读版本。
fwrite(summary_table, file.path(result_dir, "Supplementary_PH_Table_All_Terms.csv"), bom = TRUE)

# 同时写入便于直接查看的HTML表，不依赖额外办公软件。
html_path <- file.path(result_dir, "Supplementary_PH_Table_All_Terms.html")
html_table <- copy(summary_table)
html_table[, `:=`(
  p_lt_0_05_percent = sprintf("%.1f", p_lt_0_05_percent),
  p_min = sprintf("%.4f", p_min),
  p_median = sprintf("%.4f", p_median),
  p_max = sprintf("%.4f", p_max),
  chisq_median = sprintf("%.3f", chisq_median)
)]
html_table[, p_lt_0_05_percent := paste0(p_lt_0_05_percent, "%")]
names(html_table) <- c(
  "Exposure", "Model", "Term type", "Term", "Term label", "Imputations",
  "P < 0.05 (n)", "P < 0.05 (%)", "P min", "P median", "P max",
  "Median chi-square", "N", "Events", "Diagnostic Cox"
)
escape_html <- function(x) htmltools::htmlEscape(as.character(x))
header_html <- paste0("<tr>", paste0("<th>", escape_html(names(html_table)), "</th>", collapse = ""), "</tr>")
row_html <- apply(as.data.frame(html_table), 1L, function(one_row) {
  paste0("<tr>", paste0("<td>", escape_html(one_row), "</td>", collapse = ""), "</tr>")
})
html_lines <- c(
  "<!doctype html>", "<meta charset='utf-8'>",
  "<title>Supplementary PH diagnostics</title>",
  "<style>body{font-family:Arial,sans-serif} table{border-collapse:collapse;font-size:12px} th,td{border:1px solid #bbb;padding:4px 6px} th{background:#eaf2f8;position:sticky;top:0}</style>",
  "<h1>Supplementary PH diagnostics: all model terms</h1>",
  "<p>Each row summarizes 20 imputed datasets. P values are not averaged or Rubin-pooled.</p>",
  "<p>The diagnostic Cox model was unweighted and unclustered because cox.zph was numerically singular for the weighted clustered object. Primary effect models remain weighted and community-clustered.</p>",
  "<table>", header_html, row_html, "</table>"
)
writeLines(html_lines, html_path, useBytes = TRUE)

# 只读取主要暴露项，避免把所有协变量残差重复绘制到论文附件中。
residuals <- fread(source_csv, select = c(
  "transformed_time", "term", "schoenfeld_residual", "model", "exposure", "imputation"
), encoding = "UTF-8")
residuals <- residuals[term == "exposure_IQR"]
if (!nrow(residuals)) stop("No exposure Schoenfeld residuals found.")

# 每份插补先在相同的时间分箱内取中位数，再在20份插补之间汇总。
# 这样每份插补权重相同，不会因为某份插补的事件时间点更多而占优势。
residuals[, time_bin := pmin(80L, pmax(1L,
  ceiling(frank(transformed_time, ties.method = "average") / .N * 80L))),
  by = .(exposure, model, imputation)]
per_imputation <- residuals[, .(
  time = median(transformed_time, na.rm = TRUE),
  residual = median(schoenfeld_residual, na.rm = TRUE)
), by = .(exposure, model, imputation, time_bin)]
plot_data <- per_imputation[, .(
  time = median(time, na.rm = TRUE),
  residual_median = median(residual, na.rm = TRUE),
  residual_lower = quantile(residual, 0.025, na.rm = TRUE),
  residual_upper = quantile(residual, 0.975, na.rm = TRUE)
), by = .(exposure, model, time_bin)]

plot_data[, exposure := factor(exposure, levels = c("TV", "Tmean", "DTR", "Anum", "Bnum", "CEnum"))]
plot_data[, model := factor(model, levels = c("M1", "M2", "M3_revised"), labels = c("M1", "M2", "M3"))]

ph_plot <- ggplot(plot_data, aes(x = time, y = residual_median)) +
  geom_hline(yintercept = 0, linewidth = 0.3, colour = "grey45") +
  geom_ribbon(aes(ymin = residual_lower, ymax = residual_upper),
              fill = "#2C7FB8", alpha = 0.18, colour = NA) +
  geom_line(linewidth = 0.45, colour = "#145A86") +
  facet_grid(model ~ exposure, scales = "free_y") +
  labs(
    title = "Schoenfeld residual summary for the main exposure terms",
    subtitle = "Median residual across time bins; ribbon shows the 2.5th to 97.5th percentile across 20 imputations",
    x = "Transformed follow-up time",
    y = "Scaled Schoenfeld residual",
    caption = "Diagnostic Cox: unweighted and unclustered; formal PH results for all terms are reported in the supplementary table."
  ) +
  theme_minimal(base_size = 10) +
  theme(
    panel.grid.minor = element_blank(),
    strip.text = element_text(face = "bold"),
    plot.title = element_text(face = "bold"),
    plot.caption = element_text(size = 8, hjust = 0)
  )

ggsave(file.path(result_dir, "Supplementary_PH_Figure_Main_Exposure_Schoenfeld.pdf"),
       ph_plot, width = 15, height = 8.5, units = "in", device = cairo_pdf)
svglite::svglite(file.path(result_dir, "Supplementary_PH_Figure_Main_Exposure_Schoenfeld.svg"),
                 width = 15, height = 8.5)
print(ph_plot)
grDevices::dev.off()
ggsave(file.path(result_dir, "Supplementary_PH_Figure_Main_Exposure_Schoenfeld.png"),
       ph_plot, width = 15, height = 8.5, units = "in", dpi = 300)
fwrite(plot_data, file.path(trace_dir, "Supplementary_PH_Figure_Main_Exposure_Source.csv"), bom = TRUE)

# 保存可追溯说明，明确附件图是汇总图，不替代逐份原始图。
writeLines(c(
  "Publication supplement PH diagnostic package generated without changing analysis inputs.",
  "The table includes every exposure, model, covariate and GLOBAL term across 20 imputations.",
  "The figure includes main exposure terms only; each panel summarizes all 20 imputations.",
  "Full one-imputation-per-page PDFs remain in the original PH_Schoenfeld_plots audit directory.",
  "No PH P values were averaged or Rubin-pooled.",
  paste0("Rows in all-term table: ", nrow(summary_table), "; exposure-plot summary rows: ", nrow(plot_data), ".")
), file.path(trace_dir, "Supplementary_PH_package_readme.txt"), useBytes = TRUE)
message("Publication supplement PH diagnostics complete.")
