# ============================================================================
# Step 08-01: proportional-hazards (PH) diagnostics for 18 continuous Cox models
#
# 读取步骤07冻结的风险集和20份Part B插补数据，按相同权重、社区聚类和
# M1/M2/M3_revised公式重新拟合18个模型，并逐份运行 survival::cox.zph。
# PH诊断不修改数据、不删除样本；完成后才进入四分位数和趋势分析。
#
# 说明：代码和字符串使用ASCII；中文只保留在注释中，避免Windows R在UTF-8
# locale下的重编码问题。对象名清晰，适合初学者在RStudio点击Source。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
# Windows中文路径需要使用系统代码页读取；代码本身仍保持ASCII。
try(Sys.setlocale("LC_CTYPE", "Chinese_China.936"), silent = TRUE)
suppressPackageStartupMessages({
  library(survival)
  library(mice)
  library(digest)
})

# ggcoxzph用于按用户指定方法绘制Schoenfeld残差图。
# 如果绘图包缺失，仍完成数值检验，但必须在追溯日志中明确记录。
has_survminer <- requireNamespace("survminer", quietly = TRUE)

# 研究根目录是脚本运行时的工作目录：
# Configure the authorized local analysis root and explicit path overrides below.
project_root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
riskset_path <- Sys.getenv("P19_RISKSET_ASCII", unset = "")
mids_path <- Sys.getenv("P19_MIDS_ASCII", unset = "")
results_dir <- Sys.getenv("P19_RESULTS_ASCII", unset = "")
trace_dir <- Sys.getenv("P19_TRACE_ASCII", unset = "")

if (!nzchar(riskset_path) || !nzchar(mids_path) || !nzchar(results_dir) || !nzchar(trace_dir)) {
  # 在冻结目录中按唯一的ASCII文件名片段查找输入文件。
  riskset_candidates <- list.files(
    project_root, pattern = "2011_2020_CMM.*\\.rds$", recursive = TRUE,
    full.names = TRUE, ignore.case = TRUE
  )
  mids_candidates <- list.files(
    project_root, pattern = "PartB_MICE_m20_maxit25_seed20261025\\.rds$",
    recursive = TRUE, full.names = TRUE, ignore.case = TRUE
  )
  if (!nzchar(riskset_path) && length(riskset_candidates) == 1L) riskset_path <- riskset_candidates[1]
  if (!nzchar(mids_path) && length(mids_candidates) == 1L) mids_path <- mids_candidates[1]
  if (!nzchar(results_dir) || !nzchar(trace_dir)) {
    research_root <- list.dirs(project_root, full.names = TRUE, recursive = FALSE)
    research_root <- research_root[grepl("04_", basename(research_root))][1]
    if (is.na(research_root) || !nzchar(research_root)) stop("Cannot locate research directory.")
    step_root <- list.dirs(research_root, full.names = TRUE, recursive = FALSE)
    step_root <- step_root[grepl("08_", basename(step_root))][1]
    if (is.na(step_root) || !nzchar(step_root)) stop("Cannot locate step 08 directory.")
    step_subdirs <- list.dirs(step_root, full.names = TRUE, recursive = FALSE)
    if (!nzchar(results_dir)) results_dir <- file.path(step_subdirs[1], "01_PH_diagnostics_20261026")
    if (!nzchar(trace_dir)) trace_dir <- file.path(step_subdirs[1], "01_PH_diagnostics_20261026")
  }
}
if (!file.exists(riskset_path) || !file.exists(mids_path)) stop("Input file does not exist.")
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(trace_dir, recursive = TRUE, showWarnings = FALSE)

riskset <- readRDS(riskset_path)
mids_obj <- readRDS(mids_path)
event_numeric <- function(x) suppressWarnings(as.integer(as.character(x)))

if (!inherits(mids_obj, "mids") || mids_obj$m != 20L || mids_obj$iteration != 25L) {
  stop("MICE object or settings do not match the frozen plan.")
}
if (nrow(riskset) != 15061L || sum(event_numeric(riskset$cmm_event)) != 1117L) {
  stop("Risk set is not the frozen 15,061-person, 1,117-event version.")
}

exposure_vars <- c(
  TV = "temperature_TV_daily_annual_mean_pre2011",
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010",
  Anum = "built_Anum",
  Bnum = "built_Bnum",
  CEnum = "built_CEnum"
)
model_covariates <- list(
  M1 = c("Age", "Gender", "Residence", "Education_Status"),
  M2 = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
         "Smoking_Status", "Drinking_Status", "household_income"),
  M3_revised = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
                 "Smoking_Status", "Drinking_Status", "household_income", "BMI2011",
                 "Regional_Category_2011")
)
required_vars <- unique(c(
  unname(exposure_vars), unlist(model_covariates),
  "cmm_event", "time_from_2011_years"
))
if (!all(required_vars %in% names(mids_obj$data))) {
  stop("MICE object is missing required analysis variables.")
}

# 每份插补都必须与冻结风险集保持同一行顺序、事件、时间和暴露值。
completed_data <- lapply(seq_len(mids_obj$m), function(i) {
  d <- mice::complete(mids_obj, action = i)
  if (nrow(d) != nrow(riskset) ||
      !identical(event_numeric(d$cmm_event), event_numeric(riskset$cmm_event)) ||
      !isTRUE(all.equal(as.numeric(d$time_from_2011_years),
                        as.numeric(riskset$time_from_2011_years),
                        check.attributes = FALSE))) {
    stop("Completed data do not match the frozen risk set.")
  }
  for (v in unname(exposure_vars)) {
    if (!isTRUE(all.equal(as.numeric(d[[v]]), as.numeric(riskset[[v]]),
                          check.attributes = FALSE))) {
      stop("A fixed exposure column changed in completed data.")
    }
  }
  d$community_id_fixed <- as.character(riskset$community_id)
  d$individual_weight_fixed <- as.numeric(riskset$individual_weight)
  d
})

# cox.zph不支持当前加权、社区聚类稳健方差对象的稳定求解；
# 因此PH门禁使用同一风险集/暴露/协变量的未加权、未聚类Cox，仅检验时间比例假设。
# 这一步不替代Part C的加权、社区聚类主模型。
fit_ph <- function(d, exposure_name, covariate_names) {
  exposure_name_in_data <- exposure_vars[[exposure_name]]
  iqr_value <- as.numeric(
    quantile(as.numeric(riskset[[exposure_name_in_data]]), 0.75, na.rm = TRUE) -
      quantile(as.numeric(riskset[[exposure_name_in_data]]), 0.25, na.rm = TRUE)
  )
  if (!is.finite(iqr_value) || iqr_value <= 0) stop("Invalid exposure IQR.")
  d$exposure_IQR <- as.numeric(d[[exposure_name_in_data]]) / iqr_value
  d$cmm_event_num <- event_numeric(d$cmm_event)
  model_formula <- stats::as.formula(paste(
    "survival::Surv(time_from_2011_years, cmm_event_num) ~ exposure_IQR +",
    paste(covariate_names, collapse = "+")
  ))
  survival::coxph(
    model_formula, data = d, ties = "efron", robust = FALSE,
    na.action = stats::na.fail, x = TRUE
  )
}

ph_results <- list()
ph_residual_source <- list()
model_audit <- list()
ph_failures <- list()
ph_plot_failures <- list()
ph_plot_dir <- file.path(results_dir, "PH_Schoenfeld_plots")
dir.create(ph_plot_dir, recursive = TRUE, showWarnings = FALSE)
for (exposure_name in names(exposure_vars)) {
  for (model_name in names(model_covariates)) {
    message("PH diagnostic: ", model_name, " | ", exposure_name)
    fits <- lapply(
      completed_data, fit_ph,
      exposure_name = exposure_name,
      covariate_names = model_covariates[[model_name]]
    )
    for (i in seq_along(fits)) {
      z <- tryCatch(
        survival::cox.zph(fits[[i]], transform = "km", terms = TRUE, global = TRUE),
        error = function(err) {
          # 某些版本在terms=TRUE下因矩阵奇异失败；先按同一拟合对象使用terms=FALSE重试。
          tryCatch(
            survival::cox.zph(fits[[i]], transform = "km", terms = FALSE, global = TRUE),
            error = function(err2) {
              ph_failures[[length(ph_failures) + 1L]] <<- data.frame(
                model = model_name, exposure = exposure_name, imputation = i,
                error = conditionMessage(err2), stringsAsFactors = FALSE
              )
              NULL
            }
          )
        }
      )
      if (is.null(z)) next
      tab <- as.data.frame(z$table, stringsAsFactors = FALSE)
      tab$term <- rownames(tab)
      rownames(tab) <- NULL
      names(tab)[names(tab) == "p"] <- "p_value"
      rho_values <- if ("rho" %in% names(tab)) as.numeric(tab$rho) else rep(NA_real_, nrow(tab))
      chisq_values <- if ("chisq" %in% names(tab)) as.numeric(tab$chisq) else rep(NA_real_, nrow(tab))
      p_values <- if ("p_value" %in% names(tab)) as.numeric(tab$p_value) else rep(NA_real_, nrow(tab))
      ph_results[[length(ph_results) + 1L]] <- data.frame(
        model = model_name, exposure = exposure_name, imputation = i,
        term = tab$term, rho = rho_values,
        chisq = chisq_values, p_value = p_values,
        stringsAsFactors = FALSE
      )

      # 保存ggcoxzph使用的Schoenfeld残差源数据，便于逐点复核图形。
      # cox.zph的x是变换后的时间，y是各模型项的残差矩阵。
      residual_matrix <- as.matrix(z$y)
      if (is.null(dim(residual_matrix))) {
        residual_matrix <- matrix(residual_matrix, ncol = 1L)
      }
      residual_source <- do.call(rbind, lapply(seq_len(ncol(residual_matrix)), function(j) {
        term_names <- colnames(residual_matrix)
        current_term <- if (!is.null(term_names) && nzchar(term_names[j])) {
          term_names[j]
        } else {
          paste0("term_", j)
        }
        data.frame(
          transformed_time = as.numeric(z$x),
          term = current_term,
          schoenfeld_residual = as.numeric(residual_matrix[, j]),
          model = model_name, exposure = exposure_name, imputation = i,
          n = nrow(riskset), events = sum(event_numeric(riskset$cmm_event)),
          diagnostic_cox = "unweighted_unclustered",
          stringsAsFactors = FALSE
        )
      }))
      ph_residual_source[[length(ph_residual_source) + 1L]] <- residual_source

      # 用户要求保留PH检验图。每个暴露×模型输出一个多页PDF，20页分别对应20份插补。
      # 这样既不把不同插补的残差混在一起，也能直接追溯每一页的插补编号。
      if (has_survminer) {
        plot_path <- file.path(
          ph_plot_dir,
          paste0("PH_Schoenfeld_", exposure_name, "_", model_name, ".pdf")
        )
        if (i == 1L) grDevices::pdf(plot_path, width = 10, height = 8, onefile = TRUE)
        plot_ok <- tryCatch({
          p <- survminer::ggcoxzph(z)
          plot_caption <- paste0(
            "Exposure: ", exposure_name, " | Model: ", model_name,
            " | Imputation: ", i, " / ", mids_obj$m,
            " | n=", nrow(riskset), " | events=", sum(event_numeric(riskset$cmm_event)),
            " | diagnostic Cox: unweighted, unclustered"
          )
          if (inherits(p, "list")) {
            for (one_plot in p) {
              if (requireNamespace("ggplot2", quietly = TRUE)) {
                one_plot <- one_plot + ggplot2::labs(subtitle = plot_caption)
              }
              print(one_plot)
            }
          } else {
            if (requireNamespace("ggplot2", quietly = TRUE)) {
              p <- p + ggplot2::labs(subtitle = plot_caption)
            }
            print(p)
          }
          TRUE
        }, error = function(err) {
          ph_plot_failures[[length(ph_plot_failures) + 1L]] <<- data.frame(
            model = model_name, exposure = exposure_name, imputation = i,
            error = conditionMessage(err), stringsAsFactors = FALSE
          )
          FALSE
        })
        if (i == mids_obj$m && grDevices::dev.cur() != 1L) grDevices::dev.off()
      }
    }
    model_audit[[length(model_audit) + 1L]] <- data.frame(
      model = model_name, exposure = exposure_name, imputations = length(fits),
      ph_fit = "unweighted_unclustered",
      n = nrow(riskset), events = sum(event_numeric(riskset$cmm_event)),
      communities = length(unique(riskset$community_id)), stringsAsFactors = FALSE
    )
  }
}
ph_results <- do.call(rbind, ph_results)
model_audit <- do.call(rbind, model_audit)
write.csv(ph_results, file.path(results_dir, "PH_by_imputation_all_terms.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(model_audit, file.path(trace_dir, "PH_18_model_sample_audit.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
if (length(ph_failures)) {
  write.csv(do.call(rbind, ph_failures), file.path(trace_dir, "PH_failed_diagnostics.csv"),
            row.names = FALSE, fileEncoding = "UTF-8")
}
if (length(ph_plot_failures)) {
  write.csv(do.call(rbind, ph_plot_failures),
            file.path(trace_dir, "PH_plot_failed_diagnostics.csv"),
            row.names = FALSE, fileEncoding = "UTF-8")
}
if (length(ph_residual_source)) {
  residual_source_all <- do.call(rbind, ph_residual_source)
  write.csv(
    residual_source_all,
    file.path(trace_dir, "PH_Schoenfeld_residual_source_all.csv"),
    row.names = FALSE, fileEncoding = "UTF-8"
  )
}

# 报告20份插补中的最小、中位数、最大P值，不伪造Rubin合并PH检验。
global_ph <- ph_results[ph_results$term == "GLOBAL", , drop = FALSE]
summary_table <- do.call(rbind, lapply(
  split(global_ph, list(global_ph$model, global_ph$exposure)),
  function(x) data.frame(
    model = x$model[1], exposure = x$exposure[1], imputations = nrow(x),
    p_min = min(x$p_value, na.rm = TRUE),
    p_median = median(x$p_value, na.rm = TRUE),
    p_max = max(x$p_value, na.rm = TRUE), stringsAsFactors = FALSE
  )
))
summary_table$n <- 15061L
summary_table$events <- 1117L
summary_table$communities <- 446L
write.csv(summary_table, file.path(results_dir, "PH_global_test_pvalue_range.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

signals <- summary_table[summary_table$p_min < 0.05, , drop = FALSE]
failure_count <- length(ph_failures)
conclusion <- c(
  "This step is diagnostic only; no risk-set, event, follow-up, exposure, or imputation data were changed.",
  paste0("18 models x 20 imputations; fixed sample: ", nrow(riskset),
         " persons, ", sum(event_numeric(riskset$cmm_event)), " events, ",
         length(unique(riskset$community_id)), " communities."),
  "Global PH results are reported as the range across imputations; P values are not averaged without a prespecified method.",
  paste0("Models with at least one global PH P < 0.05: ", nrow(signals), "."),
  paste0("Failed PH diagnostic fits: ", failure_count, "."),
  paste0("Schoenfeld plot package available: ", has_survminer, "; plot failures: ", length(ph_plot_failures), "."),
  if (failure_count > 0) {
    "PH gate is not closed because one or more diagnostics failed; inspect PH_failed_diagnostics.csv before quartile/trend analysis."
  } else if (nrow(signals) == 0) {
    "No global PH signal was detected; proceed to quartile and trend analyses."
  } else {
    "A PH signal was detected; record the affected model/term before deciding on stratification or time interaction."
  }
)
writeLines(conclusion, file.path(results_dir, "PH_diagnostic_conclusion.txt"), useBytes = TRUE)
writeLines(c(
  paste0("Run time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
  paste0("Risk-set SHA256: ", digest::digest(riskset_path, file = TRUE, algo = "sha256")),
  paste0("MICE-object SHA256: ", digest::digest(mids_path, file = TRUE, algo = "sha256")),
  "Method: survival::cox.zph(transform='km', terms=TRUE, global=TRUE) on an unweighted, unclustered diagnostic Cox fit; primary Part C models remain weighted and community-clustered.",
  "Plots: survminer::ggcoxzph(), one multi-page PDF per exposure x model, with one page per imputation when plotting succeeds.",
  "Next gate: use the PH conclusion to decide whether quartile/trend analysis can start."
), file.path(trace_dir, "PH_run_trace.txt"), useBytes = TRUE)
message("PH diagnostics complete.")
