# ============================================================================
# 步骤08-04：六个暴露的四分位数KM曲线
#
# 本脚本只做描述性KM：使用冻结风险集、固定P25/P50/P75分组，绘制1-KM累计
# 事件概率。暴露、事件和随访时间均已冻结且不需要插补，因此不重复绘制20份
# MICE数据。死亡竞争风险另有步骤08-05，不能把本脚本的1-KM称为CIF。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
suppressPackageStartupMessages({
  library(survival)
  library(ggplot2)
  library(digest)
})

# 1. 路径 --------------------------------------------------------------------
project_root <- Sys.getenv("P19_PROJECT_ROOT", unset = "analysis")
riskset_default <- file.path(project_root, "02_人群纳排与风险集", "数据",
                             "人群筛选_20261022", "2011_2020_CMM主风险集_年龄45岁及以上.rds")
boundary_default <- file.path(project_root, "08_暴露形式与模型诊断", "结果",
                               "02_四分位数趋势_20261026", "quartile_boundaries.csv")
riskset_path <- Sys.getenv("P19_KM_RISKSET_ASCII", unset = riskset_default)
boundary_path <- Sys.getenv("P19_KM_BOUNDARY_ASCII", unset = boundary_default)
result_dir <- Sys.getenv("P19_KM_RESULT_ASCII", unset = file.path(project_root, "08_暴露形式与模型诊断", "结果", "04_KM_20261027"))
data_dir <- Sys.getenv("P19_KM_DATA_ASCII", unset = file.path(project_root, "08_暴露形式与模型诊断", "数据", "04_KM_20261027"))
trace_dir <- Sys.getenv("P19_KM_TRACE_ASCII", unset = file.path(project_root, "08_暴露形式与模型诊断", "追溯文件", "04_KM_20261027"))
publication_dir <- Sys.getenv("P19_KM_PUBLICATION_DIR_ASCII", unset = file.path(result_dir, "SCI发表图_20261027"))
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(trace_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(publication_dir, recursive = TRUE, showWarnings = FALSE)
if (!all(file.exists(c(riskset_path, boundary_path)))) stop("KM输入文件不存在。")

# 2. 输入门禁 ----------------------------------------------------------------
riskset <- readRDS(riskset_path)
boundaries <- read.csv(boundary_path, stringsAsFactors = FALSE, check.names = FALSE)
as_event <- function(x) suppressWarnings(as.integer(as.character(x)))
if (nrow(riskset) != 15061L || sum(as_event(riskset$cmm_event)) != 1117L) {
  stop("风险集不是冻结的15,061人、1,117例事件版本。")
}

exposure_vars <- c(
  TV = "temperature_TV_daily_annual_mean_pre2011",
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010",
  Anum = "built_Anum",
  Bnum = "built_Bnum",
  CEnum = "built_CEnum"
)
if (!all(names(exposure_vars) %in% boundaries$exposure)) stop("四分位数边界缺少暴露。")

# 3. 统一论文图形风格 ---------------------------------------------------------
group_colors <- c(Q1 = "#0072B2", Q2 = "#E69F00", Q3 = "#009E73", Q4 = "#CC79A7")
group_linetypes <- c(Q1 = "solid", Q2 = "dashed", Q3 = "dotdash", Q4 = "dotted")
time_ticks <- c(0, 2, 4, 6, 8, 9)
exposure_labels <- c(
  TV = "Temperature variability (TV)",
  Tmean = "Mean temperature (Tmean)",
  DTR = "Diurnal temperature range (DTR)",
  Anum = "Infrastructure score (Anum)",
  Bnum = "Community support score (Bnum)",
  CEnum = "Composite built environment score (CEnum)"
)

format_p <- function(x) {
  if (is.na(x)) return("NA")
  if (x < 0.001) return("<0.001")
  sprintf("%.3f", x)
}

make_km_plot <- function(curve_data, risk_data, exposure_name,
                         logrank_p = NA_real_, show_logrank = FALSE) {
  max_y <- max(curve_data$estimate, na.rm = TRUE)
  y_top <- max(0.10, ceiling(max_y * 1.20 / 0.05) * 0.05)
  curve_plot <- ggplot(curve_data, aes(time, estimate, color = group, linetype = group)) +
    geom_ribbon(aes(ymin = lower, ymax = upper, fill = group), alpha = 0.10,
                color = NA, show.legend = FALSE) +
    geom_step(linewidth = 0.75) +
    scale_color_manual(values = group_colors, name = "Exposure quartile") +
    scale_fill_manual(values = group_colors) +
    scale_linetype_manual(values = group_linetypes, name = "Exposure quartile") +
    scale_x_continuous(breaks = time_ticks, limits = c(0, 9), expand = c(0, 0)) +
    scale_y_continuous(limits = c(0, y_top), labels = function(x) paste0(round(100 * x), "%")) +
    labs(title = exposure_labels[[exposure_name]],
         subtitle = "Unadjusted, unweighted cumulative event probability (1-KM)",
         x = NULL, y = "Cumulative event probability (1-KM)") +
    theme_classic(base_size = 10) +
    theme(plot.title = element_text(face = "bold"),
          plot.subtitle = element_text(size = 8),
          legend.position = "top", legend.title = element_blank())

  risk_plot <- ggplot(risk_data, aes(time, group, label = n_risk, color = group)) +
    geom_text(size = 3, show.legend = FALSE) +
    scale_color_manual(values = group_colors) +
    scale_y_discrete(limits = rev(paste0("Q", 1:4))) +
    scale_x_continuous(breaks = time_ticks, limits = c(0, 9), expand = c(0, 0)) +
    labs(x = "Years since baseline (2011)", y = "Number at risk") +
    theme_classic(base_size = 9) +
    theme(axis.line.y = element_blank(), axis.ticks.y = element_blank(),
          legend.position = "none", plot.margin = margin(0, 10, 5, 10))

  if (requireNamespace("patchwork", quietly = TRUE)) {
    patchwork::wrap_plots(curve_plot, risk_plot, ncol = 1, heights = c(3, 1.0)) +
      patchwork::plot_annotation(caption = if (show_logrank)
        paste("Descriptive unweighted log-rank P =", format_p(logrank_p),
              "; deaths censored; weighted clustered Cox is primary.") else
        "Archival figure: deaths censored; weighted clustered Cox is primary.") &
      ggplot2::theme(plot.caption = element_text(hjust = 0, size = 8))
  } else {
    curve_plot
  }
}

# 4. 六个暴露逐一绘图 ---------------------------------------------------------
all_curves <- list()
all_risk <- list()
all_estimates <- list()
audit <- list()
logrank_tests <- list()

for (exposure_name in names(exposure_vars)) {
  b <- boundaries[boundaries$exposure == exposure_name, , drop = FALSE]
  cuts <- as.numeric(b[1, c("p25", "p50", "p75")])
  if (length(unique(cuts)) != 3L || any(!is.finite(cuts))) stop("边界无效：", exposure_name)
  x <- as.numeric(riskset[[exposure_vars[[exposure_name]]]])
  group <- cut(x, breaks = c(-Inf, cuts, Inf), labels = paste0("Q", 1:4), right = TRUE)
  group <- factor(group, levels = paste0("Q", 1:4))
  dat <- data.frame(time = as.numeric(riskset$time_from_2011_years),
                    event = as_event(riskset$cmm_event), group = group)
  if (anyNA(dat$group) || anyNA(dat$time) || anyNA(dat$event)) stop("KM输入出现缺失：", exposure_name)
  fit <- survival::survfit(survival::Surv(time, event) ~ group,
                           data = dat, conf.type = "log-log")
  logrank_fit <- survival::survdiff(survival::Surv(time, event) ~ group, data = dat)
  logrank_p <- stats::pchisq(logrank_fit$chisq,
                             df = length(logrank_fit$n) - 1L,
                             lower.tail = FALSE)
  logrank_tests[[exposure_name]] <- data.frame(
    exposure = exposure_name, test = "ordinary log-rank",
    statistic = unname(logrank_fit$chisq), df = length(logrank_fit$n) - 1L,
    p_value = logrank_p, n = nrow(dat), events = sum(dat$event),
    stringsAsFactors = FALSE
  )
  curve_summary <- summary(fit, censored = TRUE)
  curve_data <- data.frame(
    time = curve_summary$time,
    estimate = 1 - curve_summary$surv,
    lower = 1 - curve_summary$upper,
    upper = 1 - curve_summary$lower,
    group = sub("group=", "", as.character(curve_summary$strata)),
    stringsAsFactors = FALSE
  )
  curve_data <- rbind(data.frame(time = 0, estimate = 0, lower = 0, upper = 0,
                                 group = paste0("Q", 1:4)), curve_data)
  curve_data <- curve_data[order(curve_data$group, curve_data$time), ]
  risk_summary <- summary(fit, times = time_ticks, extend = TRUE)
  risk_data <- data.frame(time = risk_summary$time, n_risk = risk_summary$n.risk,
                          group = sub("group=", "", as.character(risk_summary$strata)),
                          stringsAsFactors = FALSE)
  nine_year <- summary(fit, times = 9, extend = TRUE)
  estimates <- data.frame(
    exposure = exposure_name,
    group = sub("group=", "", as.character(nine_year$strata)),
    time = 9,
    cumulative_event_probability = 1 - nine_year$surv,
    CI_95_low = 1 - nine_year$upper,
    CI_95_high = 1 - nine_year$lower,
    n_risk = nine_year$n.risk,
    stringsAsFactors = FALSE
  )
  all_curves[[exposure_name]] <- cbind(exposure = exposure_name, curve_data)
  all_risk[[exposure_name]] <- cbind(exposure = exposure_name, risk_data)
  all_estimates[[exposure_name]] <- estimates
  audit[[exposure_name]] <- data.frame(
    exposure = exposure_name, n = nrow(dat), events = sum(dat$event),
    q1_n = sum(group == "Q1"), q2_n = sum(group == "Q2"),
    q3_n = sum(group == "Q3"), q4_n = sum(group == "Q4"),
    p25 = cuts[1], p50 = cuts[2], p75 = cuts[3],
    stringsAsFactors = FALSE
  )

  p <- make_km_plot(curve_data, risk_data, exposure_name)
  p_publication <- make_km_plot(curve_data, risk_data, exposure_name,
                                logrank_p = logrank_p, show_logrank = TRUE)
  ggplot2::ggsave(file.path(result_dir, paste0("KM_", exposure_name, "_Q1_Q4.png")),
                  p, width = 7.2, height = 5.6, units = "in", dpi = 600, bg = "white")
  grDevices::cairo_pdf(file.path(result_dir, paste0("KM_", exposure_name, "_Q1_Q4.pdf")),
                       width = 7.2, height = 5.6)
  print(p)
  grDevices::dev.off()
  ggplot2::ggsave(file.path(publication_dir, paste0("KM_", exposure_name, "_Q1_Q4_Pvalues.png")),
                  p_publication, width = 7.2, height = 5.6, units = "in", dpi = 600, bg = "white")
  grDevices::cairo_pdf(file.path(publication_dir, paste0("KM_", exposure_name, "_Q1_Q4_Pvalues.pdf")),
                       width = 7.2, height = 5.6)
  print(p_publication)
  grDevices::dev.off()
  message("KM完成：", exposure_name)
}

# 5. 保存源数据、结果和追溯 ---------------------------------------------------
write.csv(do.call(rbind, all_curves), file.path(data_dir, "KM_curve_source_1_minus_KM.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, all_risk), file.path(data_dir, "KM_risk_table_source.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, all_estimates), file.path(result_dir, "KM_9_year_estimates.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
logrank_table <- do.call(rbind, logrank_tests)
write.csv(logrank_table, file.path(result_dir, "KM_logrank_p_values.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(logrank_table, file.path(publication_dir, "KM_logrank_p_values.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
file.copy(file.path(result_dir, "KM_9_year_estimates.csv"),
          file.path(publication_dir, "KM_9_year_estimates.csv"), overwrite = TRUE)
write.csv(do.call(rbind, audit), file.path(trace_dir, "KM_sample_and_boundary_audit.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(boundaries, file.path(data_dir, "KM_quartile_boundaries_used.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(data.frame(
  file = c(riskset_path, boundary_path),
  sha256 = c(digest::digest(riskset_path, file = TRUE, algo = "sha256"),
             digest::digest(boundary_path, file = TRUE, algo = "sha256")),
  stringsAsFactors = FALSE
), file.path(trace_dir, "KM_input_sha256.csv"), row.names = FALSE, fileEncoding = "UTF-8")

writeLines(c(
  paste0("Run time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
  paste0("Risk set: ", nrow(riskset), " persons; ", sum(as_event(riskset$cmm_event)), " events."),
  "Groups: frozen P25/P50/P75 boundaries from Step 08-02, shared by all six exposures.",
  "Estimator: unadjusted, unweighted 1-KM; time ticks 0, 2, 4, 6, 8, 9 years; risk table included.",
  "Ordinary log-rank P is now provided as a descriptive comparison in KM_logrank_p_values.csv and the SCI publication figures.",
  "Death competing risk is not estimated here; Step 08-05 applies the data gate."
), file.path(trace_dir, "KM_run_trace.txt"), useBytes = TRUE)
writeLines(c(
  "# Kaplan-Meier SCI publication figures",
  "",
  "This folder contains the publication versions of the six descriptive 1-KM figures.",
  "Each figure has four quartile curves (Q1-Q4), a risk table, and the ordinary log-rank P value.",
  "The log-rank P is descriptive and does not replace the weighted, community-clustered pooled Cox model.",
  "Death is treated as censoring in ordinary KM; competing-risk CIF is reported in the separate step 08-05 folder.",
  "KM_logrank_p_values.csv and KM_9_year_estimates.csv are the accompanying publication tables."
), file.path(publication_dir, "README.md"), useBytes = TRUE)
message("KM_ANALYSIS_COMPLETE")
