# ============================================================================
# 步骤08-05：死亡竞争风险敏感性分析
#
# 目的：在同一冻结风险集上，使用 CHARLS 文献常用的死亡时间规则，
#       估计 CMM 的累积发生函数（CIF），并绘制与 KM 图一致的 SCI 风格图。
#
# 死亡时间规则：
#   1. 有可用的阳历死亡日期时，使用死亡日期；
#   2. 日期缺失、历法为农历或日期不完整时，使用基线到首次死亡报告波次
#      之间的区间中点；这是文献中的估计时间，不是真实死亡日期；
#   3. 已先发生 CMM 的人不再计为死亡竞争事件，使用其 CMM 事件时间；
#   4. 没有 CMM、没有死亡报告者按最后有效随访时间删失。
#
# 主要 CIF 为未调整、未加权的描述性敏感性分析；主模型仍以步骤07的
# 加权、社区聚类 Cox 为准。Fine-Gray 和 cause-specific Cox 作为同一
# 代理死亡时间规则下的补充敏感性结果，不替代主模型。
#
# 运行：在 RStudio 打开本文件点击 Source。中文路径不稳定时，使用下列
# 环境变量指定 ASCII 临时路径：
# P19_CIF_RISKSET_ASCII, P19_CIF_TRACE_ASCII, P19_CIF_BOUNDARY_ASCII,
# P19_CIF_MIDS_ASCII, P19_CIF_RESULT_ASCII, P19_CIF_DATA_ASCII,
# P19_CIF_TRACE_OUT_ASCII, P19_CIF_PUBLICATION_DIR_ASCII。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
suppressPackageStartupMessages({
  library(survival)
  library(cmprsk)
  library(ggplot2)
  library(patchwork)
  library(mice)
  library(digest)
})

project_root <- Sys.getenv("P19_PROJECT_ROOT", unset = "analysis")
default_path <- function(env_name, default_value) {
  value <- Sys.getenv(env_name, unset = "")
  if (nzchar(value)) value else default_value
}

riskset_default <- file.path(project_root, "02_人群纳排与风险集/数据/人群筛选_20261022",
                              "2011_2020_CMM主风险集_年龄45岁及以上.rds")
trace_default <- file.path(project_root, "03_基线CMM与死亡失访核查/追溯文件/基线CMM与随访复核_20261024",
                            "participant_mortality_followup_trace.csv")
boundary_default <- file.path(project_root, "08_暴露形式与模型诊断/结果/02_四分位数趋势_20261026",
                               "quartile_boundaries.csv")
mids_default <- file.path(project_root, "06_ABC多重插补/数据/PartB_MICE_m20_maxit25_seed20261025.rds")
result_default <- file.path(project_root, "08_暴露形式与模型诊断/结果/05_竞争风险敏感性_20261027")
data_default <- file.path(project_root, "08_暴露形式与模型诊断/数据/05_竞争风险敏感性_20261027")
trace_out_default <- file.path(project_root, "08_暴露形式与模型诊断/追溯文件/05_竞争风险敏感性_20261027")

riskset_path <- default_path("P19_CIF_RISKSET_ASCII", riskset_default)
trace_path <- default_path("P19_CIF_TRACE_ASCII", trace_default)
boundary_path <- default_path("P19_CIF_BOUNDARY_ASCII", boundary_default)
mids_path <- default_path("P19_CIF_MIDS_ASCII", mids_default)
result_dir <- default_path("P19_CIF_RESULT_ASCII", result_default)
data_dir <- default_path("P19_CIF_DATA_ASCII", data_default)
trace_dir <- default_path("P19_CIF_TRACE_OUT_ASCII", trace_out_default)
publication_dir <- default_path("P19_CIF_PUBLICATION_DIR_ASCII", file.path(result_dir, "SCI发表图_20261027"))
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(trace_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(publication_dir, recursive = TRUE, showWarnings = FALSE)

required_files <- c(riskset_path, trace_path, boundary_path, mids_path)
if (any(!file.exists(required_files))) {
  stop("竞争风险分析缺少输入文件：", paste(required_files[!file.exists(required_files)], collapse = "；"))
}

# 1. 读取冻结输入并执行门禁 ----------------------------------------------------
riskset <- readRDS(riskset_path)
trace <- read.csv(trace_path, stringsAsFactors = FALSE, check.names = FALSE,
                  colClasses = c(ID = "character"))
boundaries <- read.csv(boundary_path, stringsAsFactors = FALSE, check.names = FALSE)
mids <- readRDS(mids_path)

as_num <- function(x) suppressWarnings(as.numeric(as.character(x)))
as_event <- function(x) suppressWarnings(as.integer(as.character(x)))
key <- function(x) sub("^0+", "", trimws(as.character(x)))
if (nrow(riskset) != 15061L || sum(as_event(riskset$cmm_event)) != 1117L) {
  stop("风险集不是冻结的15,061人、1,117例事件版本。")
}
if (!inherits(mids, "mids") || mids$m != 20L || mids$iteration != 25L) {
  stop("MICE对象不是冻结的m=20、maxit=25版本。")
}
trace_index <- match(key(riskset$ID), key(trace$ID))
if (anyNA(trace_index)) stop("有风险集ID无法匹配死亡随访追溯表。")
trace <- trace[trace_index, , drop = FALSE]
if (!identical(as_event(riskset$cmm_event), as_event(trace$event))) {
  stop("风险集事件与死亡随访追溯表不一致。")
}

# 2. 构建死亡时间：真实阳历日期优先，其余使用波次区间中点 ----------------------
# CHARLS随访波次对应的结束访视时间。部分死亡报告者没有该波次的个人访视
# 日期，因此使用该波次在风险集中的中位基线-访视间隔作为区间上界。
wave_duration_reference <- c(
  `2` = median(as_num(riskset$duration11_13), na.rm = TRUE),
  `3` = median(as_num(riskset$duration11_15), na.rm = TRUE),
  `4` = median(as_num(riskset$duration11_18), na.rm = TRUE),
  `5` = median(as_num(riskset$duration11_20), na.rm = TRUE)
)
wave <- trace$first_death_report_wave
wave_duration_months <- unname(wave_duration_reference[as.character(wave)])

valid_date <- !is.na(trace$death_year_exit2020) &
  trace$death_year_exit2020 >= 2011 & trace$death_year_exit2020 <= 2020 &
  trace$death_month_exit2020 %in% 1:12 & trace$death_day_exit2020 %in% 1:31
solar_date <- valid_date & trace$death_calendar_exit2020 %in% 1
death_date <- as.Date(rep(NA_character_, nrow(riskset)))
death_date[solar_date] <- as.Date(sprintf("%04d-%02d-%02d",
  trace$death_year_exit2020[solar_date], trace$death_month_exit2020[solar_date],
  trace$death_day_exit2020[solar_date]))
entry_date <- as.Date(as.character(riskset$entry_time11))
exact_time_years <- as.numeric(death_date - entry_date) / 365.25
midpoint_time_years <- wave_duration_months / 12 / 2

known_death <- isTRUE(trace$known_death_report) | trace$known_death_report %in% TRUE
death_candidate <- known_death & as_event(riskset$cmm_event) == 0L
death_time <- ifelse(solar_date, exact_time_years, midpoint_time_years)
death_source <- rep("not_a_death_event", nrow(riskset))
death_source[death_candidate & solar_date] <- "observed_solar_date"
death_source[death_candidate & !solar_date & valid_date] <- "wave_midpoint_lunar_or_calendar_missing"
death_source[death_candidate & !solar_date & !valid_date] <- "wave_midpoint_death_date_missing"

event_type <- rep(0L, nrow(riskset))
analysis_time <- as_num(riskset$time_from_2011_years)
event_type[as_event(riskset$cmm_event) == 1L] <- 1L
analysis_time[death_candidate] <- death_time[death_candidate]
event_type[death_candidate] <- 2L

if (any(!is.finite(analysis_time)) || any(analysis_time <= 0)) stop("存在无效的竞争风险时间。")
if (any(event_type == 2L & (!is.finite(analysis_time) | analysis_time > 9.5))) {
  stop("死亡代理时间超出2011--2020随访范围。")
}

event_audit <- data.frame(
  ID = as.character(riskset$ID),
  cmm_event = as_event(riskset$cmm_event),
  death_report = known_death,
  first_death_report_wave = trace$first_death_report_wave,
  death_calendar = trace$death_calendar_exit2020,
  death_year = trace$death_year_exit2020,
  death_month = trace$death_month_exit2020,
  death_day = trace$death_day_exit2020,
  event_type = event_type,
  analysis_time_years = analysis_time,
  death_time_source = death_source,
  stringsAsFactors = FALSE
)
write.csv(event_audit, file.path(data_dir, "CIF_event_time_proxy_by_ID.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

counts <- data.frame(
  item = c("risk_set_n", "cmm_events", "death_reports", "death_reports_after_excluding_prior_cmm",
           "death_events_observed_solar_date", "death_events_wave_midpoint", "censoring", "all_events"),
  value = c(nrow(riskset), sum(event_type == 1L), sum(known_death), sum(death_candidate),
            sum(event_type == 2L & death_source == "observed_solar_date"),
            sum(event_type == 2L & death_source != "observed_solar_date"),
            sum(event_type == 0L), sum(event_type != 0L)),
  stringsAsFactors = FALSE
)
write.csv(counts, file.path(result_dir, "CIF_event_definition_counts.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

# 3. 六个暴露的四分位数 CIF ----------------------------------------------------
exposure_vars <- c(
  TV = "temperature_TV_daily_annual_mean_pre2011",
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010",
  Anum = "built_Anum", Bnum = "built_Bnum", CEnum = "built_CEnum"
)
group_colors <- c(Q1 = "#0072B2", Q2 = "#E69F00", Q3 = "#009E73", Q4 = "#CC79A7")
group_linetypes <- c(Q1 = "solid", Q2 = "dashed", Q3 = "dotdash", Q4 = "dotted")
time_ticks <- c(0, 2, 4, 6, 8, 9)
exposure_labels <- c(
  TV = "Temperature variability (TV)",
  Tmean = "Mean temperature (Tmean)",
  DTR = "Diurnal temperature range (DTR)",
  Anum = "Infrastructure score (Anum)",
  Bnum = "Community support score (Bnum)",
  CEnum = "Composite built environment score (CEnum)"
)

extract_cif <- function(fit, exposure_name, cause_code, group_levels) {
  wanted <- paste0(group_levels, " ", cause_code)
  pieces <- lapply(wanted, function(nm) {
    obj <- fit[[nm]]
    if (is.null(obj)) return(NULL)
    est <- as.numeric(obj$est)
    se <- sqrt(as.numeric(obj$var))
    data.frame(time = as.numeric(obj$time), estimate = est,
               lower = pmax(0, est - 1.96 * se),
               upper = pmin(1, est + 1.96 * se),
               group = sub(paste0(" ", cause_code, "$"), "", nm),
               cause = cause_code, exposure = exposure_name,
               stringsAsFactors = FALSE)
  })
  out <- do.call(rbind, pieces)
  rbind(data.frame(time = 0, estimate = 0, lower = 0, upper = 0,
                   group = group_levels, cause = cause_code, exposure = exposure_name), out)
}

format_p <- function(x) {
  if (is.na(x)) return("NA")
  if (x < 0.001) return("<0.001")
  sprintf("%.3f", x)
}

make_cif_panel <- function(curve_data, exposure_name, cause_label,
                           gray_p = NA_real_, show_p = FALSE) {
  ggplot(curve_data, aes(time, estimate, color = group, linetype = group)) +
    geom_ribbon(aes(ymin = lower, ymax = upper, fill = group), alpha = 0.10,
                color = NA, show.legend = FALSE) +
    geom_step(linewidth = 0.75) +
    scale_color_manual(values = group_colors, name = "Exposure quartile") +
    scale_fill_manual(values = group_colors) +
    scale_linetype_manual(values = group_linetypes, name = "Exposure quartile") +
    scale_x_continuous(breaks = time_ticks, limits = c(0, 9), expand = c(0, 0)) +
    scale_y_continuous(labels = function(x) paste0(round(100 * x), "%")) +
    labs(title = cause_label,
         subtitle = if (show_p) paste0("Gray's test P = ", format_p(gray_p)) else NULL,
         x = NULL, y = "Cumulative incidence") +
    theme_classic(base_size = 10) +
    theme(plot.title = element_text(face = "bold"), plot.subtitle = element_text(size = 8),
          legend.position = "top",
          legend.title = element_blank())
}

all_cif <- list(); all_risk <- list(); all_estimates <- list()
gray_tests <- list()
for (exposure_name in names(exposure_vars)) {
  boundary <- boundaries[boundaries$exposure == exposure_name, , drop = FALSE]
  cuts <- as.numeric(boundary[1, c("p25", "p50", "p75")])
  x <- as_num(riskset[[exposure_vars[[exposure_name]]]])
  group <- cut(x, breaks = c(-Inf, cuts, Inf), labels = paste0("Q", 1:4), right = TRUE)
  group <- factor(group, levels = paste0("Q", 1:4))
  if (anyNA(group)) stop("暴露四分位数分组存在缺失：", exposure_name)
  cif_fit <- cmprsk::cuminc(ftime = analysis_time, fstatus = event_type,
                            group = group, cencode = 0)
  # cuminc() 的 Tests 表给出按暴露四分位数比较的 Gray 检验。
  # CMM 和死亡分别检验；删失不是第三个竞争事件曲线。
  gray_p <- c(CMM = NA_real_, Death = NA_real_)
  if (!is.null(cif_fit$Tests)) {
    test_rows <- rownames(cif_fit$Tests)
    for (cause_code in c("1", "2")) {
      row_index <- which(test_rows == cause_code)
      if (length(row_index) == 0L) {
        row_index <- grep(paste0("(^| )", cause_code, "$"), test_rows)
      }
      if (length(row_index) > 0L) {
        gray_p[if (cause_code == "1") "CMM" else "Death"] <-
          as.numeric(cif_fit$Tests[row_index[1], "pv"])
      }
    }
  }
  gray_tests[[exposure_name]] <- data.frame(
    exposure = exposure_name, cmm_gray_p = gray_p[["CMM"]],
    cmm_gray_p_display = format_p(gray_p[["CMM"]]),
    death_gray_p = gray_p[["Death"]],
    death_gray_p_display = format_p(gray_p[["Death"]]),
    n = nrow(riskset),
    cmm_events = sum(event_type == 1L), death_events = sum(event_type == 2L),
    stringsAsFactors = FALSE
  )
  curve_cmm <- extract_cif(cif_fit, exposure_name, 1, levels(group))
  curve_death <- extract_cif(cif_fit, exposure_name, 2, levels(group))
  curve_all <- rbind(curve_cmm, curve_death)
  all_cif[[exposure_name]] <- curve_all

  risk_fit <- survival::survfit(survival::Surv(analysis_time, event_type != 0L) ~ group)
  risk_summary <- summary(risk_fit, times = time_ticks, extend = TRUE)
  risk_data <- data.frame(time = risk_summary$time, n_risk = risk_summary$n.risk,
                          group = sub("group=", "", as.character(risk_summary$strata)),
                          exposure = exposure_name, stringsAsFactors = FALSE)
  all_risk[[exposure_name]] <- risk_data

  nine <- do.call(rbind, lapply(list(CMM = curve_cmm, Death = curve_death), function(z) {
    z <- z[which.min(abs(z$time - 9)), , drop = FALSE]
    data.frame(exposure = exposure_name, cause = unique(z$cause), group = z$group,
               time = z$time, CIF = z$estimate, CI_95_low = z$lower,
               CI_95_high = z$upper, stringsAsFactors = FALSE)
  }))
  all_estimates[[exposure_name]] <- nine

  p1 <- make_cif_panel(curve_cmm, exposure_name, "CMM incidence; death as competing event")
  p2 <- make_cif_panel(curve_death, exposure_name, "Death incidence; CMM as competing event")
  p1_publication <- make_cif_panel(curve_cmm, exposure_name,
                                   "CMM incidence; death as competing event",
                                   gray_p = gray_p[["CMM"]], show_p = TRUE)
  p2_publication <- make_cif_panel(curve_death, exposure_name,
                                   "Death incidence; CMM as competing event",
                                   gray_p = gray_p[["Death"]], show_p = TRUE)
  risk_plot <- ggplot(risk_data, aes(time, group, label = n_risk, color = group)) +
    geom_text(size = 3, show.legend = FALSE) + scale_color_manual(values = group_colors) +
    scale_y_discrete(limits = rev(paste0("Q", 1:4))) +
    scale_x_continuous(breaks = time_ticks, limits = c(0, 9), expand = c(0, 0)) +
    labs(x = "Years since baseline (2011)", y = "Number at risk") + theme_classic(base_size = 9) +
    theme(axis.line.y = element_blank(), axis.ticks.y = element_blank(), legend.position = "none")
  p <- (p1 / p2 / risk_plot) + plot_layout(heights = c(3, 3, 1.0)) +
    plot_annotation(title = exposure_labels[[exposure_name]],
      caption = "Unweighted CIF sensitivity analysis; death time partly uses a CHARLS wave-midpoint proxy.") &
    ggplot2::theme(plot.caption = element_text(hjust = 0, size = 8))
  ggsave(file.path(result_dir, paste0("CIF_", exposure_name, "_Q1_Q4.png")), p,
         width = 7.2, height = 9.2, units = "in", dpi = 600, bg = "white")
  grDevices::cairo_pdf(file.path(result_dir, paste0("CIF_", exposure_name, "_Q1_Q4.pdf")),
                       width = 7.2, height = 9.2); print(p); grDevices::dev.off()
  p_publication <- (p1_publication / p2_publication / risk_plot) +
    plot_layout(heights = c(3, 3, 1.0)) +
    plot_annotation(title = exposure_labels[[exposure_name]],
      caption = "Unweighted CIF sensitivity analysis; death time partly uses a CHARLS wave-midpoint proxy.") &
    ggplot2::theme(plot.caption = element_text(hjust = 0, size = 8))
  ggplot2::ggsave(file.path(publication_dir, paste0("CIF_", exposure_name, "_Q1_Q4_Pvalues.png")),
                  p_publication, width = 7.2, height = 9.2, units = "in", dpi = 600, bg = "white")
  grDevices::cairo_pdf(file.path(publication_dir, paste0("CIF_", exposure_name, "_Q1_Q4_Pvalues.pdf")),
                       width = 7.2, height = 9.2); print(p_publication); grDevices::dev.off()
  message("CIF完成：", exposure_name)
}
write.csv(do.call(rbind, all_cif), file.path(data_dir, "CIF_curve_source.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, all_risk), file.path(data_dir, "CIF_risk_table_source.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, all_estimates), file.path(result_dir, "CIF_9_year_estimates.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
gray_table <- do.call(rbind, gray_tests)
write.csv(gray_table, file.path(result_dir, "CIF_gray_test_p_values.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(gray_table, file.path(publication_dir, "CIF_gray_test_p_values.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
file.copy(file.path(result_dir, "CIF_9_year_estimates.csv"),
          file.path(publication_dir, "CIF_9_year_estimates.csv"), overwrite = TRUE)

# 4. 在20份插补数据上进行补充 cause-specific Cox 与 Fine-Gray ------------------
model_covariates <- list(
  M1 = c("Age", "Gender", "Residence", "Education_Status"),
  M2 = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
         "Smoking_Status", "Drinking_Status", "household_income"),
  M3 = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
         "Smoking_Status", "Drinking_Status", "household_income", "BMI2011",
         "Regional_Category_2011")
)
mi_data <- lapply(seq_len(mids$m), function(i) {
  d <- mice::complete(mids, action = i)
  if (nrow(d) != nrow(riskset)) stop("插补数据行数不符：第", i, "份")
  d$analysis_time <- analysis_time
  d$event_type <- event_type
  d$community_id_fixed <- as.character(riskset$community_id)
  d
})
iqr_value <- vapply(exposure_vars, function(v) {
  as.numeric(quantile(as_num(riskset[[v]]), .75, na.rm = TRUE) -
               quantile(as_num(riskset[[v]]), .25, na.rm = TRUE))
}, numeric(1))

rubin_pool <- function(estimates, variances, exposure_name, model_name, analysis_name) {
  terms <- names(estimates[[1]])
  do.call(rbind, lapply(terms, function(term) {
    q <- vapply(estimates, function(x) unname(x[term]), numeric(1))
    u <- vapply(variances, function(x) unname(x[term, term]), numeric(1))
    m <- length(q); qbar <- mean(q); within <- mean(u); between <- stats::var(q)
    total <- within + (1 + 1 / m) * between; se <- sqrt(total)
    df <- if (between <= .Machine$double.eps) Inf else (m - 1) *
      (1 + within / ((1 + 1 / m) * between))^2
    stat <- qbar / se
    p <- if (is.finite(df)) 2 * stats::pt(abs(stat), df, lower.tail = FALSE) else
      2 * stats::pnorm(abs(stat), lower.tail = FALSE)
    crit <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
    data.frame(analysis = analysis_name, model = model_name, exposure = exposure_name,
      term = term, imputations = m, beta = qbar, SE = se, HR = exp(qbar),
      CI_95_low = exp(qbar - crit * se), CI_95_high = exp(qbar + crit * se),
      p_value = p, df = df, stringsAsFactors = FALSE)
  }))
}

cs_results <- list(); fg_results <- list(); model_audit <- list()
for (exposure_name in names(exposure_vars)) {
  for (model_name in names(model_covariates)) {
    exposure_column <- exposure_vars[[exposure_name]]
    covars <- model_covariates[[model_name]]
    cs_est <- list(); cs_var <- list(); fg_est <- list(); fg_var <- list()
    for (imp in seq_len(mids$m)) {
      d <- mi_data[[imp]]
      d$exposure_IQR <- as_num(d[[exposure_column]]) / iqr_value[[exposure_name]]
      # cause-specific Cox：死亡在死亡时间作为删失。
      cs_formula <- stats::as.formula(paste(
        "survival::Surv(analysis_time, event_type == 1) ~ exposure_IQR +",
        paste(covars, collapse = " + ")))
      cs_fit <- survival::coxph(cs_formula, data = d, ties = "efron",
                                 na.action = stats::na.fail, x = TRUE)
      cs_est[[imp]] <- stats::coef(cs_fit); cs_var[[imp]] <- stats::vcov(cs_fit)
      # Fine-Gray：cmprsk不提供个体权重或社区聚类接口，故本结果明确为
      # 未加权、未聚类的补充敏感性分析，不替代主模型。
      # 先保留截距生成标准处理编码，再删除截距；不能使用~0+因子，
      # 否则二分类变量会同时保留两个完整哑变量而使crr矩阵奇异。
      fg_matrix <- stats::model.matrix(stats::as.formula(paste(
        "~ exposure_IQR +", paste(covars, collapse = " + "))), data = d)[, -1, drop = FALSE]
      fg_fit <- cmprsk::crr(ftime = d$analysis_time, fstatus = d$event_type,
                             cov1 = fg_matrix, failcode = 1, cencode = 0,
                             maxiter = 50)
      # cmprsk::crr() 返回的方差矩阵有时没有 dimnames；先补齐变量名，
      # 这样后面的 Rubin 合并可以安全地按 term 名称提取方差。
      fg_names <- names(fg_fit$coef)
      if (is.null(fg_names)) fg_names <- colnames(fg_matrix)
      fg_est[[imp]] <- stats::setNames(as.numeric(fg_fit$coef), fg_names)
      fg_var_matrix <- as.matrix(fg_fit$var)
      dimnames(fg_var_matrix) <- list(fg_names, fg_names)
      fg_var[[imp]] <- fg_var_matrix
      model_audit[[length(model_audit) + 1L]] <- data.frame(
        analysis = "competing_risk_models", model = model_name, exposure = exposure_name,
        imputation = imp, n = nrow(d), cmm_events = sum(d$event_type == 1L),
        death_competing = sum(d$event_type == 2L), censor = sum(d$event_type == 0L),
        stringsAsFactors = FALSE)
    }
    cs_results[[length(cs_results) + 1L]] <- rubin_pool(cs_est, cs_var, exposure_name,
                                                         model_name, "cause_specific_Cox")
    fg_results[[length(fg_results) + 1L]] <- rubin_pool(fg_est, fg_var, exposure_name,
                                                         model_name, "Fine_Gray")
  }
}
write.csv(do.call(rbind, cs_results), file.path(result_dir, "cause_specific_Cox_Rubin.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, fg_results), file.path(result_dir, "Fine_Gray_Rubin.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
file.copy(file.path(result_dir, "cause_specific_Cox_Rubin.csv"),
          file.path(publication_dir, "cause_specific_Cox_Rubin.csv"), overwrite = TRUE)
file.copy(file.path(result_dir, "Fine_Gray_Rubin.csv"),
          file.path(publication_dir, "Fine_Gray_Rubin.csv"), overwrite = TRUE)
write.csv(do.call(rbind, model_audit), file.path(trace_dir, "competing_risk_model_audit.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

# 5. 保存输入哈希、运行记录和复现状态 -----------------------------------------
input_files <- c(riskset_path, trace_path, boundary_path, mids_path)
write.csv(data.frame(file = input_files,
                     sha256 = vapply(input_files, digest::digest, character(1), file = TRUE, algo = "sha256")),
          file.path(trace_dir, "CIF_input_sha256.csv"), row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c(
  paste0("Run time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
  "Method: observed solar death date when available; otherwise CHARLS wave-interval midpoint.",
  "Event coding: 0=censoring, 1=new CMM, 2=death before observed CMM.",
  paste0("Risk set: ", nrow(riskset), " persons; CMM events: ", sum(event_type == 1L),
         "; death competing events: ", sum(event_type == 2L), "; censoring: ", sum(event_type == 0L), "."),
  "CIF: unadjusted and unweighted descriptive sensitivity analysis.",
  "Cause-specific Cox and Fine-Gray: 20 MICE datasets; unweighted and non-clustered supplementary sensitivity analyses.",
  "The wave midpoint is an estimated time and is not presented as an exact death date."
), file.path(trace_dir, "CIF_run_trace.txt"), useBytes = TRUE)
writeLines(c(
  "# Competing-risk SCI publication figures and tables",
  "",
  "This folder contains six publication CIF figures, each with two event panels:",
  "CMM incidence with death as the competing event, and death incidence with CMM as the competing event.",
  "Each panel contains four exposure-quartile curves (Q1-Q4). Censoring is not a third curve.",
  "Gray's test P values are shown in the two event panels and saved in CIF_gray_test_p_values.csv.",
  "CIF_9_year_estimates.csv, cause_specific_Cox_Rubin.csv and Fine_Gray_Rubin.csv are the accompanying tables.",
  "Death time is partly a CHARLS wave-interval midpoint proxy; these are sensitivity results, not the primary analysis."
), file.path(publication_dir, "README.md"), useBytes = TRUE)
message("COMPETING_RISK_CIF_COMPLETE")
