# ============================================================================
# Step 08-02: quartile and trend analyses for six exposures
#
# 天桥老师方法：P25/P50/P75只从冻结风险集的观测暴露计算；20份插补共用同一
# 组断点，不能使用ntile拆开相同值。每份插补使用加权、社区聚类Cox，最后按
# Rubin规则合并系数、标准误和P值。M3使用修订版，不含baseline CMM count。
#
# 代码和字符串使用ASCII；中文只在注释中出现，避免Windows R重编码问题。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
suppressPackageStartupMessages({
  library(survival)
  library(mice)
  library(digest)
})

project_root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
riskset_path <- Sys.getenv("P19_RISKSET_ASCII", unset = "")
mids_path <- Sys.getenv("P19_MIDS_ASCII", unset = "")
results_dir <- Sys.getenv("P19_QUARTILE_RESULTS_ASCII", unset = "")
trace_dir <- Sys.getenv("P19_QUARTILE_TRACE_ASCII", unset = "")
if (!nzchar(riskset_path) || !nzchar(mids_path) || !nzchar(results_dir) || !nzchar(trace_dir)) {
  stop("Set P19_RISKSET_ASCII, P19_MIDS_ASCII, P19_QUARTILE_RESULTS_ASCII, and P19_QUARTILE_TRACE_ASCII before running.")
}
if (!file.exists(riskset_path) || !file.exists(mids_path)) stop("Input file does not exist.")
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(trace_dir, recursive = TRUE, showWarnings = FALSE)

riskset <- readRDS(riskset_path)
mids_obj <- readRDS(mids_path)
event_numeric <- function(x) suppressWarnings(as.integer(as.character(x)))
if (!inherits(mids_obj, "mids") || mids_obj$m != 20L || mids_obj$iteration != 25L) {
  stop("MICE object or settings do not match the frozen plan.")
}
if (nrow(riskset) != 15061L || sum(event_numeric(riskset$cmm_event)) != 1117L) {
  stop("Risk set is not the frozen 15,061-person, 1,117-event version.")
}

exposure_vars <- c(
  TV = "temperature_TV_daily_annual_mean_pre2011",
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010",
  Anum = "built_Anum",
  Bnum = "built_Bnum",
  CEnum = "built_CEnum"
)
model_covariates <- list(
  M1 = c("Age", "Gender", "Residence", "Education_Status"),
  M2 = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
         "Smoking_Status", "Drinking_Status", "household_income"),
  M3_revised = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
                 "Smoking_Status", "Drinking_Status", "household_income", "BMI2011",
                 "Regional_Category_2011")
)
required_vars <- unique(c(unname(exposure_vars), unlist(model_covariates),
                          "cmm_event", "time_from_2011_years"))
if (!all(required_vars %in% names(mids_obj$data))) stop("MICE object is missing analysis variables.")

completed_data <- lapply(seq_len(mids_obj$m), function(i) {
  d <- mice::complete(mids_obj, action = i)
  if (nrow(d) != nrow(riskset) ||
      !identical(event_numeric(d$cmm_event), event_numeric(riskset$cmm_event)) ||
      !isTRUE(all.equal(as.numeric(d$time_from_2011_years),
                        as.numeric(riskset$time_from_2011_years), check.attributes = FALSE))) {
    stop("Completed data do not match the frozen risk set.")
  }
  for (v in unname(exposure_vars)) {
    if (!isTRUE(all.equal(as.numeric(d[[v]]), as.numeric(riskset[[v]]),
                          check.attributes = FALSE))) stop("Fixed exposure changed in completed data.")
  }
  d$community_id_fixed <- as.character(riskset$community_id)
  d$individual_weight_fixed <- as.numeric(riskset$individual_weight)
  d
})

# Rubin合并单个回归项。
pool_scalar <- function(fits, term) {
  estimates <- vapply(fits, function(f) unname(stats::coef(f)[term]), numeric(1))
  variances <- vapply(fits, function(f) unname(stats::vcov(f)[term, term]), numeric(1))
  m <- length(estimates)
  qbar <- mean(estimates)
  within <- mean(variances)
  between <- if (m > 1) stats::var(estimates) else 0
  total <- within + (1 + 1 / m) * between
  se <- sqrt(total)
  df <- if (between <= .Machine$double.eps) Inf else (m - 1) *
    (1 + within / ((1 + 1 / m) * between))^2
  statistic <- qbar / se
  p_value <- if (is.finite(df)) 2 * stats::pt(abs(statistic), df, lower.tail = FALSE) else
    2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
  critical <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
  data.frame(term = term, imputations = m, beta = qbar, robust_SE = se,
             HR = exp(qbar), CI_95_low = exp(qbar - critical * se),
             CI_95_high = exp(qbar + critical * se), p_value = p_value,
             df = df, within_variance = within, between_variance = between,
             stringsAsFactors = FALSE)
}

# Rubin合并多自由度总体检验；报告近似F/卡方统计量并保留完整矩阵信息。
pool_wald <- function(fits, terms) {
  q <- do.call(rbind, lapply(fits, function(f) unname(stats::coef(f)[terms])))
  u <- Reduce("+", lapply(fits, function(f) stats::vcov(f)[terms, terms, drop = FALSE])) / nrow(q)
  b <- stats::cov(q)
  total <- u + (1 + 1 / nrow(q)) * b
  qbar <- colMeans(q)
  statistic <- as.numeric(t(qbar) %*% solve(total, qbar))
  p_value <- stats::pchisq(statistic, df = length(terms), lower.tail = FALSE)
  data.frame(test = "quartile_overall", terms = paste(terms, collapse = ";"),
             imputations = nrow(q), statistic = statistic, df = length(terms),
             p_value = p_value, stringsAsFactors = FALSE)
}

fit_weighted_cluster <- function(d, exposure_term, covariates) {
  d$analysis_weight <- d$individual_weight_fixed / mean(d$individual_weight_fixed)
  d$cmm_event_num <- event_numeric(d$cmm_event)
  formula <- stats::as.formula(paste(
    "survival::Surv(time_from_2011_years, cmm_event_num) ~",
    exposure_term, "+", paste(covariates, collapse = "+"),
    "+ cluster(community_id_fixed)"
  ))
  survival::coxph(formula, data = d, weights = analysis_weight, ties = "efron",
                  robust = TRUE, na.action = stats::na.fail, x = TRUE)
}

quartile_bounds <- list()
quartile_counts <- list()
quartile_results <- list()
overall_tests <- list()
trend_results <- list()
audit <- list()

for (exposure_name in names(exposure_vars)) {
  exposure_col <- exposure_vars[[exposure_name]]
  x <- as.numeric(riskset[[exposure_col]])
  q <- as.numeric(stats::quantile(x, c(.25, .50, .75), na.rm = TRUE, names = FALSE))
  if (any(!is.finite(q)) || length(unique(q)) != 3L) stop("Quartile cut points are invalid.")
  group <- cut(x, breaks = c(-Inf, q, Inf), labels = paste0("Q", 1:4), right = TRUE)
  group <- factor(group, levels = paste0("Q", 1:4))
  medians <- tapply(x, group, median, na.rm = TRUE)
  quartile_bounds[[exposure_name]] <- data.frame(
    exposure = exposure_name, p25 = q[1], p50 = q[2], p75 = q[3],
    IQR = q[3] - q[1], stringsAsFactors = FALSE
  )
  quartile_counts[[exposure_name]] <- do.call(rbind, lapply(levels(group), function(g) {
    ix <- group == g
    data.frame(exposure = exposure_name, group = g, n = sum(ix),
               events = sum(event_numeric(riskset$cmm_event)[ix]),
               person_years = sum(as.numeric(riskset$time_from_2011_years)[ix]),
               observed_min = min(x[ix]), observed_max = max(x[ix]),
               observed_median = median(x[ix]), stringsAsFactors = FALSE)
  }))

  for (i in seq_along(completed_data)) {
    completed_data[[i]][[paste0(exposure_name, "_q")]] <- group
    completed_data[[i]][[paste0(exposure_name, "_trend")]] <- as.numeric(medians[as.character(group)])
    completed_data[[i]][[paste0(exposure_name, "_rank")]] <- as.numeric(group)
  }

  for (model_name in names(model_covariates)) {
    q_term <- paste0(exposure_name, "_q")
    trend_term <- paste0(exposure_name, "_trend")
    fits_q <- lapply(completed_data, fit_weighted_cluster,
                     exposure_term = q_term, covariates = model_covariates[[model_name]])
    q_terms <- paste0(q_term, "Q", 2:4)
    if (!all(q_terms %in% names(stats::coef(fits_q[[1]])))) stop("Quartile terms are missing.")
    pooled_q <- do.call(rbind, lapply(c(q_term, q_terms), function(term) {
      if (term == q_term) {
        data.frame(term = "Q1_reference", imputations = length(fits_q), beta = 0,
                   robust_SE = NA_real_, HR = 1, CI_95_low = 1, CI_95_high = 1,
                   p_value = NA_real_, df = NA_real_, within_variance = NA_real_,
                   between_variance = NA_real_, stringsAsFactors = FALSE)
      } else pool_scalar(fits_q, term)
    }))
    quartile_results[[paste(exposure_name, model_name, sep = "_")]] <- cbind(
      exposure = exposure_name, model = model_name, pooled_q
    )
    overall_tests[[paste(exposure_name, model_name, sep = "_")]] <- cbind(
      exposure = exposure_name, model = model_name, pool_wald(fits_q, q_terms)
    )

    fits_trend <- lapply(completed_data, fit_weighted_cluster,
                         exposure_term = trend_term, covariates = model_covariates[[model_name]])
    trend_results[[paste(exposure_name, model_name, sep = "_")]] <- cbind(
      exposure = exposure_name, model = model_name,
      scale = "observed_group_median", pool_scalar(fits_trend, trend_term)
    )
    audit[[paste(exposure_name, model_name, sep = "_")]] <- data.frame(
      exposure = exposure_name, model = model_name, imputations = length(fits_q),
      n = nrow(riskset), events = sum(event_numeric(riskset$cmm_event)),
      communities = length(unique(riskset$community_id)), stringsAsFactors = FALSE
    )
  }
  message("Quartile/trend complete: ", exposure_name)
}

write.csv(do.call(rbind, quartile_bounds), file.path(results_dir, "quartile_boundaries.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, quartile_counts), file.path(results_dir, "quartile_counts_events_person_years.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, quartile_results), file.path(results_dir, "quartile_cox_M1_M2_M3_Rubin.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, overall_tests), file.path(results_dir, "quartile_overall_tests.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, trend_results), file.path(results_dir, "trend_tests_M1_M2_M3_Rubin.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, audit), file.path(trace_dir, "quartile_trend_model_audit.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

write.csv(data.frame(
  file = c(riskset_path, mids_path),
  sha256 = c(digest::digest(riskset_path, file = TRUE, algo = "sha256"),
             digest::digest(mids_path, file = TRUE, algo = "sha256")),
  stringsAsFactors = FALSE
), file.path(trace_dir, "input_sha256.csv"), row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c(
  paste0("Run time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
  "Quartile cut points: observed P25/P50/P75 from the frozen risk set; same cut points in all 20 imputations.",
  "Ties were retained in the same quartile; ntile was not used.",
  "Models: weighted Efron Cox with community-clustered robust variance; M3 excludes baseline CMM component count.",
  paste0("Fixed sample: ", nrow(riskset), " persons; ", sum(event_numeric(riskset$cmm_event)), " events; ",
         length(unique(riskset$community_id)), " communities."),
  "The PH diagnostic is stored in the preceding step; no exposure or covariate was removed because of its P value."
), file.path(trace_dir, "quartile_trend_run_trace.txt"), useBytes = TRUE)
message("Quartile and trend analyses complete.")
