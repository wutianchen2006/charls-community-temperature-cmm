# ============================================================================
# 步骤08-03：六个暴露的限制性立方样条（RCS）分析
#
# 运行目的：
#   1. 使用冻结的15,061人风险集和20份MICE插补数据；
#   2. 对TV、Tmean、DTR、Anum、Bnum、CEnum分别拟合M1、M2和修订M3；
#   3. 结点固定为P5、P35、P65、P95，重复结点自动去重；
#   4. 参考值固定为暴露中位数，输出总体关联和非线性检验；
#   5. 输出M3主图、全部模型检验表、曲线源数据和运行追溯信息。
#
# 初学者运行：在RStudio打开本文件，点击Source。正式运行前请确认下面四个
# 环境变量已经指向输入和输出目录。脚本不会修改风险集或MICE对象。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
suppressPackageStartupMessages({
  library(survival)
  library(mice)
  library(ggplot2)
  library(digest)
})

# 1. 路径设置 ---------------------------------------------------------------
project_root <- Sys.getenv("P19_PROJECT_ROOT", unset = "analysis")
riskset_default <- file.path(project_root, "02_人群纳排与风险集", "数据",
                             "人群筛选_20261022", "2011_2020_CMM主风险集_年龄45岁及以上.rds")
mids_default <- file.path(project_root, "06_ABC多重插补", "数据",
                          "PartB_MICE_m20_maxit25_seed20261025.rds")
riskset_path <- Sys.getenv("P19_RCS_RISKSET_ASCII", unset = riskset_default)
mids_path <- Sys.getenv("P19_RCS_MIDS_ASCII", unset = mids_default)
result_dir <- Sys.getenv("P19_RCS_RESULT_ASCII", unset = file.path(project_root, "08_暴露形式与模型诊断", "结果", "03_RCS_20261027"))
data_dir <- Sys.getenv("P19_RCS_DATA_ASCII", unset = file.path(project_root, "08_暴露形式与模型诊断", "数据", "03_RCS_20261027"))
trace_dir <- Sys.getenv("P19_RCS_TRACE_ASCII", unset = file.path(project_root, "08_暴露形式与模型诊断", "追溯文件", "03_RCS_20261027"))
# 投稿版图单独放在结果目录的子文件夹；不会覆盖原始结果图。
publication_dir <- Sys.getenv("P19_RCS_PUBLICATION_DIR_ASCII", unset = file.path(result_dir, "SCI发表图_20261027"))
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(trace_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(publication_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(file.exists(c(riskset_path, mids_path)))) {
  stop("风险集或MICE对象不存在，请先检查上游步骤06和步骤02的交付文件。")
}

# 2. 读取和输入门禁 ----------------------------------------------------------
riskset <- readRDS(riskset_path)
mids_obj <- readRDS(mids_path)
as_event <- function(x) suppressWarnings(as.integer(as.character(x)))

if (!inherits(mids_obj, "mids") || mids_obj$m != 20L || mids_obj$iteration != 25L) {
  stop("MICE对象不是冻结的m=20、maxit=25版本。")
}
if (nrow(riskset) != 15061L || sum(as_event(riskset$cmm_event)) != 1117L) {
  stop("风险集不是冻结的15,061人、1,117例事件版本。")
}

exposure_vars <- c(
  TV = "temperature_TV_daily_annual_mean_pre2011",
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010",
  Anum = "built_Anum",
  Bnum = "built_Bnum",
  CEnum = "built_CEnum"
)
model_covariates <- list(
  M1 = c("Age", "Gender", "Residence", "Education_Status"),
  M2 = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
         "Smoking_Status", "Drinking_Status", "household_income"),
  M3_revised = c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
                 "Smoking_Status", "Drinking_Status", "household_income", "BMI2011",
                 "Regional_Category_2011")
)
required_vars <- unique(c(unname(exposure_vars), unlist(model_covariates),
                          "cmm_event", "time_from_2011_years"))
if (!all(required_vars %in% names(mids_obj$data))) {
  stop("MICE对象缺少变量：", paste(setdiff(required_vars, names(mids_obj$data)), collapse = ", "))
}

completed_data <- lapply(seq_len(mids_obj$m), function(i) {
  d <- mice::complete(mids_obj, action = i)
  if (nrow(d) != nrow(riskset) ||
      !identical(as_event(d$cmm_event), as_event(riskset$cmm_event)) ||
      !isTRUE(all.equal(as.numeric(d$time_from_2011_years),
                        as.numeric(riskset$time_from_2011_years), check.attributes = FALSE))) {
    stop("第", i, "份插补数据的事件或随访时间与冻结风险集不一致。")
  }
  for (v in unname(exposure_vars)) {
    if (!isTRUE(all.equal(as.numeric(d[[v]]), as.numeric(riskset[[v]]),
                          check.attributes = FALSE))) {
      stop("第", i, "份插补数据的固定暴露发生变化：", v)
    }
  }
  d$community_id_fixed <- as.character(riskset$community_id)
  d$individual_weight_fixed <- as.numeric(riskset$individual_weight)
  d
})

# 3. RCS工具函数 -------------------------------------------------------------
model_formula <- function(basis_names, covariates) {
  stats::as.formula(paste(
    "survival::Surv(time_from_2011_years, cmm_event_num) ~",
    paste(c(basis_names, covariates), collapse = " + "),
    "+ cluster(community_id_fixed)"
  ))
}

fit_rcs <- function(d, basis_names, covariates) {
  d$cmm_event_num <- as_event(d$cmm_event)
  d$analysis_weight <- d$individual_weight_fixed / mean(d$individual_weight_fixed)
  survival::coxph(
    formula = model_formula(basis_names, covariates),
    data = d, weights = analysis_weight, ties = "efron", robust = TRUE,
    na.action = stats::na.fail, x = TRUE
  )
}

pool_coefficients <- function(fits, model_name, exposure_name) {
  terms <- names(stats::coef(fits[[1]]))
  same_terms <- vapply(fits, function(f) identical(names(stats::coef(f)), terms), logical(1))
  if (!all(same_terms)) {
    stop("20份RCS模型的系数名称不一致：", exposure_name, " / ", model_name)
  }
  do.call(rbind, lapply(terms, function(term) {
    q <- vapply(fits, function(f) unname(stats::coef(f)[term]), numeric(1))
    u <- vapply(fits, function(f) unname(stats::vcov(f)[term, term]), numeric(1))
    m <- length(q)
    qbar <- mean(q)
    within <- mean(u)
    between <- if (m > 1) stats::var(q) else 0
    total <- within + (1 + 1 / m) * between
    se <- sqrt(total)
    df <- if (between <= .Machine$double.eps) Inf else
      (m - 1) * (1 + within / ((1 + 1 / m) * between))^2
    crit <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
    p <- if (is.finite(df)) 2 * stats::pt(abs(qbar / se), df, lower.tail = FALSE) else
      2 * stats::pnorm(abs(qbar / se), lower.tail = FALSE)
    data.frame(model = model_name, exposure = exposure_name, term = term,
               imputations = m, beta = qbar, robust_SE = se, HR = exp(qbar),
               CI_95_low = exp(qbar - crit * se), CI_95_high = exp(qbar + crit * se),
               p_value = p, df = df, within_variance = within,
               between_variance = between, n = 15061L, events = 1117L,
               communities = length(unique(riskset$community_id)),
               stringsAsFactors = FALSE)
  }))
}

pool_wald <- function(fits, terms, model_name, exposure_name, test_name) {
  q <- do.call(rbind, lapply(fits, function(f) unname(stats::coef(f)[terms])))
  u <- Reduce("+", lapply(fits, function(f) stats::vcov(f)[terms, terms, drop = FALSE])) / nrow(q)
  b <- stats::cov(q)
  total <- u + (1 + 1 / nrow(q)) * b
  qbar <- colMeans(q)
  statistic <- as.numeric(t(qbar) %*% solve(total, qbar))
  data.frame(model = model_name, exposure = exposure_name, test = test_name,
             terms = paste(terms, collapse = ";"), imputations = nrow(q),
             statistic = statistic, df = length(terms),
             p_value = stats::pchisq(statistic, df = length(terms), lower.tail = FALSE),
             stringsAsFactors = FALSE)
}

contrast_from_pool <- function(pooled, fits, basis_names, new_basis, ref_basis) {
  term_names <- names(stats::coef(fits[[1]]))
  L <- setNames(rep(0, length(term_names)), term_names)
  L[basis_names] <- as.numeric(new_basis - ref_basis)
  q <- sum(L * pooled$beta)
  u <- mean(vapply(fits, function(f) as.numeric(t(L) %*% stats::vcov(f) %*% L), numeric(1)))
  b <- stats::var(vapply(fits, function(f) sum(L * stats::coef(f)), numeric(1)))
  total <- u + (1 + 1 / length(fits)) * b
  se <- sqrt(total)
  df <- if (b <= .Machine$double.eps) Inf else
    (length(fits) - 1) * (1 + u / ((1 + 1 / length(fits)) * b))^2
  crit <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
  data.frame(beta = q, HR = exp(q), CI_95_low = exp(q - crit * se),
             CI_95_high = exp(q + crit * se), p_value = if (is.finite(df))
               2 * stats::pt(abs(q / se), df, lower.tail = FALSE) else
               2 * stats::pnorm(abs(q / se), lower.tail = FALSE),
             stringsAsFactors = FALSE)
}

# 4. 循环六个暴露和三个模型 -----------------------------------------------
all_coefficients <- list()
all_tests <- list()
all_curves <- list()
all_knots <- list()
audit <- list()
plot_list <- list()

exposure_labels <- c(
  TV = "Temperature variability (TV)",
  Tmean = "Mean temperature (Tmean)",
  DTR = "Diurnal temperature range (DTR)",
  Anum = "Infrastructure score (Anum)",
  Bnum = "Community support score (Bnum)",
  CEnum = "Composite built environment score (CEnum)"
)

# 论文图中统一使用简洁的 P 值格式；源 CSV 仍保留完整精度。
format_plot_p <- function(x) {
  if (is.na(x)) return("NA")
  if (x < 0.001) return("<0.001")
  sprintf("%.3f", x)
}

for (exposure_name in names(exposure_vars)) {
  exposure_col <- exposure_vars[[exposure_name]]
  x <- as.numeric(riskset[[exposure_col]])
  knot_values <- unique(as.numeric(stats::quantile(x, probs = c(.05, .35, .65, .95),
                                                   na.rm = TRUE, names = FALSE, type = 7)))
  if (length(knot_values) < 3L) stop("RCS结点少于3个：", exposure_name)
  all_knots[[exposure_name]] <- data.frame(
    exposure = exposure_name, knot_index = seq_along(knot_values),
    percentile = c(.05, .35, .65, .95)[seq_along(knot_values)],
    knot_value = knot_values, stringsAsFactors = FALSE
  )

  basis_observed <- Hmisc::rcspline.eval(x, knots = knot_values, inclx = TRUE)
  basis_names <- paste0("rcs_", seq_len(ncol(basis_observed)))
  colnames(basis_observed) <- basis_names
  for (i in seq_along(completed_data)) {
    completed_data[[i]][, basis_names] <- basis_observed
  }

  fit_by_model <- list()
  for (model_name in names(model_covariates)) {
    fits <- lapply(completed_data, fit_rcs, basis_names = basis_names,
                   covariates = model_covariates[[model_name]])
    fit_by_model[[model_name]] <- fits
    pooled <- pool_coefficients(fits, model_name, exposure_name)
    all_coefficients[[paste(exposure_name, model_name, sep = "_")]] <- pooled
    all_tests[[paste(exposure_name, model_name, "overall", sep = "_")]] <- pool_wald(
      fits, basis_names, model_name, exposure_name, "overall"
    )
    nonlinear_terms <- basis_names[-1]
    all_tests[[paste(exposure_name, model_name, "nonlinear", sep = "_")]] <- pool_wald(
      fits, nonlinear_terms, model_name, exposure_name, "nonlinear"
    )
    audit[[paste(exposure_name, model_name, sep = "_")]] <- data.frame(
      exposure = exposure_name, model = model_name, imputations = length(fits),
      n = 15061L, events = 1117L,
      communities = length(unique(riskset$community_id)),
      knots = paste(signif(knot_values, 8), collapse = ";"),
      stringsAsFactors = FALSE
    )

    # 只生成M3主图；M1/M2的曲线源数据和总体检验全部保留。
    if (model_name == "M3_revised") {
      overall_test <- all_tests[[paste(exposure_name, model_name, "overall", sep = "_")]]
      nonlinear_test <- all_tests[[paste(exposure_name, model_name, "nonlinear", sep = "_")]]
      p_annotation <- paste0(
        "P-overall = ", format_plot_p(overall_test$p_value),
        "\nP-nonlinear = ", format_plot_p(nonlinear_test$p_value)
      )
      reference_value <- stats::median(x, na.rm = TRUE)
      grid <- seq(min(x, na.rm = TRUE), max(x, na.rm = TRUE), length.out = 200L)
      basis_grid <- Hmisc::rcspline.eval(grid, knots = knot_values, inclx = TRUE)
      basis_ref <- Hmisc::rcspline.eval(reference_value, knots = knot_values, inclx = TRUE)
      curve <- do.call(rbind, lapply(seq_along(grid), function(j) {
        est <- contrast_from_pool(pooled, fits, basis_names,
                                  basis_grid[j, ], basis_ref[1, ])
        cbind(exposure = exposure_name, model = model_name, x = grid[j],
              reference = reference_value, est)
      }))
      all_curves[[paste(exposure_name, model_name, sep = "_")]] <- curve

      title_text <- exposure_labels[[exposure_name]]
      p <- ggplot(curve, aes(x = x, y = HR)) +
        geom_ribbon(aes(ymin = CI_95_low, ymax = CI_95_high),
                    fill = "#0072B2", alpha = 0.18) +
        geom_line(color = "#0072B2", linewidth = 0.8) +
        geom_hline(yintercept = 1, linetype = 2, color = "grey45") +
        geom_vline(xintercept = reference_value, linetype = 3, color = "grey55") +
        labs(title = title_text,
              subtitle = "M3; reference = median; 20 imputations",
             x = exposure_name, y = "Hazard ratio (95% CI)") +
        theme_classic(base_size = 10) +
        theme(plot.title = element_text(face = "bold"),
              plot.subtitle = element_text(size = 8), legend.position = "none")
      plot_list[[exposure_name]] <- p

      # 原始图保持原样；论文版图在面板右上角增加两个预先定义的检验值。
      p_publication <- p +
        annotate("label", x = Inf, y = Inf, label = p_annotation,
                 hjust = 1.03, vjust = 1.08, size = 3.0,
                 fill = "white", alpha = 0.90,
                 color = "black", lineheight = 1.05) +
        theme(plot.margin = margin(5.5, 22, 5.5, 5.5))
      plot_list[[exposure_name]] <- p_publication

      ggplot2::ggsave(file.path(result_dir, paste0("RCS_", exposure_name, "_M3_revised.png")),
                      p, width = 7.2, height = 4.6, units = "in", dpi = 600, bg = "white")
      grDevices::cairo_pdf(file.path(result_dir, paste0("RCS_", exposure_name, "_M3_revised.pdf")),
                           width = 7.2, height = 4.6)
      print(p)
      grDevices::dev.off()

      ggplot2::ggsave(file.path(publication_dir, paste0("RCS_", exposure_name, "_M3_revised_Pvalues.png")),
                      p_publication, width = 7.2, height = 4.6, units = "in", dpi = 600, bg = "white")
      grDevices::cairo_pdf(file.path(publication_dir, paste0("RCS_", exposure_name, "_M3_revised_Pvalues.pdf")),
                           width = 7.2, height = 4.6)
      print(p_publication)
      grDevices::dev.off()
    }
  }
  message("RCS完成：", exposure_name)
}

# 5. 保存结果、源数据和追溯 ---------------------------------------------------
write.csv(do.call(rbind, all_coefficients), file.path(result_dir, "RCS_coefficients_all_models.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, all_tests), file.path(result_dir, "RCS_overall_nonlinear_tests.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, all_knots), file.path(data_dir, "RCS_knots_P5_P35_P65_P95.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, all_curves), file.path(data_dir, "RCS_M3_curve_source.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(do.call(rbind, audit), file.path(trace_dir, "RCS_model_audit.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

input_hash <- data.frame(
  file = c(riskset_path, mids_path),
  sha256 = c(digest::digest(riskset_path, file = TRUE, algo = "sha256"),
             digest::digest(mids_path, file = TRUE, algo = "sha256")),
  stringsAsFactors = FALSE
)
write.csv(input_hash, file.path(trace_dir, "RCS_input_sha256.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

if (length(plot_list) == 6L && requireNamespace("patchwork", quietly = TRUE)) {
  combined <- patchwork::wrap_plots(plot_list, ncol = 2) +
    patchwork::plot_annotation(title = "Restricted cubic spline analyses",
                               subtitle = "M3; six exposures; 20 imputations; shaded areas are 95% CIs",
                               tag_levels = "A")
  ggplot2::ggsave(file.path(result_dir, "RCS_six_exposures_M3_combined.png"),
                  combined, width = 10, height = 12, units = "in", dpi = 600, bg = "white")
  grDevices::cairo_pdf(file.path(result_dir, "RCS_six_exposures_M3_combined.pdf"),
                       width = 10, height = 12)
  print(combined)
  grDevices::dev.off()

  ggplot2::ggsave(file.path(publication_dir, "RCS_six_exposures_M3_combined_Pvalues.png"),
                  combined, width = 10, height = 12, units = "in", dpi = 600, bg = "white")
  grDevices::cairo_pdf(file.path(publication_dir, "RCS_six_exposures_M3_combined_Pvalues.pdf"),
                       width = 10, height = 12)
  print(combined)
  grDevices::dev.off()
  ggplot2::ggsave(file.path(publication_dir, "RCS_six_exposures_M3_combined_Pvalues.svg"),
                  combined, width = 10, height = 12, units = "in", bg = "white")
}

# 单独保存论文图使用的 M3 检验值，避免图中标签无法追溯。
publication_tests <- do.call(rbind, lapply(expected_exposures <- names(exposure_vars), function(exposure_name) {
  overall_test <- all_tests[[paste(exposure_name, "M3_revised", "overall", sep = "_")]]
  nonlinear_test <- all_tests[[paste(exposure_name, "M3_revised", "nonlinear", sep = "_")]]
  data.frame(exposure = exposure_name, model = "M3_revised",
             p_overall = overall_test$p_value,
             p_nonlinear = nonlinear_test$p_value,
             stringsAsFactors = FALSE)
}))
write.csv(publication_tests, file.path(publication_dir, "RCS_M3_plot_p_values.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c(
  "# RCS SCI publication figures",
  "",
  "This folder contains revised M3 figures for manuscript layout and does not overwrite the original result figures.",
  "Each panel displays P-overall (overall association) and P-nonlinear (nonlinear component).",
  "P values are pooled across 20 MICE datasets with the same Rubin/Wald procedure; the reference is the exposure median and ribbons are 95% CIs.",
  "Preferred manuscript figure: RCS_six_exposures_M3_combined_Pvalues.pdf; PNG is a preview.",
  "Individual PDF/PNG panels are available when the journal requests separate panels. RCS_M3_plot_p_values.csv is the label audit table.",
  "Reproducible script: code/03_RCS_20261027/01_RCS_six_exposures.R.",
  "Input hashes, model audit, and run log: trace/03_RCS_20261027/."
), file.path(publication_dir, "README.md"), useBytes = TRUE)

# 投稿目录文件清单和哈希：便于确认图没有被替换或漏交。
publication_files <- list.files(publication_dir, full.names = TRUE, recursive = FALSE)
publication_files <- publication_files[basename(publication_files) != "publication_manifest.csv"]
publication_manifest <- data.frame(
  file = basename(publication_files),
  sha256 = vapply(publication_files, digest::digest, character(1), file = TRUE, algo = "sha256"),
  bytes = file.info(publication_files)$size,
  stringsAsFactors = FALSE
)
write.csv(publication_manifest, file.path(trace_dir, "RCS_publication_manifest.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

run_trace <- c(
  paste0("Run time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
  paste0("R version: ", R.version.string),
  paste0("Risk set: ", nrow(riskset), " persons; ", sum(as_event(riskset$cmm_event)),
         " events; ", length(unique(riskset$community_id)), " communities."),
  paste0("MICE: m=", mids_obj$m, "; maxit=", mids_obj$iteration),
  "Exposures: TV, Tmean, DTR, Anum, Bnum, CEnum; models: M1, M2, M3_revised.",
  "Knots: P5, P35, P65, P95; duplicated knots were removed; reference is the median.",
  "M3 plots and all M1/M2/M3 overall and nonlinear tests were saved.",
  "Models used individual weights, community-clustered robust variance, Efron ties, and Rubin pooling."
)
writeLines(run_trace, file.path(trace_dir, "RCS_run_trace.txt"), useBytes = TRUE)
message("RCS_ANALYSIS_COMPLETE")
