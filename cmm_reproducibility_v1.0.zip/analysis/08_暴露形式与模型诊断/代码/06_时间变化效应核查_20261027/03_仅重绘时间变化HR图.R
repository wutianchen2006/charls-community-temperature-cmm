# ============================================================================
# 步骤08-06：只重绘图，不重新运行模型。
# 正式图为SVG和PDF；PNG只放在追溯文件中，供内部检查。
# 数据唯一来源是01脚本输出的完整HR曲线CSV，不删减时间点。
# ============================================================================
options(encoding = "UTF-8", stringsAsFactors = FALSE)
if (.Platform$OS.type == "windows" && !isTRUE(l10n_info()[["UTF-8"]])) {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "English_United States.utf8"))
}
suppressPackageStartupMessages(library(ggplot2))

# 从项目或脚本附近向上查找根目录，便于在RStudio直接Source。
source_file <- tryCatch(sys.frame(1)$ofile, error = function(e) NULL)
arg_file <- grep("^--file=", commandArgs(), value = TRUE)
starts <- c(getwd(), if (length(source_file)) dirname(source_file),
            if (length(arg_file)) dirname(sub("^--file=", "", arg_file[1])))
figure_root <- ""
for (start in starts) {
  candidate <- normalizePath(start, winslash = "/", mustWork = FALSE)
  for (level in 0:9) {
    if (dir.exists(file.path(candidate, "04_研究进行"))) {
      figure_root <- candidate
      break
    }
    candidate <- dirname(candidate)
  }
  if (nzchar(figure_root)) break
}
if (!nzchar(figure_root)) stop("Open from the project or script directory.")
figure_phase <- file.path(figure_root, "04_研究进行/08_暴露形式与模型诊断")
figure_substep <- "06_时间变化效应核查_20261027"
figure_result <- file.path(figure_phase, "结果", figure_substep)
figure_trace <- file.path(figure_phase, "追溯文件", figure_substep)
figure_data <- read.csv(file.path(figure_result, "03_time_varying_HR_data.csv"),
                        fileEncoding = "UTF-8")
stopifnot(all(is.finite(figure_data$HR)), all(figure_data$CI_95_low > 0),
          all(figure_data$CI_95_high >= figure_data$HR),
          all(figure_data$HR >= figure_data$CI_95_low),
          all(figure_data$time_years > 0))
figure_data$exposure <- factor(figure_data$exposure, levels = c("Tmean", "DTR", "Bnum"))
stopifnot(!anyNA(figure_data$exposure))

# 三个并列面板回答同一个问题：每IQR的HR是否可能随随访时间变化。
# 虚线为HR=1；阴影为逐时点95%CI，不是整条曲线的同时置信带。
# 图中时间范围由正式CSV决定，仅覆盖实际观察到事件的时间支持范围。
figure_plot <- ggplot(figure_data, aes(x = time_years, y = HR,
                                      color = exposure, fill = exposure)) +
  geom_ribbon(aes(ymin = CI_95_low, ymax = CI_95_high), alpha = .14, color = NA) +
  geom_line(linewidth = .8) +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey45") +
  facet_wrap(~ exposure, nrow = 1) +
  scale_color_manual(values = c(Tmean = "#0072B2", DTR = "#D55E00", Bnum = "#009E73")) +
  scale_fill_manual(values = c(Tmean = "#0072B2", DTR = "#D55E00", Bnum = "#009E73")) +
  scale_x_continuous(breaks = c(2, 4, 7, 9)) +
  scale_y_log10() +
  labs(title = "Time-varying HR for Tmean, DTR and Bnum",
       subtitle = "Revised M3; event-time interaction; pointwise 95% CI",
       x = "Years since baseline (2011)", y = "Hazard ratio (log scale)") +
  theme_classic(base_size = 10, base_family = "Arial") +
  theme(legend.position = "none", strip.background = element_blank())

# 254×101.6mm的原稿，在183mm双栏宽度下，基础字号约为7.2pt。
# svglite保留真实文字和路径；cairo_pdf嵌入字体。
svglite::svglite(file.path(figure_result, "04_time_varying_HR.svg"), width = 10, height = 4)
print(figure_plot)
grDevices::dev.off()
grDevices::cairo_pdf(file.path(figure_result, "04_time_varying_HR.pdf"),
                     width = 10, height = 4, family = "Arial")
print(figure_plot)
grDevices::dev.off()

# 内部预览也由R绘制；预览不进入投稿结果目录。
ragg::agg_png(file.path(figure_trace, "13_内部预览_时间变化HR.png"),
              width = 10, height = 4, units = "in", res = 300)
print(figure_plot)
grDevices::dev.off()
message("SVG/PDF and internal R preview exported from the saved full curve data.")
