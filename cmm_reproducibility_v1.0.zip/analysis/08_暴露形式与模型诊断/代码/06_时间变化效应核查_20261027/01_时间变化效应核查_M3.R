# ============================================================================
# 第十九篇预分析 | 步骤08-06：三个暴露的时间变化效应核查
# 2026-10-29修正：按所有事件时点拆分随访，使用当前事件时间，而非个体终末时间。
#
# 目的：
#   1. 使用当前冻结的15,061人风险集和20份MICE插补数据；
#   2. 保持修订M3、个体权重和社区聚类设定不变；
#   3. 只对PH诊断中持续出现信号的Tmean、DTR、Bnum加入“暴露×log(随访时间)”项；
#   4. 按Rubin规则合并主要暴露和时间交互项，并输出逐份审计记录。
#
# 为什么只检查三个暴露：
#   在M1、M2和修订M3的20份插补数据中，Tmean、DTR、Bnum的暴露项均持续
#   出现PH信号；TV、Anum和CEnum的暴露项没有持续PH信号。此步骤不是删变量、
#   改风险集或追求显著性，而是核查受影响暴露的HR是否随时间变化。
#
# 初学者运行方法：在RStudio打开本文件，点击“Source”。脚本不会修改上游
# 风险集、MICE对象或步骤07的主模型结果。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
# Windows命令行可能继承不合法的C.UTF-8；只在当前R进程修复字符区域设置。
if (.Platform$OS.type == "windows" && !isTRUE(l10n_info()[["UTF-8"]])) {
  suppressWarnings(Sys.setlocale("LC_CTYPE", "English_United States.utf8"))
}
# 运行时通过完整路径环境变量传入中文目录，避免在代码中拼接中文路径。
suppressPackageStartupMessages({
  library(survival)
  library(mice)
  library(digest)
  library(ggplot2)
  library(svglite)
})

project_root <- Sys.getenv(
  "P19_PROJECT_ROOT", unset = ""
)
# 小白运行：从项目或脚本附近打开，Source即可；环境变量仅作可选路径覆盖。
if (!nzchar(project_root)) {
  source_file <- tryCatch(sys.frame(1)$ofile, error = function(e) NULL)
  argv_file <- grep("^--file=", commandArgs(), value = TRUE)
  starts <- c(getwd(), if (length(source_file)) dirname(source_file),
              if (length(argv_file)) dirname(sub("^--file=", "", argv_file[1])))
  for (start in starts) {
    candidate <- normalizePath(start, winslash = "/", mustWork = FALSE)
    for (level in 0:8) {
      if (dir.exists(file.path(candidate, "04_研究进行"))) {
        project_root <- file.path(candidate, "04_研究进行")
        break
      }
      if (dir.exists(file.path(candidate, "02_人群纳排与风险集"))) {
        project_root <- candidate
        break
      }
      candidate <- dirname(candidate)
    }
    if (nzchar(project_root)) break
  }
}
# 运行环境可以直接传入这些完整路径，避免Windows R的中文路径编码差异。
phase_root <- Sys.getenv("P19_TV_PHASE_ROOT", unset = "")
data_dir <- Sys.getenv("P19_TV_DATA_DIR", unset = "")
trace_dir <- Sys.getenv("P19_TV_TRACE_DIR", unset = "")
result_dir <- Sys.getenv("P19_TV_RESULT_DIR", unset = "")
if (!nzchar(project_root)) stop("Open this script from the project, or set P19_PROJECT_ROOT.")
if (!nzchar(phase_root)) phase_root <- file.path(project_root, "08_暴露形式与模型诊断")
substep <- "06_时间变化效应核查_20261027"
if (!nzchar(data_dir)) data_dir <- file.path(phase_root, "数据", substep)
if (!nzchar(trace_dir)) trace_dir <- file.path(phase_root, "追溯文件", substep)
if (!nzchar(result_dir)) result_dir <- file.path(phase_root, "结果", substep)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(trace_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)

riskset_path <- Sys.getenv("P19_TV_RISKSET_PATH", unset = "")
mids_path <- Sys.getenv("P19_TV_MIDS_PATH", unset = "")
if (!nzchar(riskset_path)) riskset_path <- file.path(
  project_root, "02_人群纳排与风险集", "数据", "人群筛选_20261022",
  "2011_2020_CMM主风险集_年龄45岁及以上.rds"
)
if (!nzchar(mids_path)) mids_path <- file.path(
  project_root, "06_ABC多重插补", "数据", "PartB_MICE_m20_maxit25_seed20261025.rds"
)
if (!all(file.exists(c(riskset_path, mids_path)))) {
  stop("Input riskset or MICE object is missing.")
}

# 一、读取输入并执行门禁 --------------------------------------------------------
expected_hashes <- c(
  "f199d6bb86ce49f43a652f57908020932382cb5cf989073ee171b4b92cca3131",
  "1f1e234332fba2da0ac0505fb73e588e378dc7f036823c24b967dfc63d3e6fdd"
)
actual_hashes <- vapply(c(riskset_path, mids_path), function(p) {
  digest::digest(p, file = TRUE, algo = "sha256")
}, character(1))
if (!identical(unname(actual_hashes), expected_hashes)) stop("Frozen input SHA256 mismatch.")
riskset <- readRDS(riskset_path)
mids <- readRDS(mids_path)
to_event_num <- function(x) suppressWarnings(as.integer(as.character(x)))

if (!inherits(mids, "mids")) stop("Input is not a mice mids object.")
if (anyDuplicated(as.character(riskset$ID)) ||
    !identical(rownames(mids$data), rownames(riskset))) {
  stop("ID uniqueness or frozen row-order gate failed.")
}
if (mids$m != 20L || mids$iteration != 25L) {
  stop("MICE must use m=20 and maxit=25.")
}
if (nrow(riskset) != 15061L || sum(to_event_num(riskset$cmm_event)) != 1117L) {
  stop("Risk set must contain 15061 persons and 1117 events.")
}
if (anyNA(riskset$individual_weight) ||
    any(!is.finite(riskset$individual_weight)) ||
    any(riskset$individual_weight <= 0)) {
  stop("Weights contain missing, non-finite or non-positive values.")
}
if (anyNA(riskset$community_id) ||
    !all(nzchar(as.character(riskset$community_id)))) {
  stop("Community cluster IDs contain missing or empty values.")
}

# 只核查PH诊断中持续出现信号的三个暴露。
exposure_vars <- c(
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010",
  Bnum = "built_Bnum"
)
m3_covariates <- c(
  "Age", "Gender", "Residence", "Education_Status", "Marital_status",
  "Smoking_Status", "Drinking_Status", "household_income", "BMI2011",
  "Regional_Category_2011"
)
required_vars <- unique(c(
  unname(exposure_vars), m3_covariates, "cmm_event", "time_from_2011_years"
))
if (!all(required_vars %in% names(mids$data))) {
  stop("Required variables are missing: ",
       paste(setdiff(required_vars, names(mids$data)), collapse = ", "))
}
if (any(!is.finite(as.numeric(riskset$time_from_2011_years))) ||
    any(as.numeric(riskset$time_from_2011_years) <= 0)) {
  stop("Follow-up time must be positive.")
}

iqr_scale <- vapply(exposure_vars, function(v) {
  x <- as.numeric(riskset[[v]])
  as.numeric(stats::quantile(x, .75, na.rm = TRUE, names = FALSE) -
               stats::quantile(x, .25, na.rm = TRUE, names = FALSE))
}, numeric(1))
exposure_center <- vapply(exposure_vars, function(v) {
  stats::median(as.numeric(riskset[[v]]), na.rm = TRUE)
}, numeric(1))
if (any(!is.finite(iqr_scale) | iqr_scale <= 0)) {
  stop("At least one exposure IQR is invalid.")
}
if (any(!is.finite(exposure_center))) {
  stop("At least one exposure center is invalid.")
}

imputed_data <- lapply(seq_len(mids$m), function(i) {
  d <- mice::complete(mids, action = i)
  if (nrow(d) != nrow(riskset)) stop("Imputation row count mismatch: ", i)
  if (!identical(to_event_num(d$cmm_event),
                 to_event_num(riskset$cmm_event)) ||
      !isTRUE(all.equal(as.numeric(d$time_from_2011_years),
                        as.numeric(riskset$time_from_2011_years),
                        check.attributes = FALSE))) {
    stop("Event or follow-up mismatch in imputation ", i)
  }
  for (v in unname(exposure_vars)) {
    if (!isTRUE(all.equal(as.numeric(d[[v]]), as.numeric(riskset[[v]]),
                          check.attributes = FALSE))) {
      stop("Fixed exposure changed in imputation ", i, ": ", v)
    }
  }
  if (anyNA(d[, m3_covariates, drop = FALSE])) {
    stop("Missing revised M3 variable in imputation ", i)
  }
  d$ID_fixed <- as.character(riskset$ID)
  d$community_id_fixed <- as.character(riskset$community_id)
  d$individual_weight_fixed <- as.numeric(riskset$individual_weight)
  d
})

input_audit <- do.call(rbind, lapply(seq_along(imputed_data), function(i) {
  d <- imputed_data[[i]]
  data.frame(
    imputation = i, n = nrow(d),
    events = sum(to_event_num(d$cmm_event)),
    communities = length(unique(d$community_id_fixed)),
    missing_required = sum(vapply(d[, required_vars, drop = FALSE],
                                  function(x) sum(is.na(x)), numeric(1))),
    invalid_weight = sum(!is.finite(d$individual_weight_fixed) |
                         d$individual_weight_fixed <= 0),
    stringsAsFactors = FALSE
  )
}))
write.csv(input_audit, file.path(trace_dir, "01_input_gate.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(data.frame(
  file = c(riskset_path, mids_path),
  sha256 = c(digest::digest(riskset_path, file = TRUE, algo = "sha256"),
             digest::digest(mids_path, file = TRUE, algo = "sha256")),
  stringsAsFactors = FALSE
), file.path(trace_dir, "02_input_sha256.csv"),
row.names = FALSE, fileEncoding = "UTF-8")
if (any(input_audit$n != 15061L) ||
    any(input_audit$events != 1117L) ||
    any(input_audit$communities != 446L) ||
    any(input_audit$missing_required != 0L) ||
    any(input_audit$invalid_weight != 0L)) {
  stop("At least one imputation failed the input gate; model was not run.")
}

# 二、先验证事件风险集，再拟合修订M3的时间交互模型 ---------------------------
# 正确目标：log HR(t) = beta_4 + beta_time * log(t / 4)。
# 4年位于观察到的事件时间内；它只是计算参照点，不是挑选的分层断点。
# 同一个事件时点t，风险集中所有人的交互项必须都使用这个t。
# 原错误：用每个人最终随访时间Ti生成x*log(Ti)，把未来结局时间当作固定预测变量。
reference_year <- 4
event_times <- sort(unique(as.numeric(riskset$time_from_2011_years)[
  to_event_num(riskset$cmm_event) == 1L
]))
time_term <- "exposure_log_time"
model_terms <- c("exposure_iqr", time_term)
validation_rows <- list()
fit_audit_rows <- list()
warning_rows <- list()

prepare_data <- function(d, exposure_name) {
  d <- d[, c(m3_covariates, unname(exposure_vars), "cmm_event",
              "time_from_2011_years", "community_id_fixed", "individual_weight_fixed"),
         drop = FALSE]
  d$person_row <- seq_len(nrow(d))
  d$cmm_event_num <- to_event_num(d$cmm_event)
  d$analysis_weight <- d$individual_weight_fixed /
    mean(d$individual_weight_fixed)
  # 以风险集的中位数为中心，再按风险集IQR缩放。
  # 这样 exposure_iqr 每增加1代表暴露增加1个IQR，且主效应可解释为
  # 在随访第4年时的每IQR HR；中心化只影响计算参照，不改变每IQR的含义。
  d$exposure_iqr <- (
    as.numeric(d[[exposure_vars[[exposure_name]]]]) -
      exposure_center[[exposure_name]]
  ) / iqr_scale[[exposure_name]]
  d
}

make_split <- function(d) {
  # survSplit使用(start, stop]区间；在事件时点恰好删失者仍属于该时点风险集。
  # 在所有事件时点切开后，发生在t的事件及其风险集行的tstop都等于t。
  z <- survival::survSplit(
    Surv(time_from_2011_years, cmm_event_num) ~ .,
    data = d, cut = event_times, start = "tstart", end = "tstop", event = "status"
  )
  z$exposure_log_time <- z$exposure_iqr * log(z$tstop / reference_year)
  stopifnot(all(z$tstart < z$tstop), sum(z$status) == 1117L,
            length(unique(z$person_row)) == 15061L)
  z
}

fit_checked <- function(formula, d, tt_fun = NULL) {
  # 所有拟合警告均写入追溯；存在警告时不签发“通过”。
  warning_text <- character()
  args <- list(formula = formula, data = d, weights = d$analysis_weight,
               ties = "efron", robust = TRUE, na.action = stats::na.fail,
               x = FALSE, y = FALSE, model = FALSE,
               control = survival::coxph.control(iter.max = 50))
  if (!is.null(tt_fun)) args$tt <- tt_fun
  f <- withCallingHandlers(do.call(survival::coxph, args), warning = function(w) {
    warning_text <<- c(warning_text, conditionMessage(w))
    invokeRestart("muffleWarning")
  })
  if (length(warning_text)) stop("Cox fit warning: ", paste(warning_text, collapse = "; "))
  if (any(!is.finite(stats::coef(f))) || any(!is.finite(stats::vcov(f))) ||
      is.null(f$naive.var) || max(f$iter) >= 50) stop("Cox convergence/robust-variance gate failed.")
  f
}

split_formula <- stats::as.formula(paste(
  "survival::Surv(tstart, tstop, status) ~ exposure_iqr + exposure_log_time +",
  paste(m3_covariates, collapse = " + "), "+ cluster(community_id_fixed)"
))

# 独立验证：第一份完整插补数据，三个暴露均比较两种不同实现。
# 另外比较不加时间交互的拆分模型与原始右删失模型，验证拆分没有改变风险集。
for (exposure_name in names(exposure_vars)) {
  d <- prepare_data(imputed_data[[1]], exposure_name)
  z <- make_split(d)
  tt_formula <- stats::as.formula(paste(
    "survival::Surv(time_from_2011_years, cmm_event_num) ~ exposure_iqr + tt(exposure_iqr) +",
    paste(m3_covariates, collapse = " + "), "+ cluster(community_id_fixed)"
  ))
  split_fit <- fit_checked(split_formula, z)
  tt_fit <- fit_checked(tt_formula, d, function(x, t, ...) x * log(t / reference_year))
  a <- c("exposure_iqr", "exposure_log_time")
  b <- c("exposure_iqr", "tt(exposure_iqr)")
  compare_row <- function(label, f1, f2, terms1, terms2) {
    coef_error <- max(abs(stats::coef(f1)[terms1] - stats::coef(f2)[terms2]))
    var_error <- max(abs(unname(stats::vcov(f1)[terms1, terms1]) -
                           unname(stats::vcov(f2)[terms2, terms2])))
    likelihood_error <- abs(tail(f1$loglik, 1) - tail(f2$loglik, 1))
    data.frame(exposure = exposure_name, test = label, coef_max_abs_error = coef_error,
               robust_cov_max_abs_error = var_error, loglik_abs_error = likelihood_error,
               passed = coef_error < 1e-6 && var_error < 1e-6 && likelihood_error < 1e-5)
  }
  validation_rows[[length(validation_rows) + 1L]] <- compare_row(
    "event_split_vs_tt", split_fit, tt_fit, a, b)
  base_right <- stats::as.formula(paste(
    "survival::Surv(time_from_2011_years, cmm_event_num) ~ exposure_iqr +",
    paste(m3_covariates, collapse = " + "), "+ cluster(community_id_fixed)"
  ))
  base_split <- stats::as.formula(paste(
    "survival::Surv(tstart, tstop, status) ~ exposure_iqr +",
    paste(m3_covariates, collapse = " + "), "+ cluster(community_id_fixed)"
  ))
  f1 <- fit_checked(base_right, d)
  f2 <- fit_checked(base_split, z)
  validation_rows[[length(validation_rows) + 1L]] <- compare_row(
    "constant_cox_before_vs_after_split", f1, f2, names(stats::coef(f1)), names(stats::coef(f2)))
  # 在每一个事件时点直接比较人数、事件数、权重总和及当前时间交互项。
  risk_checks <- do.call(rbind, lapply(event_times, function(t) {
    before <- d$time_from_2011_years >= t
    after <- z$tstart < t & z$tstop >= t
    current_error <- max(abs(z$exposure_log_time[after] -
                              z$exposure_iqr[after] * log(t / reference_year)))
    data.frame(exposure = exposure_name, event_time = t, n_before = sum(before),
               n_after = sum(after), events_before = sum(d$cmm_event_num[d$time_from_2011_years == t]),
               events_after = sum(z$status[z$tstop == t]),
               weight_sum_error = abs(sum(d$analysis_weight[before]) - sum(z$analysis_weight[after])),
               current_time_max_error = current_error,
               unique_persons = length(unique(z$person_row[after])))
  }))
  stopifnot(all(risk_checks$n_before == risk_checks$n_after),
            all(risk_checks$n_after == risk_checks$unique_persons),
            all(risk_checks$events_before == risk_checks$events_after),
            all(risk_checks$weight_sum_error < 1e-7),
            all(risk_checks$current_time_max_error < 1e-10))
  write.csv(risk_checks, file.path(trace_dir, paste0("05_risksets_", exposure_name, ".csv")),
            row.names = FALSE, fileEncoding = "UTF-8")
  rm(d, z, split_fit, tt_fit, f1, f2)
  gc(verbose = FALSE)
}
validation_table <- do.call(rbind, validation_rows)
write.csv(validation_table, file.path(trace_dir, "06_independent_method_validation.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
if (!all(validation_table$passed)) stop("Independent implementation validation failed.")
message("Independent event-split vs tt() and baseline-riskset checks passed.")

fit_one <- function(d, exposure_name, imputation) {
  d <- prepare_data(d, exposure_name)
  z <- make_split(d)
  f <- fit_checked(split_formula, z)
  fit_audit_rows[[length(fit_audit_rows) + 1L]] <<- data.frame(
    exposure = exposure_name, imputation = imputation, persons = nrow(d),
    split_rows = nrow(z), events = f$nevent,
    communities = length(unique(z$community_id_fixed)), iterations = max(f$iter),
    warnings = 0L, robust_variance = !is.null(f$naive.var),
    time_reference_year = reference_year
  )
  message(exposure_name, " imputation ", imputation, "/20 fitted.")
  # 只保留合并所需的系数和稳健协方差，避免60个展开模型耗尽内存。
  list(beta = stats::coef(f)[model_terms],
       covariance = stats::vcov(f)[model_terms, model_terms, drop = FALSE])
}

model_lists <- lapply(names(exposure_vars), function(exposure_name) {
  lapply(seq_along(imputed_data), function(i) {
    fit_one(imputed_data[[i]], exposure_name, i)
  })
})
names(model_lists) <- names(exposure_vars)
write.csv(do.call(rbind, fit_audit_rows), file.path(trace_dir, "07_model_fit_audit.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

pool_terms <- function(fits, exposure_name, term_names) {
  coefficient_matrix <- do.call(rbind, lapply(fits, function(f) {
    f$beta[term_names]
  }))
  covariance_list <- lapply(
    fits, function(f) f$covariance[term_names, term_names, drop = FALSE]
  )
  pooled_beta <- colMeans(coefficient_matrix)
  within_cov <- Reduce("+", covariance_list) / length(fits)
  between_cov <- stats::cov(coefficient_matrix)
  total_cov <- within_cov + (1 + 1 / length(fits)) * between_cov

  output <- lapply(seq_along(term_names), function(j) {
    term <- term_names[[j]]
    q <- coefficient_matrix[, j]
    u <- vapply(covariance_list, function(x) x[j, j], numeric(1))
    within <- mean(u)
    between <- stats::var(q)
    total_var <- within + (1 + 1 / length(q)) * between
    se <- sqrt(total_var)
    df <- if (between <= .Machine$double.eps) Inf else
      (length(q) - 1) *
      (1 + within / ((1 + 1 / length(q)) * between))^2
    statistic <- pooled_beta[[j]] / se
    p_value <- if (is.finite(df)) {
      2 * stats::pt(abs(statistic), df, lower.tail = FALSE)
    } else {
      2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
    }
    critical <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
    data.frame(
      exposure = exposure_name, term = term, imputations = length(q),
      beta = pooled_beta[[j]], robust_SE = se, HR = exp(pooled_beta[[j]]),
      CI_95_low = exp(pooled_beta[[j]] - critical * se),
      CI_95_high = exp(pooled_beta[[j]] + critical * se),
      p_value = p_value, df = df, within_variance = within,
      between_variance = between, n = 15061L, events = 1117L,
      communities = 446L, stringsAsFactors = FALSE
    )
  })
  list(table = do.call(rbind, output), beta = pooled_beta,
       covariance = total_cov)
}

pooled <- lapply(names(model_lists), function(exposure_name) {
  pool_terms(model_lists[[exposure_name]], exposure_name,
             model_terms)
})
names(pooled) <- names(model_lists)
pooled_table <- do.call(rbind, lapply(pooled, function(x) x[["table"]]))
write.csv(pooled_table, file.path(result_dir, "01_M3_time_interaction_Rubin.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

per_imputation <- do.call(rbind, lapply(names(model_lists), function(exposure_name) {
  fits <- model_lists[[exposure_name]]
  do.call(rbind, lapply(seq_along(fits), function(i) {
    f <- fits[[i]]
    coefficient <- f$beta[[time_term]]
    se <- sqrt(f$covariance[time_term, time_term])
    statistic <- unname(coefficient / se)
    p_value <- 2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
    data.frame(
      exposure = exposure_name, imputation = i,
      beta_time = unname(coefficient), robust_SE = se,
      p_value_time = p_value, n = 15061L, events = 1117L,
      communities = 446L, stringsAsFactors = FALSE
    )
  }))
}))
write.csv(per_imputation, file.path(data_dir, "01_per_imputation_time_interaction.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
consistency <- do.call(rbind, lapply(
  split(per_imputation, per_imputation$exposure), function(z) {
    data.frame(
      exposure = z$exposure[[1]], imputations = nrow(z),
      p_below_0_05 = sum(z$p_value_time < .05),
      p_below_0_01 = sum(z$p_value_time < .01),
      p_min = min(z$p_value_time), p_median = median(z$p_value_time),
      p_max = max(z$p_value_time), stringsAsFactors = FALSE
    )
  }
))
write.csv(consistency, file.path(result_dir, "02_time_interaction_consistency.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

# 三、输出不同随访时间点的时间变化HR -------------------------------------------
# 只在确实观察到事件的时间范围内画图；不把第1年外推当作观测证据。
time_grid <- sort(unique(c(seq(min(event_times), max(event_times), length.out = 160),
                           c(2, 4, 7, 9))))
time_effects <- do.call(rbind, lapply(names(pooled), function(exposure_name) {
  do.call(rbind, lapply(time_grid, function(t) {
    design <- c(1, log(t / reference_year))
    fits <- model_lists[[exposure_name]]
    q <- vapply(fits, function(f) sum(design * f$beta), numeric(1))
    u <- vapply(fits, function(f) as.numeric(t(design) %*% f$covariance %*% design), numeric(1))
    estimate <- mean(q)
    within <- mean(u)
    between <- stats::var(q)
    se <- sqrt(within + (1 + 1 / length(q)) * between)
    df <- if (between <= .Machine$double.eps) Inf else
      (length(q) - 1) * (1 + within / ((1 + 1 / length(q)) * between))^2
    critical <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
    data.frame(
      exposure = exposure_name, time_years = t,
      HR = exp(estimate), CI_95_low = exp(estimate - critical * se),
      CI_95_high = exp(estimate + critical * se),
      beta = estimate, robust_SE = se, df = df,
      within_variance = within, between_variance = between,
      stringsAsFactors = FALSE
    )
  }))
}))
write.csv(time_effects, file.path(result_dir, "03_time_varying_HR_data.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
write.csv(time_effects[time_effects$time_years %in% c(2, 4, 7, 9), ],
          file.path(result_dir, "05_HR_at_years_2_4_7_9.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
saveRDS(list(models = model_lists, pooled = pooled,
             reference_year = reference_year, event_times = event_times),
        file.path(data_dir, "02_corrected_coefficients_and_covariances.rds"))

# 作图单独放在03脚本；修改排版时只运行03，不必再拟合60个模型。
source(file.path(phase_root, "代码", substep, "03_仅重绘时间变化HR图.R"),
       encoding = "UTF-8")

# 四、写入说明、运行日志和模型规范 --------------------------------------------
interaction_summary <- pooled_table[
  pooled_table$term == time_term, , drop = FALSE
]
format_p <- function(x) ifelse(x < .001, "<0.001", sprintf("%.3f", x))
summary_lines <- c(
  "# Step 08-06: time-varying effect check",
  "",
  "## Scope",
  "",
  "Tmean, DTR and Bnum were selected because their exposure terms repeatedly showed PH signals in 20 imputations across M1, M2 and revised M3. TV, Anum and CEnum did not show persistent exposure-term signals.",
  "",
  "A PH signal means that the exposure HR may vary over follow-up. It is not a data error and does not change the risk set, event definition, exposure values, imputations or main-model covariates.",
  "",
  "## Model specification",
  "",
  "CORRECTED 2026-10-29: Event-time split Cox with exposure x log(t/4), where t is current event time for everyone in the risk set. The analysis uses 15,061 persons, 1,117 incident CMM events, 446 communities and 20 MICE datasets. Revised M3 covariates, normalized individual weights, community-cluster robust covariance, Efron ties and Rubin pooling are retained. The main coefficient is the per-IQR log HR at year 4. Both coefficients and pointwise HR(t) confidence intervals use Rubin within- and between-imputation variances with t critical values. First-imputation event-split models agree with tt() for all three exposures; constant-coefficient models agree before and after splitting.",
  "",
  "## Results",
  "",
  "| Exposure | Time-interaction HR | 95% CI | P value | P<0.05 among 20 |",
  "|---|---:|---:|---:|---:|",
  vapply(seq_len(nrow(interaction_summary)), function(i) {
    z <- interaction_summary[i, ]
    c <- consistency[consistency$exposure == z$exposure, , drop = FALSE]
    paste0("| ", z$exposure, " | ", sprintf("%.3f", z$HR), " | ",
           sprintf("%.3f-%.3f", z$CI_95_low, z$CI_95_high), " | ",
           format_p(z$p_value), " | ", c$p_below_0_05, "/20 |")
  }, character(1)),
  "",
  "P<0.05 supports departure from a constant exposure coefficient under the specified log-time function. P>=0.05 does not establish PH. The unweighted diagnostic cox.zph tests and these weighted clustered log-time tests are different tests. The exponential time coefficient is the multiplier of the per-IQR HR when time increases by a factor of e; it is not the exposure HR itself. Plots are restricted to the observed event-time range. Later estimates rely on fewer events and a log-time functional assumption. This is an added time-varying coefficient analysis of fixed baseline exposure, not a change in exposure over follow-up.",
  "",
  "## Files",
  "",
  "01_M3_time_interaction_Rubin.csv: pooled main and time-interaction terms.",
  "02_time_interaction_consistency.csv: per-imputation interaction P-value consistency.",
  "03_time_varying_HR_data.csv: pointwise HR(t) and 95% CI within observed event support.",
  "04_time_varying_HR.svg/pdf: vector figure.",
  "05_HR_at_years_2_4_7_9.csv: time-specific HR for manuscript review.",
  "",
  "Step 07 fixed-coefficient estimates are unchanged but must not be interpreted as a constant HR when time variation is supported. The invalid fixed-final-time results are archived and must not be cited."
)
writeLines(summary_lines, file.path(result_dir, "00_results.md"), useBytes = TRUE)
writeLines(c(
  "This is a focused diagnostic supplement and does not rebuild the primary model.",
  "Tmean, DTR and Bnum were selected because their exposure terms had persistent PH signals in 20 imputations; TV, Anum and CEnum did not.",
  "Model: revised M3, individual weights, community-cluster robust variance, Rubin pooling.",
  "Time term: exposure_IQR x log(current event time / 4); log(4/4)=0.",
  "Exposure scaling: (exposure - risk-set median) / risk-set IQR.",
  "Interpretation: a PH signal means possible time variation, not a data error or a reason to delete a variable."
), file.path(trace_dir, "03_why_three_exposures.md"), useBytes = TRUE)
writeLines(c(
  paste0("Run time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
  "Script: 01_time_varying_effect_check_M3.R",
  "Risk set: 15061 persons; CMM events: 1117; communities: 446; MICE m=20, maxit=25.",
  "Completion: input gate, 3 exposures x 20 imputations and Rubin pooled results generated.",
  capture.output(sessionInfo())
), file.path(trace_dir, "04_run_log_sessionInfo.txt"), useBytes = TRUE)
message("Step 08-06 time-varying effect check complete: ", result_dir)
writeLines(c(
  "PASS: frozen input SHA256 and all 20 imputations passed.",
  "PASS: 3 event-split vs tt() coefficient/robust-covariance/log-likelihood checks.",
  "PASS: 3 constant-coefficient models unchanged by riskset splitting.",
  "PASS: every event-time riskset count, event count, weight sum and interaction value.",
  "PASS: 60 warning-free weighted clustered fits; Rubin pooling and pointwise t intervals.",
  "This computational closure does not imply proportional hazards holds."
), file.path(trace_dir, "08_computational_closure.txt"), useBytes = TRUE)
