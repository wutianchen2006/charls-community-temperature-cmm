# ============================================================================
# 第十九篇预分析 | 步骤10：敏感性分析（统一入口）
#
# 目的：在不改变主分析riskset、主模型或主暴露定义的前提下，检查四件事：
#   1) 建成环境题项必须全部观测时，结果是否改变；
#   2) 随访只keep_2018年时，结果是否改变；
#   3) 2008--2010温度窗口去掉其中一年时，结果是否改变；
#   4) 城乡分层后，结果方向是否一致。
#
# 统一口径：修订版M3、个体权重、社区聚类稳健方差、Efron ties、Rubin规则。
# 迁移人口分析由独立脚本运行，避免把 CHARLSMAX 地址提取和常规敏感性结果混在一个脚本中。
# 本脚本只读取上游riskset和MICE对象，不覆盖主分析结果。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
# Windows 中文项目路径需要使用系统中文代码页，保证 RStudio/ Rscript 均能定位输入输出文件。
try(Sys.setlocale("LC_CTYPE", "Chinese_China.936"), silent = TRUE)
suppressPackageStartupMessages({
  library(survival)
  library(mice)
  library(digest)
})

project_root <- Sys.getenv(
  "P19_PROJECT_ROOT",
  unset = Sys.getenv("P19_PROJECT_ROOT", unset = "analysis")
)
riskset_path <- Sys.getenv(
  "P19_RISKSET_PATH",
  unset = file.path(project_root, "02_人群纳排与风险集/数据/人群筛选_20261022/2011_2020_CMM主风险集_年龄45岁及以上.rds")
)
mids_path <- Sys.getenv(
  "P19_MIDS_PATH",
  unset = file.path(project_root, "06_ABC多重插补/数据/PartB_MICE_m20_maxit25_seed20261025.rds")
)
step_dir <- Sys.getenv("P19_SENSITIVITY_DIR", unset = file.path(project_root, "10_敏感性分析"))
# 原始模型输出统一进入结果/99_原始输出_审计保留；投稿子目录只放经过筛选的结果表。
result_dir <- Sys.getenv("P19_SENSITIVITY_RESULT_DIR", unset = file.path(step_dir, "结果", "99_原始输出_审计保留"))
trace_dir <- Sys.getenv("P19_SENSITIVITY_TRACE_DIR", unset = file.path(step_dir, "追溯文件"))
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(trace_dir, recursive = TRUE, showWarnings = FALSE)

if (!all(file.exists(c(riskset_path, mids_path)))) {
  stop("缺少输入：", paste(c(riskset_path, mids_path)[!file.exists(c(riskset_path, mids_path))], collapse = "；"))
}

# --------------------------- 1. 读取并核对输入 -------------------------------
riskset <- readRDS(riskset_path)
mids_obj <- readRDS(mids_path)
event_int <- function(x) suppressWarnings(as.integer(as.character(x)))
if (!inherits(mids_obj, "mids")) stop("MICE输入不是mids对象。")
if (mids_obj$m != 20L || mids_obj$iteration != 25L) stop("MICE设置不是m=20、maxit=25。")
if (nrow(riskset) != 15061L || sum(event_int(riskset$cmm_event)) != 1117L) {
  stop("冻结riskset不是15,061人、1,117例事件。")
}

exposures <- c(
  TV = "temperature_TV_daily_annual_mean_pre2011",
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010",
  Anum = "built_Anum",
  Bnum = "built_Bnum",
  CEnum = "built_CEnum"
)
m3_covariates <- c(
  "Age", "Gender", "Residence", "Education_Status", "Marital_status",
  "Smoking_Status", "Drinking_Status", "household_income", "BMI2011",
  "Regional_Category_2011"
)
# MICE对象只保存插补数据框中的协变量；固定暴露、结局和随访时间保存在冻结riskset。
# 因此核验两类输入的联合列集合，而不是只检查 mids_obj$data。
probe_completed <- mice::complete(mids_obj, action = 1)
required_vars <- unique(c(unname(exposures), m3_covariates, "cmm_event", "time_from_2011_years"))
available_vars <- union(names(probe_completed), names(riskset))
if (!all(required_vars %in% available_vars)) {
  stop("输入文件联合缺少：", paste(setdiff(required_vars, available_vars), collapse = "、"))
}

# 留一年温度敏感性所需的年度列也来自冻结riskset。
fixed_from_riskset <- intersect(
  c(
    unname(exposures), "cmm_event", "time_from_2011_years", "Y_new_cmm18", "duration11_18",
    paste0("temperature_tv_daily_sd_annual_", 2008:2010),
    paste0("temperature_tmean_annual_", 2008:2010),
    paste0("temperature_dtr_annual_", 2008:2010)
  ),
  names(riskset)
)

# 每份插补数据只补covariates；固定列从冻结riskset按行接回，确保20份数据使用同一风险集。
completed_list <- lapply(seq_len(mids_obj$m), function(i) {
  d <- mice::complete(mids_obj, action = i)
  if (nrow(d) != nrow(riskset)) stop("第", i, "份插补数据行数不符。")
  d[fixed_from_riskset] <- riskset[fixed_from_riskset]
  d$ID_fixed <- as.character(riskset$ID)
  d$community_id_fixed <- as.character(riskset$community_id)
  d$individual_weight_fixed <- as.numeric(riskset$individual_weight)
  d
})

# 固定题项完整性：严格完整是某个评分的全部组成题项均有观测值。
anum_items <- paste0("built_", c(
  "a1", "a2", "a3", "a4", "b1", "b2", "b3", "b4", "b5", "b6", "b7",
  "c1", "c2", "c3", "c4", "c5", "d1", "d2", "d3", "d4", "d5"
))
bnum_items <- paste0("built_", paste0("e", 1:5))
cenum_items <- c(anum_items, bnum_items)
strict_flags <- list(
  Anum = rowSums(!is.na(riskset[anum_items])) == length(anum_items),
  Bnum = rowSums(!is.na(riskset[bnum_items])) == length(bnum_items),
  CEnum = rowSums(!is.na(riskset[cenum_items])) == length(cenum_items)
)
strict_counts <- do.call(rbind, lapply(names(strict_flags), function(nm) {
  flag <- strict_flags[[nm]]
  data.frame(
    sensitivity = "strict_item_complete",
    score = nm,
    n_items = length(if (nm == "Anum") anum_items else if (nm == "Bnum") bnum_items else cenum_items),
    complete_n = sum(flag),
    incomplete_n = sum(!flag),
    complete_percent = 100 * mean(flag),
    stringsAsFactors = FALSE
  )
}))
write.csv(strict_counts, file.path(result_dir, "S01_严格完整题项人数.csv"), row.names = FALSE, fileEncoding = "UTF-8")

# 2008--2010中去掉一年，形成三个两年平均窗口；不改变主分析三年窗口。
temp_columns <- list(
  TV = setNames(paste0("temperature_tv_daily_sd_annual_", 2008:2010), 2008:2010),
  Tmean = setNames(paste0("temperature_tmean_annual_", 2008:2010), 2008:2010),
  DTR = setNames(paste0("temperature_dtr_annual_", 2008:2010), 2008:2010)
)
leave_one_year <- list()
for (metric in names(temp_columns)) {
  for (omit_year in 2008:2010) {
    keep_years <- setdiff(2008:2010, omit_year)
    new_name <- paste0(metric, "_leave_", omit_year)
    riskset[[new_name]] <- rowMeans(riskset[paste0(temp_columns[[metric]][as.character(keep_years)])], na.rm = FALSE)
    leave_one_year[[new_name]] <- new_name
  }
}

# 上面的两年平均列是在 completed_list 建立后生成的，逐份插补数据也要同步接回。
completed_list <- lapply(completed_list, function(d) {
  d[names(leave_one_year)] <- riskset[names(leave_one_year)]
  d
})

calc_iqr <- function(x) {
  q <- stats::quantile(as.numeric(x), c(.25, .75), na.rm = TRUE, names = FALSE)
  as.numeric(q[2] - q[1])
}

# --------------------------- 2. pool_rubin和模型函数 --------------------------
pool_rubin <- function(models, analysis_name, exposure_name, n_used, events_used, communities_used) {
  term_names <- names(stats::coef(models[[1]]))
  if (any(!vapply(models, function(f) identical(names(stats::coef(f)), term_names), logical(1)))) {
    stop("模型系数名称不一致：", analysis_name, " / ", exposure_name)
  }
  do.call(rbind, lapply(term_names, function(term) {
    q <- vapply(models, function(f) unname(stats::coef(f)[term]), numeric(1))
    u <- vapply(models, function(f) unname(stats::vcov(f)[term, term]), numeric(1))
    m <- length(q); qbar <- mean(q); within <- mean(u); between <- stats::var(q)
    total <- within + (1 + 1 / m) * between
    se <- sqrt(total)
    df <- if (between <= .Machine$double.eps) Inf else
      (m - 1) * (1 + within / ((1 + 1 / m) * between))^2
    statistic <- qbar / se
    p <- if (is.finite(df)) 2 * stats::pt(abs(statistic), df, lower.tail = FALSE) else
      2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
    crit <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
    data.frame(
      analysis = analysis_name, exposure = exposure_name, term = term,
      imputations = m, beta = qbar, robust_SE = se, HR = exp(qbar),
      CI_95_low = exp(qbar - crit * se), CI_95_high = exp(qbar + crit * se),
      p_value = p, df = df, n = n_used, events = events_used,
      communities = communities_used, stringsAsFactors = FALSE
    )
  }))
}

fit_one <- function(d, exposure_column, exposure_name, covariates, time_column, event_column, iqr_value) {
  d$analysis_weight <- d$individual_weight_fixed / mean(d$individual_weight_fixed)
  d$exposure_IQR <- as.numeric(d[[exposure_column]]) / iqr_value
  d$event_num <- event_column
  d$time_num <- time_column
  form <- stats::as.formula(paste(
    "survival::Surv(time_num, event_num) ~ exposure_IQR +",
    paste(covariates, collapse = " + "), "+ cluster(community_id_fixed)"
  ))
  survival::coxph(
    form, data = d, weights = analysis_weight, ties = "efron",
    robust = TRUE, na.action = stats::na.fail, x = TRUE
  )
}

all_audit <- list(); all_results <- list(); idx <- 0L
run_group <- function(analysis_name, exposure_map, row_mask, time_values, event_values,
                    covariates = m3_covariates, stratification_label = "overall") {
  keep <- which(row_mask)
  n_used <- length(keep); events_used <- sum(event_values[keep])
  communities_used <- length(unique(riskset$community_id[keep]))
  if (n_used == 0L || events_used == 0L) stop("分析组没有可用样本或事件：", analysis_name)
  for (exposure_name in names(exposure_map)) {
    exposure_column <- exposure_map[[exposure_name]]
    iqr_value <- calc_iqr(riskset[[exposure_column]][keep])
    if (!is.finite(iqr_value) || iqr_value <= 0) stop("IQR无效：", analysis_name, " / ", exposure_name)
    models <- lapply(seq_len(mids_obj$m), function(i) {
      d <- completed_list[[i]][keep, , drop = FALSE]
      fit_one(d, exposure_column, exposure_name, covariates,
           time_values[keep], event_values[keep], iqr_value)
    })
    pooled <- pool_rubin(models, analysis_name, exposure_name, n_used, events_used, communities_used)
    pooled$stratum <- stratification_label
    pooled$exposure_IQR <- iqr_value
    all_results[[length(all_results) + 1L]] <<- pooled
    all_audit[[length(all_audit) + 1L]] <<- data.frame(
      analysis = analysis_name, exposure = exposure_name,
      stratum = stratification_label, imputation = seq_along(models),
      n = n_used, events = events_used, communities = communities_used,
      stringsAsFactors = FALSE
    )
  }
}

# --------------------------- 3. 严格完整题项敏感性 ---------------------------
# 只对与该评分对应的暴露运行；这样不会把另一个评分的缺失误当成该分析缺失。
for (score_name in names(strict_flags)) {
  exposure_name <- score_name
  run_group(
    analysis_name = paste0("strict_complete_", score_name),
    exposure_map = setNames(unname(exposures[score_name]), score_name),
    row_mask = strict_flags[[score_name]],
    time_values = as.numeric(riskset$time_from_2011_years),
    event_values = event_int(riskset$cmm_event)
  )
}

# --------------------------- 4. 2011--2018限定随访敏感性 ----------------------
# Y_new_cmm18=1表示2018年前新发CMM；duration11_18为月，换算为年。
keep_2018 <- !is.na(riskset$Y_new_cmm18) & !is.na(riskset$duration11_18)
time_2018 <- suppressWarnings(as.numeric(riskset$duration11_18)) / 12
event_2018 <- event_int(riskset$Y_new_cmm18)
if (sum(keep_2018) != 12431L || sum(event_2018[keep_2018]) != 853L) {
  stop("2011--2018限定随访人数或事件数不符合已核对值。")
}
run_group(
  analysis_name = "followup_2011_2018",
  exposure_map = exposures,
  row_mask = keep_2018,
  time_values = time_2018,
  event_values = event_2018
)

# --------------------------- 5. 留一年温度窗口敏感性 --------------------------
run_group(
  analysis_name = "temperature_leave_one_year",
  exposure_map = leave_one_year,
  row_mask = rep(TRUE, nrow(riskset)),
  time_values = as.numeric(riskset$time_from_2011_years),
  event_values = event_int(riskset$cmm_event)
)

# --------------------------- 6. 城乡分层敏感性 -------------------------------
# Residence在冻结riskset中无缺失；分层后从covariates中移除Residence，避免组内无变异。
for (residence_code in sort(unique(riskset$Residence))) {
  run_group(
    analysis_name = "residence_stratified",
    exposure_map = exposures,
    row_mask = riskset$Residence == residence_code,
    time_values = as.numeric(riskset$time_from_2011_years),
    event_values = event_int(riskset$cmm_event),
    covariates = setdiff(m3_covariates, "Residence"),
    stratification_label = paste0("Residence=", residence_code)
  )
}

# --------------------------- 7. 输出和追溯 -----------------------------------
results <- do.call(rbind, all_results); rownames(results) <- NULL
audit <- do.call(rbind, all_audit); rownames(audit) <- NULL
write.csv(results, file.path(result_dir, "S02_敏感性分析_M3_pool_rubin结果.csv"), row.names = FALSE, fileEncoding = "UTF-8")
write.csv(audit, file.path(trace_dir, "S01_敏感性分析_逐份插补审计.csv"), row.names = FALSE, fileEncoding = "UTF-8")

window_table <- data.frame(
  exposure = rep(c("TV", "Tmean", "DTR"), each = 3),
  omitted_year = rep(2008:2010, times = 3),
  retained_years = rep(c("2009,2010", "2008,2010", "2008,2009"), times = 3),
  definition = "两年年metric的算术平均；仅作敏感性分析，不替代主分析2008--2010三年窗口",
  stringsAsFactors = FALSE
)
write.csv(window_table, file.path(result_dir, "S03_温度留一年窗口定义.csv"), row.names = FALSE, fileEncoding = "UTF-8")

hash_table <- data.frame(
  file = c(riskset_path, mids_path),
  sha256 = c(digest::digest(riskset_path, file = TRUE, algo = "sha256"),
             digest::digest(mids_path, file = TRUE, algo = "sha256")),
  stringsAsFactors = FALSE
)
write.csv(hash_table, file.path(trace_dir, "S02_输入文件SHA256.csv"), row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c(
  paste0("运行时间：", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
  "分析：严格完整题项、2011--2018限定随访、温度留一年、城乡分层。",
  "统一模型：修订版M3；加权Cox；社区聚类稳健方差；Efron ties；Rubin规则。",
  paste0("冻结主riskset：", nrow(riskset), "人；主事件：", sum(event_int(riskset$cmm_event)), "例；社区：", length(unique(riskset$community_id))),
  paste0("严格完整人数：Anum=", sum(strict_flags$Anum), "；Bnum=", sum(strict_flags$Bnum), "；CEnum=", sum(strict_flags$CEnum)),
  paste0("2011--2018限定：", sum(keep_2018), "人；", sum(event_2018[keep_2018]), "例事件。"),
  "迁移排除由独立脚本03_migration_sensitivity_M3_20261028.R运行；其结果单独核验。",
  paste0("输出结果：", file.path(result_dir, "S02_敏感性分析_M3_pool_rubin结果.csv")),
  "运行完成标志：S02结果和S01逐份插补审计均成功生成。"
), file.path(trace_dir, "S03_运行闭环.txt"), useBytes = TRUE)

if (nrow(audit) != 20L * (3L + 6L + 9L + 12L)) {
  stop("逐份all_audit数不符合预期：", nrow(audit))
}
message("SENSITIVITY_COMPLETE：步骤10敏感性分析完成。")
