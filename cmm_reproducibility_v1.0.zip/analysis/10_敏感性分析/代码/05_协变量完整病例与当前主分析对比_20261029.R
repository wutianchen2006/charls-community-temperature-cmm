# ==============================================================================
# 协变量完整病例敏感性分析：与当前六暴露修订M3逐项对比
# 在RStudio以UTF-8打开本脚本，点击Source即可运行。
# 为什么补做：旧完整病例表仍使用含基线CMM组分数的旧M3，不能代表当前口径。
# 本脚本只补做6个完整病例Cox模型，不重跑插补或主分析，不覆盖旧结果。
# ==============================================================================
options(stringsAsFactors = FALSE, encoding = "UTF-8")
library(survival)
if (!requireNamespace("digest", quietly = TRUE)) stop("缺少digest包，请核对已有环境。")

# 1. 明确输入与输出路径。原始风险集只读取，不修改。
project_dir <- Sys.getenv("P19_PROJECT_ROOT",
  unset = Sys.getenv("P19_PROJECT_ROOT", unset = "analysis"))
step_dir <- file.path(project_dir, "10_敏感性分析")
result_dir <- file.path(step_dir, "结果", "07_协变量完整病例_20261029")
trace_dir <- file.path(step_dir, "追溯文件", "07_协变量完整病例_20261029")
data_dir <- file.path(step_dir, "数据", "07_协变量完整病例_20261029")
for (p in c(result_dir, trace_dir, data_dir)) dir.create(p, recursive = TRUE, showWarnings = FALSE)
risk_file <- file.path(project_dir,
  "02_人群纳排与风险集/数据/人群筛选_20261022/2011_2020_CMM主风险集_年龄45岁及以上.rds")
observed_file <- file.path(project_dir,
  "06_ABC多重插补/数据/PartB_MICE_input_prepared_20261025.rds")
main_file <- file.path(project_dir,
  "07_模型分析/结果/Part_C_主模型_20261025_六暴露_M3修订/C02_六暴露_M1_M2_M3_主要效应_HR每IQR.csv")
inputs <- c(risk_file, observed_file, main_file)
if (!all(file.exists(inputs))) stop("缺少冻结输入文件，停止。")
risk <- readRDS(risk_file)
# observed是正式插补之前准备的输入，仍保留原始缺失；不是任何一次插补完成数据。
observed <- readRDS(observed_file)
main <- read.csv(main_file, fileEncoding = "UTF-8-BOM")
as_number <- function(x) suppressWarnings(as.numeric(as.character(x)))
stopifnot(nrow(risk) == 15061L, nrow(observed) == nrow(risk))
stopifnot(sum(as_number(risk$cmm_event)) == 1117L)

# 2. 与当前主分析完全相同的暴露及M3协变量。
exposures <- c(TV = "temperature_TV_daily_annual_mean_pre2011",
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010",
  Anum = "built_Anum", Bnum = "built_Bnum", CEnum = "built_CEnum")
covariates <- c("Age", "Gender", "Residence", "Education_Status", "Marital_status",
  "Smoking_Status", "Drinking_Status", "household_income", "BMI2011", "Regional_Category_2011")
required <- unique(c(unname(exposures), covariates, "cmm_event", "time_from_2011_years"))
stopifnot(all(required %in% names(observed)))
# 核对行顺序上的固定列后，才从风险集接回权重、社区和ID。
for (v in c(unname(exposures), "cmm_event", "time_from_2011_years")) {
  if (!isTRUE(all.equal(as_number(risk[[v]]), as_number(observed[[v]]),
                       check.attributes = FALSE))) stop("固定列不一致：", v)
}
observed$ID_fixed <- as.character(risk$ID)
observed$community_id_fixed <- as.character(risk$community_id)
observed$individual_weight_fixed <- as_number(risk$individual_weight)
stopifnot(!anyNA(observed$ID_fixed), !anyDuplicated(observed$ID_fixed))

# 3. 只保留当前M3全部协变量和固定分析列均有观测的人。
# 这里没有对缺失值进行插补，也没有因为P值改变样本或协变量。
complete_flag <- complete.cases(observed[, required, drop = FALSE])
cc <- observed[complete_flag, , drop = FALSE]
stopifnot(nrow(cc) == 7167L, sum(as_number(cc$cmm_event)) == 583L,
          length(unique(cc$community_id_fixed)) == 422L)
stopifnot(all(is.finite(cc$individual_weight_fixed) & cc$individual_weight_fixed > 0))
write.csv(data.frame(stage = c("Frozen cohort", "Complete covariates", "Incomplete covariates"),
  n = c(nrow(observed), nrow(cc), sum(!complete_flag)),
  events = c(1117L, 583L, sum(as_number(observed$cmm_event[!complete_flag])))),
  file.path(result_dir, "CC01_sample_flow.csv"), row.names = FALSE, fileEncoding = "UTF-8")

# 4. 固定为全体15,061人的IQR，确保HR与主分析表示同样大小的暴露增量。
# 不能重新使用7,167人子样本的IQR，否则两个HR的单位不同。
iqrs <- vapply(exposures, function(v) stats::IQR(as_number(risk[[v]]), na.rm = TRUE), numeric(1))
stopifnot(all(is.finite(iqrs) & iqrs > 0))
main <- main[main$model == "M3_revised" & main$term == "exposure_IQR", ]
stopifnot(nrow(main) == 6L, all(main$n == 15061L), all(main$events == 1117L))
for (e in names(exposures)) {
  stopifnot(isTRUE(all.equal(unname(iqrs[e]), main$exposure_IQR[main$exposure == e], tolerance = 1e-10)))
}

# 5. 六个暴露分别建模；沿用个体权重、社区聚类稳健方差和Efron并列事件处理。
# 完整病例只需拟合一次，不使用Rubin合并；主分析一栏读取既有20份合并结果。
cc$analysis_weight <- cc$individual_weight_fixed / mean(cc$individual_weight_fixed)
cc$cmm_event_num <- as_number(cc$cmm_event)
formula <- as.formula(paste("Surv(time_from_2011_years, cmm_event_num) ~ exposure_IQR +",
  paste(covariates, collapse = " + "), "+ cluster(community_id_fixed)"))
results <- lapply(names(exposures), function(e) {
  message("完整病例修订M3：", e)
  cc$exposure_IQR <- as_number(cc[[exposures[e]]]) / iqrs[e]
  fit <- withCallingHandlers(coxph(formula, data = cc, weights = analysis_weight,
    ties = "efron", robust = TRUE, na.action = na.fail, x = TRUE),
    warning = function(w) stop("模型产生警告，需要核查：", conditionMessage(w)))
  stopifnot(fit$n == 7167L, fit$nevent == 583L)
  beta <- unname(coef(fit)["exposure_IQR"])
  se <- sqrt(unname(vcov(fit)["exposure_IQR", "exposure_IQR"]))
  stopifnot(is.finite(beta), is.finite(se), se > 0)
  ref <- main[main$exposure == e, ]
  data.frame(exposure = e, exposure_IQR = unname(iqrs[e]),
    main_n = ref$n, main_events = ref$events, main_HR = ref$HR,
    main_CI_low = ref$CI_95_low, main_CI_high = ref$CI_95_high, main_P = ref$p_value,
    cc_n = fit$n, cc_events = fit$nevent, cc_communities = 422L,
    cc_HR = exp(beta), cc_CI_low = exp(beta - qnorm(.975) * se),
    cc_CI_high = exp(beta + qnorm(.975) * se), cc_P = 2 * pnorm(abs(beta / se), lower.tail = FALSE),
    direction_same = sign(beta) == sign(log(ref$HR)),
    cc_to_main_HR_ratio = exp(beta) / ref$HR)
})
comparison <- do.call(rbind, results)
write.csv(comparison, file.path(result_dir, "CC02_current_M3_main_vs_complete_case.csv"),
  row.names = FALSE, fileEncoding = "UTF-8")

# 6. 生成作者可阅读的对比表，结论根据本次实际结果逐项产生。
format_p <- function(p) ifelse(p < .001, "<0.001", sprintf("%.3f", p))
table_rows <- vapply(seq_len(nrow(comparison)), function(i) {
  x <- comparison[i, ]
  sprintf("| %s | %.3f (%.3f–%.3f) | %s | %.3f (%.3f–%.3f) | %s | %s |",
    x$exposure, x$main_HR, x$main_CI_low, x$main_CI_high, format_p(x$main_P),
    x$cc_HR, x$cc_CI_low, x$cc_CI_high, format_p(x$cc_P),
    if (x$direction_same) "方向一致" else "方向不同")
}, character(1))
writeLines(c("# 协变量完整病例与当前主分析对比", "", "更新日期：2026-10-29。",
  "", "## 方法", "",
  "主分析：15,061人、1,117例事件、446个社区；20份MICE数据拟合后Rubin合并。",
  "完整病例：只保留插补前当前M3全部协变量有观测的7,167人、583例事件、422个社区；不插补。",
  "六暴露分别使用当前修订M3：年龄、性别、城乡、教育、婚姻、吸烟、饮酒、家庭收入、BMI2011、东中西区域；不含baseline_CMM_component_count。",
  "两者使用同一全风险集IQR、个体权重、社区聚类稳健方差和Efron ties。",
  "这是协变量缺失的完整病例分析，不是建成环境26题全部完整的评分敏感性分析。",
  "", "## 对比结果", "",
  "| 暴露（每IQR） | 插补主分析HR（95% CI） | P | 完整病例HR（95% CI） | P | 方向对比 |",
  "|---|---:|---:|---:|---:|---|", table_rows, "",
  sprintf("六个暴露中%d个方向相同；完整病例中%d个P<0.05。方向一致不能自动解释为效应量一致或全部稳健。",
    sum(comparison$direction_same), sum(comparison$cc_P < .05)), "",
  "完整病例保留47.59%的人群，排除的7,894人并非随机抽样；差异可能来自样本构成、精度变化及缺失处理，不能仅凭P值判断插补有无偏倚或哪种方法更正确。即使方向相同，也应报告置信区间与效应量差异。",
  "", "## 旧结果边界", "",
  "步骤07旧C04表使用修订前M3，只含TV、Anum、Bnum、CEnum。本文件才是与当前六暴露修订M3可直接比较的完整病例结果；旧表保留追溯，不覆盖。",
  "", "## 复现与来源", "",
  "代码：步骤10/代码/05_协变量完整病例与当前主分析对比_20261029.R。输入路径及SHA256见步骤10/数据/07_协变量完整病例_20261029/输入来源.csv；运行环境和检查结果见对应追溯目录。",
  "本次没有重跑多重插补、变更主风险集或修改主分析结果。"),
  file.path(result_dir, "README.md"), useBytes = TRUE)
input_register <- data.frame(path = inputs,
  sha256 = vapply(inputs, function(p) digest::digest(p, file = TRUE, algo = "sha256"), character(1)))
write.csv(input_register, file.path(data_dir, "输入来源.csv"), row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c(paste("运行时间：", Sys.time()), "6个模型均无警告；各模型7167人、583例事件、422社区。",
  paste("同方向暴露：", sum(comparison$direction_same), "/ 6"), deparse(formula)),
  file.path(trace_dir, "运行核查.txt"), useBytes = TRUE)
capture.output(sessionInfo(), file = file.path(trace_dir, "sessionInfo.txt"))
message("COMPLETE_CASE_CURRENT_M3_DONE：", result_dir)
