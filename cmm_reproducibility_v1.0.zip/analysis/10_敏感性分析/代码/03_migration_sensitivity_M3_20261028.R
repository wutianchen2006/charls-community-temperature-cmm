# ============================================================================
# 第十九篇预分析 | 步骤10：迁移人口敏感性分析（修订 M3）
#
# 目的：按罗丹老师代码的地址变化规则，排除 2011--2015 年间可识别的
# 地址变化者，再在同一套 20 份 MICE 数据上重跑修订 M3。
#
# 规则：
#   1. permanent_address_2013 为 2，视为 2011--2013 地址变化；
#   2. current_address_2015 为 2 或 3，视为 2013--2015 地址变化；
#   3. 两个地址变量任一缺失者不判定为“未迁移”，从敏感性分析样本中排除；
#   4. 主风险集、主模型结果和其他敏感性结果均不覆盖。
#
# 这是敏感性分析，不是对迁移时间的精确事件史重建；结果只用于检验地址
# 变化者排除后主结果方向是否保持。
# ============================================================================

options(stringsAsFactors = FALSE, scipen = 999, encoding = "UTF-8")
try(Sys.setlocale("LC_CTYPE", "Chinese_China.936"), silent = TRUE)
suppressPackageStartupMessages({
  library(survival)
  library(mice)
})

project_root <- Sys.getenv(
  "P19_PROJECT_ROOT",
  unset = Sys.getenv("P19_PROJECT_ROOT", unset = "analysis")
)
riskset_path <- Sys.getenv("P19_RISKSET_PATH", unset = "")
if (!nzchar(riskset_path)) {
  riskset_dir <- Sys.getenv("P19_RISKSET_DIR", unset = file.path(project_root, "02_人群纳排与风险集", "数据", "人群筛选_20261022"))
  riskset_candidates <- list.files(riskset_dir, pattern = "2011_2020_CMM.*\\.rds$", full.names = TRUE)
  if (length(riskset_candidates) != 1L) stop("无法唯一定位冻结风险集 RDS。")
  riskset_path <- riskset_candidates[[1L]]
}
mids_path <- Sys.getenv("P19_MIDS_PATH", unset = "")
if (!nzchar(mids_path)) {
  mids_dir <- Sys.getenv("P19_MIDS_DIR", unset = file.path(project_root, "06_ABC多重插补", "数据"))
  mids_candidates <- list.files(mids_dir, pattern = "PartB_MICE_m20_maxit25.*\\.rds$", full.names = TRUE)
  if (length(mids_candidates) != 1L) stop("无法唯一定位 MICE RDS。")
  mids_path <- mids_candidates[[1L]]
}
migration_path <- Sys.getenv(
  "P19_MIGRATION_DATA_PATH",
  unset = file.path(project_root, "10_敏感性分析", "数据",
                    "S06_CHARLSMAX_2013_2015_address_minimal.rds")
)
result_dir <- Sys.getenv("P19_SENSITIVITY_RESULT_DIR",
                         unset = file.path(project_root, "10_敏感性分析", "结果", "99_原始输出_审计保留"))
trace_dir <- Sys.getenv("P19_SENSITIVITY_TRACE_DIR",
                        unset = file.path(project_root, "10_敏感性分析", "追溯文件"))
dir.create(result_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(trace_dir, recursive = TRUE, showWarnings = FALSE)

required_files <- c(riskset_path, mids_path, migration_path)
if (!all(file.exists(required_files))) {
  stop("缺少输入：", paste(required_files[!file.exists(required_files)], collapse = "; "))
}

riskset <- readRDS(riskset_path)
mids_obj <- readRDS(mids_path)
address_data <- readRDS(migration_path)
if (!inherits(mids_obj, "mids")) stop("MICE 输入不是 mids 对象。")
if (mids_obj$m != 20L || mids_obj$iteration != 25L) stop("MICE 不是 m=20、maxit=25。")
if (nrow(riskset) != 15061L || sum(as.integer(as.character(riskset$cmm_event))) != 1117L) {
  stop("冻结风险集不是 15,061 人、1,117 例事件。")
}
if (anyDuplicated(as.character(riskset$ID)) || anyDuplicated(as.character(address_data$ID))) {
  stop("风险集或 CHARLSMAX 地址数据存在重复 ID。")
}

# 标准化 ID 后按风险集顺序匹配，不能用行号直接拼接。
riskset_id <- trimws(as.character(riskset$ID))
address_id <- trimws(as.character(address_data$ID))
match_index <- match(riskset_id, address_id)
address_2013 <- address_data$permanent_address_2013[match_index]
address_2015 <- address_data$current_address_2015[match_index]
observed_both <- !is.na(address_2013) & !is.na(address_2015)

# 与罗丹老师代码一致的地址变化判定；比较前统一转字符并去除首尾空格。
address_2013_chr <- trimws(as.character(address_2013))
address_2015_chr <- trimws(as.character(address_2015))
moved_by_rule <- observed_both & (
  address_2013_chr == "2 Province_City_County/City/District/Village/Neighborhood" |
    address_2015_chr %in% c(
      "2 Other Province/City/County Township Villiage/Neiborhood",
      "3 Abroad"
    )
)
keep_no_move <- observed_both & !moved_by_rule

sample_audit <- data.frame(
  item = c("riskset_n", "riskset_events", "matched_2013_or_2015", "both_addresses_observed",
           "missing_any_address", "excluded_by_teacher_rule", "kept_no_move", "kept_events"),
  value = c(
    nrow(riskset),
    sum(as.integer(as.character(riskset$cmm_event))),
    sum(!is.na(match_index)),
    sum(observed_both),
    sum(!observed_both),
    sum(moved_by_rule),
    sum(keep_no_move),
    sum(as.integer(as.character(riskset$cmm_event))[keep_no_move])
  ),
  stringsAsFactors = FALSE
)
write.csv(sample_audit, file.path(trace_dir, "S10_migration_sample_audit.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")

writeLines(c(
  "Migration sensitivity definition",
  "",
  "Source: CHARLSMAX 2013 permanent address and 2015 current address.",
  "The teacher-code rule excludes 2013 category 2, or 2015 categories 2/3.",
  "Participants with either address missing are excluded from this sensitivity sample; they are not coded as non-migrants.",
  paste0("riskset_n=", nrow(riskset)),
  paste0("both_addresses_observed=", sum(observed_both)),
  paste0("excluded_by_teacher_rule=", sum(moved_by_rule)),
  paste0("kept_no_move=", sum(keep_no_move)),
  paste0("kept_events=", sum(as.integer(as.character(riskset$cmm_event))[keep_no_move]))
), file.path(result_dir, "S11_migration_definition_and_limits.md"))

exposures <- c(
  TV = "temperature_TV_daily_annual_mean_pre2011",
  Tmean = "temperature_tmean_pre2011_mean_2008_2010",
  DTR = "temperature_dtr_pre2011_mean_2008_2010",
  Anum = "built_Anum", Bnum = "built_Bnum", CEnum = "built_CEnum"
)
m3_covariates <- c(
  "Age", "Gender", "Residence", "Education_Status", "Marital_status",
  "Smoking_Status", "Drinking_Status", "household_income", "BMI2011",
  "Regional_Category_2011"
)
probe <- mice::complete(mids_obj, action = 1)
fixed_columns <- intersect(c(unname(exposures), "cmm_event", "time_from_2011_years"), names(riskset))
completed_list <- lapply(seq_len(mids_obj$m), function(i) {
  d <- mice::complete(mids_obj, action = i)
  if (nrow(d) != nrow(riskset)) stop("第", i, "份插补数据行数不符。")
  d[fixed_columns] <- riskset[fixed_columns]
  d$ID_fixed <- riskset_id
  d$community_id_fixed <- as.character(riskset$community_id)
  d$individual_weight_fixed <- as.numeric(riskset$individual_weight)
  d
})

calc_iqr <- function(x) {
  q <- stats::quantile(as.numeric(x), c(.25, .75), na.rm = TRUE, names = FALSE)
  as.numeric(q[2] - q[1])
}
pool_rubin <- function(models, exposure_name, n_used, events_used, communities_used) {
  terms <- names(stats::coef(models[[1]]))
  do.call(rbind, lapply(terms, function(term) {
    q <- vapply(models, function(f) unname(stats::coef(f)[term]), numeric(1))
    u <- vapply(models, function(f) unname(stats::vcov(f)[term, term]), numeric(1))
    m <- length(q); qbar <- mean(q); within <- mean(u); between <- stats::var(q)
    total <- within + (1 + 1 / m) * between
    se <- sqrt(total)
    df <- if (between <= .Machine$double.eps) Inf else
      (m - 1) * (1 + within / ((1 + 1 / m) * between))^2
    statistic <- qbar / se
    p <- if (is.finite(df)) 2 * stats::pt(abs(statistic), df, lower.tail = FALSE) else
      2 * stats::pnorm(abs(statistic), lower.tail = FALSE)
    crit <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
    data.frame(
      analysis = "migration_exclusion_M3", exposure = exposure_name, term = term,
      imputations = m, beta = qbar, robust_SE = se, HR = exp(qbar),
      CI_95_low = exp(qbar - crit * se), CI_95_high = exp(qbar + crit * se),
      p_value = p, df = df, n = n_used, events = events_used,
      communities = communities_used, stringsAsFactors = FALSE
    )
  }))
}

fit_one <- function(d, exposure_column, iqr_value) {
  d$analysis_weight <- d$individual_weight_fixed / mean(d$individual_weight_fixed)
  d$event_num <- as.integer(as.character(d$cmm_event))
  d$time_num <- as.numeric(d$time_from_2011_years)
  d$exposure_IQR <- as.numeric(d[[exposure_column]]) / iqr_value
  formula <- stats::as.formula(paste(
    "survival::Surv(time_num, event_num) ~ exposure_IQR +",
    paste(m3_covariates, collapse = " + "), "+ cluster(community_id_fixed)"
  ))
  survival::coxph(formula, data = d, weights = analysis_weight,
                  ties = "efron", robust = TRUE, na.action = stats::na.fail, x = TRUE)
}

n_used <- sum(keep_no_move)
events_used <- sum(as.integer(as.character(riskset$cmm_event))[keep_no_move])
communities_used <- length(unique(riskset$community_id[keep_no_move]))
if (n_used == 0L || events_used == 0L) stop("迁移敏感性样本没有事件。")
results <- lapply(names(exposures), function(exposure_name) {
  exposure_column <- exposures[[exposure_name]]
  iqr_value <- calc_iqr(riskset[[exposure_column]][keep_no_move])
  models <- lapply(completed_list, function(d) {
    fit_one(d[keep_no_move, , drop = FALSE], exposure_column, iqr_value)
  })
  out <- pool_rubin(models, exposure_name, n_used, events_used, communities_used)
  out$exposure_IQR <- iqr_value
  out
})
results <- do.call(rbind, results)
write.csv(results, file.path(result_dir, "S09_migration_sensitivity_M3_pool_rubin.csv"),
          row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c(
  paste0("migration_sensitivity_status=COMPLETED"),
  paste0("n=", n_used), paste0("events=", events_used),
  paste0("communities=", communities_used), "m=20; maxit=25; Rubin pooling",
  paste0("created=", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"))
), file.path(trace_dir, "S12_migration_sensitivity_run.txt"))
cat("MIGRATION_SENSITIVITY_COMPLETED\n")
print(results[results$term == "exposure_IQR", ])
