# Software

Executed statistical analyses used R 4.4.3. Refer to archived sessionInfo records for versions where available. Required namespaces identified from the selected source scripts:

Hmisc, cmprsk, data.table, digest, ggplot2, grDevices, htmltools, mice, patchwork, ragg, stats, survival, survminer, svglite

This list is dependency discovery, not a claim that all versions are pinned in a lockfile. No automatic install command is run by the entry point.
