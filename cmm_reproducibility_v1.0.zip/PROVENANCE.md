# Meteorological provenance

The upstream source is ChinaMet: A High-resolution Multi-element Meteorological Driving Dataset for China via Multi-source Data Fusion, Zhang, L., Hu, Y., Zhao, Y., Che, T. (2025). DOI: https://doi.org/10.12072/ncdc.nieer.db6722.2025. CSTR: 11738.11.NCDC.NIEER.DB6722.2025. Provider: National Cryosphere Desert Data Center. License: CC BY 4.0.

The official record describes 1980–2024 coverage and 0.1° and 0.01° grids. The record was verified on 8 November 2026; this is not the original download date. Official metadata: https://www.ncdc.ac.cn/portal/metadata/21691d03-bef2-4800-924e-5614e7268b87.

Study inputs were existing provincial daily maximum/minimum temperature spreadsheets. Exposure calculations used 2008–2010. Mean daily temperature was (Tmax + Tmin)/2; daily range was Tmax − Tmin. Tmean was the annual mean of daily mean temperatures; DTR the annual mean daily range; TV the annual sample standard deviation of daily mean temperatures. The three annual values were averaged for each exposure. The archive also contained later years, which did not enter the primary exposure window.

The archived documentation does not identify which source grid resolution or spatial weighting procedure was used to create the provincial tables, nor the original download date. The published study exposures are provincial summaries; no individual grid-level exposure or specific administrative averaging algorithm is asserted. Original input fingerprints are retained in internal study records. The public provincial file contains derived baseline exposures, not the original gridded product.
