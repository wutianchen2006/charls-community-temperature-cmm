# Execution order

1. `06_ABC多重插补/代码/01_PartA修正版_准备插补输入_20261025.R`

2. `06_ABC多重插补/代码/02_PartB_MICE正式插补_20261025.R`

3. `06_ABC多重插补/代码/03_PartB_插补诊断复核_20261025.R`

4. `07_模型分析/代码/06_PartC_六暴露_M1_M2_M3_气温补充.R`

5. `08_暴露形式与模型诊断/代码/02_四分位数与趋势分析.R`

6. `08_暴露形式与模型诊断/代码/01_PH模型诊断.R`

7. `08_暴露形式与模型诊断/代码/03_论文附件_PH诊断.R`

8. `08_暴露形式与模型诊断/代码/03_RCS_20261027/01_RCS_six_exposures.R`

9. `08_暴露形式与模型诊断/代码/04_KM_20261027/01_KM_six_exposures.R`

10. `08_暴露形式与模型诊断/代码/05_竞争风险敏感性_20261027/02_competing_risk_CIF_wave_midpoint.R`

11. `08_暴露形式与模型诊断/代码/06_时间变化效应核查_20261027/01_时间变化效应核查_M3.R`

12. `08_暴露形式与模型诊断/代码/06_时间变化效应核查_20261027/03_仅重绘时间变化HR图.R`

13. `09_交互分析/代码/01_interaction_thermal_built_M1_M2_M3.R`

14. `10_敏感性分析/代码/01_sensitivity_analysis_M3.R`

15. `10_敏感性分析/代码/03_migration_sensitivity_M3_20261028.R`

16. `10_敏感性分析/代码/05_协变量完整病例与当前主分析对比_20261029.R`

Stages 1–3 create and diagnose MICE; stage 4 fits the final six-exposure Cox models. PH diagnostics must precede the PH attachment formatter. The time-varying effect script sources its adjacent redraw script. Later stages require the same prepared inputs plus their stage-specific files. These are selected analysis scripts, not a complete set of upstream extraction or figure-export scripts. Read ENVIRONMENT_VARIABLES.md and the input guards before running. Source data are not automatically fetched.
