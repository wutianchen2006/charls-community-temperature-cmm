# Execution configuration

Run from the repository root. Set P19_PROJECT_ROOT to a writable, authorized analysis project with the input directory layout documented in INPUTS.md. The entry point does not execute every stage automatically. ENVIRONMENT_VARIABLES.csv lists all named overrides used by each selected script. Empty-string defaults in a script are required settings, not optional defaults. Inspect the first path-setting block of that script before execution; set those variables to the prepared input and output locations. In particular, quartile and PH scripts require their explicit ASCII-path overrides. Use an ASCII alias for local input/output paths if required by your Windows R setup. Never commit participant input files or generated participant-level outputs.

This release was verified by syntax parsing and aggregate-output checks, not by rerunning all participant models on a clean machine.
